//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class JsEnv.DynamicDelegateProxy
// Size: 0x70 // Inherited bytes: 0x28
struct UDynamicDelegateProxy : UObject {
	// Fields
	char pad_0x28[0x48]; // Offset: 0x28 // Size: 0x48

	// Functions

	// Object Name: Function JsEnv.DynamicDelegateProxy.Fire
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Fire(); // Offset: 0x1025f05b4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class JsEnv.ExtensionMethods
// Size: 0x28 // Inherited bytes: 0x28
struct UExtensionMethods : UBlueprintFunctionLibrary {
};

// Object Name: Class JsEnv.JSAnimGeneratedClass
// Size: 0x4a0 // Inherited bytes: 0x440
struct UJSAnimGeneratedClass : UAnimBlueprintGeneratedClass {
	// Fields
	char pad_0x440[0x60]; // Offset: 0x440 // Size: 0x60
};

// Object Name: Class JsEnv.JSGeneratedClass
// Size: 0x430 // Inherited bytes: 0x3d0
struct UJSGeneratedClass : UBlueprintGeneratedClass {
	// Fields
	char pad_0x3D0[0x60]; // Offset: 0x3d0 // Size: 0x60
};

// Object Name: Class JsEnv.JSGeneratedFunction
// Size: 0x128 // Inherited bytes: 0xc0
struct UJSGeneratedFunction : UFunction {
	// Fields
	char pad_0xC0[0x68]; // Offset: 0xc0 // Size: 0x68
};

// Object Name: Class JsEnv.JSWidgetGeneratedClass
// Size: 0x4a0 // Inherited bytes: 0x440
struct UJSWidgetGeneratedClass : UWidgetBlueprintGeneratedClass {
	// Fields
	char pad_0x440[0x60]; // Offset: 0x440 // Size: 0x60
};

// Object Name: Class JsEnv.TypeScriptBlueprint
// Size: 0xd8 // Inherited bytes: 0xd8
struct UTypeScriptBlueprint : UBlueprint {
};

// Object Name: Class JsEnv.TypeScriptGeneratedClass
// Size: 0x488 // Inherited bytes: 0x3d0
struct UTypeScriptGeneratedClass : UBlueprintGeneratedClass {
	// Fields
	char pad_0x3D0[0xb1]; // Offset: 0x3d0 // Size: 0xb1
	bool HasConstructor; // Offset: 0x481 // Size: 0x01
	char pad_0x482[0x6]; // Offset: 0x482 // Size: 0x06
};

// Object Name: Class JsEnv.TypeScriptObject
// Size: 0x28 // Inherited bytes: 0x28
struct UTypeScriptObject : UInterface {
};

