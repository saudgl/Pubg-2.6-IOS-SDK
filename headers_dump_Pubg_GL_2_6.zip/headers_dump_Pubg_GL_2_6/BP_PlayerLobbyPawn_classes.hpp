//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C
// Size: 0xc84 // Inherited bytes: 0xa50
struct ABP_PlayerLobbyPawn_C : ASTExtraLobbyCharacter {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xa50 // Size: 0x08
	struct UBP_LobbyWeaponManager_C* BP_LobbyWeaponManager; // Offset: 0xa58 // Size: 0x08
	struct ULobbyPlayEmoteComponent_BP_C* LobbyPlayEmoteComponent_BP; // Offset: 0xa60 // Size: 0x08
	struct ULobbyWeaponAnimationComponent_C* LobbyWeaponAnimationComponent; // Offset: 0xa68 // Size: 0x08
	struct USkeletalMeshComponent* WeaponSkeletalMesh; // Offset: 0xa70 // Size: 0x08
	struct UCharacterAvatarComp2_BP_C* CharacterAvatarComp2_BP; // Offset: 0xa78 // Size: 0x08
	struct UAELobbyCharAnimListComp* AELobbyCharAnimListComp; // Offset: 0xa80 // Size: 0x08
	float Timeline_0_Time_DFD4E0A94A64AF2CC7AD9DB7F31CA12E; // Offset: 0xa88 // Size: 0x04
	enum class ETimelineDirection Timeline_0__Direction_DFD4E0A94A64AF2CC7AD9DB7F31CA12E; // Offset: 0xa8c // Size: 0x01
	char pad_0xA8D[0x3]; // Offset: 0xa8d // Size: 0x03
	struct UTimelineComponent* Timeline_1; // Offset: 0xa90 // Size: 0x08
	int headid; // Offset: 0xa98 // Size: 0x04
	int resID; // Offset: 0xa9c // Size: 0x04
	bool press; // Offset: 0xaa0 // Size: 0x01
	char pad_0xAA1[0x3]; // Offset: 0xaa1 // Size: 0x03
	float LocationX; // Offset: 0xaa4 // Size: 0x04
	enum class ETouchIndex FingerIndex; // Offset: 0xaa8 // Size: 0x01
	char pad_0xAA9[0x3]; // Offset: 0xaa9 // Size: 0x03
	int LobbyPosition; // Offset: 0xaac // Size: 0x04
	struct ASTExtraWeapon* curEquipingWeapon; // Offset: 0xab0 // Size: 0x08
	struct TMap<int, struct UBackpackEmoteHandle*> EmoteItemIDToHandleMap; // Offset: 0xab8 // Size: 0x50
	struct FString PlayerKey; // Offset: 0xb08 // Size: 0x10
	bool HeadIsVisible; // Offset: 0xb18 // Size: 0x01
	bool canRotate; // Offset: 0xb19 // Size: 0x01
	char pad_0xB1A[0x2]; // Offset: 0xb1a // Size: 0x02
	int LuaID; // Offset: 0xb1c // Size: 0x04
	struct FScriptMulticastDelegate OnPlayAction; // Offset: 0xb20 // Size: 0x10
	struct FScriptMulticastDelegate OnStopAction; // Offset: 0xb30 // Size: 0x10
	struct FScriptMulticastDelegate OnChangeEquipment; // Offset: 0xb40 // Size: 0x10
	struct UBackpackEmoteHandle* CurEmoteHandle; // Offset: 0xb50 // Size: 0x08
	bool bIsEmoteLooping; // Offset: 0xb58 // Size: 0x01
	char pad_0xB59[0x3]; // Offset: 0xb59 // Size: 0x03
	int CurrentActionID; // Offset: 0xb5c // Size: 0x04
	bool IsChangingHead; // Offset: 0xb60 // Size: 0x01
	char pad_0xB61[0x3]; // Offset: 0xb61 // Size: 0x03
	int PlayOnChangingHeadAcionID; // Offset: 0xb64 // Size: 0x04
	int CurPlayEmoteId; // Offset: 0xb68 // Size: 0x04
	bool IsPlayingAction; // Offset: 0xb6c // Size: 0x01
	char pad_0xB6D[0x3]; // Offset: 0xb6d // Size: 0x03
	float RotateTime; // Offset: 0xb70 // Size: 0x04
	float TargetRotation; // Offset: 0xb74 // Size: 0x04
	bool StartRotateFlag; // Offset: 0xb78 // Size: 0x01
	char pad_0xB79[0x3]; // Offset: 0xb79 // Size: 0x03
	float ClothAnimDyAlpha; // Offset: 0xb7c // Size: 0x04
	float CurClothAnimDyAlpha; // Offset: 0xb80 // Size: 0x04
	float ClothAnimDyAlphaDiff; // Offset: 0xb84 // Size: 0x04
	bool isMVPMotion; // Offset: 0xb88 // Size: 0x01
	char pad_0xB89[0x7]; // Offset: 0xb89 // Size: 0x07
	struct FScriptMulticastDelegate OnchangeGender; // Offset: 0xb90 // Size: 0x10
	struct FScriptMulticastDelegate OnChangeWeapon; // Offset: 0xba0 // Size: 0x10
	bool bEquipingSkateAircraft; // Offset: 0xbb0 // Size: 0x01
	bool isAutoTest; // Offset: 0xbb1 // Size: 0x01
	char pad_0xBB2[0x2]; // Offset: 0xbb2 // Size: 0x02
	struct FVector LocationBeforeEmote; // Offset: 0xbb4 // Size: 0x0c
	int AvatarLevel; // Offset: 0xbc0 // Size: 0x04
	float Inten; // Offset: 0xbc4 // Size: 0x04
	struct FScriptMulticastDelegate OnEquipClothStateChange; // Offset: 0xbc8 // Size: 0x10
	bool ForceUseDefaultIdle; // Offset: 0xbd8 // Size: 0x01
	char pad_0xBD9[0x7]; // Offset: 0xbd9 // Size: 0x07
	struct FScriptMulticastDelegate OnSetForceUseDefaultIdle; // Offset: 0xbe0 // Size: 0x10
	struct TMap<int, int> DynamicMatClothMap; // Offset: 0xbf0 // Size: 0x50
	float WindSpeed_Editor; // Offset: 0xc40 // Size: 0x04
	float WindStrength_Editor; // Offset: 0xc44 // Size: 0x04
	float WindRadius_Editor; // Offset: 0xc48 // Size: 0x04
	char pad_0xC4C[0x4]; // Offset: 0xc4c // Size: 0x04
	struct UCurveFloat* WindSpeed; // Offset: 0xc50 // Size: 0x08
	float AccumelateWindTime; // Offset: 0xc58 // Size: 0x04
	char pad_0xC5C[0x4]; // Offset: 0xc5c // Size: 0x04
	struct FScriptMulticastDelegate OnAvatarComponentAllMeshLoaded; // Offset: 0xc60 // Size: 0x10
	struct FScriptMulticastDelegate OnSceneType2Change; // Offset: 0xc70 // Size: 0x10
	int SceneType2; // Offset: 0xc80 // Size: 0x04

	// Functions

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.SetCompRotate
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetCompRotate(struct USceneComponent* RotateComp, float Rotate); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.SetAddCharacterWeaponAnimListHandle
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetAddCharacterWeaponAnimListHandle(struct TArray<struct FLobbyCharacterWeaponAnimData>& addAnimData, bool& Suc); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.CharEquipWeaponPendant
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void CharEquipWeaponPendant(int WeaponID, enum class EWeaponPendantSocketType PendantSocketType); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.WeaponAllAssetLoadFinish
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void WeaponAllAssetLoadFinish(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.CharUnEquipWeaponByResId
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void CharUnEquipWeaponByResId(int resID, struct FName SocketName); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.CharUnEquipExtraWeapon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void CharUnEquipExtraWeapon(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.SetForceUseDefaultIdle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetForceUseDefaultIdle(bool force); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.UpdateClothInten
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateClothInten(float leten); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.UpdateClothMatParam
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateClothMatParam(float RotateSpeed); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.StopActionCamera
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void StopActionCamera(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.RotateOnTickInternal
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void RotateOnTickInternal(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.GetCurrentActionID
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetCurrentActionID(int& ActionID); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.SetAvatarLevel
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetAvatarLevel(int Level); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.OnAvatarAllMeshLoaded
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnAvatarAllMeshLoaded(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.TryRotateAvatar
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void TryRotateAvatar(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.SetAvatarVisibleForEmote
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetAvatarVisibleForEmote(bool Visible); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.RequestWeaponDIYData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RequestWeaponDIYData(struct FString InPlayerUID, int WeaponAvatarID, int InDIYPlanID); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.SetIsMVPMotion
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIsMVPMotion(bool isMVPMotion); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.SyncWeaponMontage
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SyncWeaponMontage(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.InitDefaultAvatarByResID
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void InitDefaultAvatarByResID(int AGender, int Head, int Hair); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.SetClothAnimDyAlphaInst
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetClothAnimDyAlphaInst(float Alpha); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.SetClothAnimDyAlphaGrad
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetClothAnimDyAlphaGrad(float Alpha); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.SetClothAnimDyAlpha
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetClothAnimDyAlpha(float Alpha); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.RotateOnTick
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RotateOnTick(float RotateTime, float TargetRotation); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.OnEndActionHandle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnEndActionHandle(int ActionID); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.OnPlayActionHandle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnPlayActionHandle(int ActionID); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.SetConflictRuleEnable
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetConflictRuleEnable(bool bEnableConflictRule); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.PutOffEquipmentBySlot
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void PutOffEquipmentBySlot(enum class EAvatarSlotType SlotType, bool& Result); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x2)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.PlayEmoteLoop
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void PlayEmoteLoop(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.ShouldCurEmoteShowWeapon
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void ShouldCurEmoteShowWeapon(bool& Result); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.HandleWeaponDisplayWhenPlayEmote
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void HandleWeaponDisplayWhenPlayEmote(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.GetAllEquipmentList
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetAllEquipmentList(struct TArray<int>& Result); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.SetCanRotate
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetCanRotate(bool canRotate); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.PutOffEquipmentByResID
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void PutOffEquipmentByResID(int resID, bool& Result); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.PutOnEquipmentByResID
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void PutOnEquipmentByResID(int resID, int ColorID, int PatternID, bool& Result); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0xd)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.HideWeapon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void HideWeapon(bool isHide); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.CharPlayEmoteByResId
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void CharPlayEmoteByResId(int EmoteId, struct FString ExtraInfo); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.CharUnEquipWeapon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void CharUnEquipWeapon(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.CharEquipWeaponByResId
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void CharEquipWeaponByResId(int resID, bool bUse, bool bAsync, struct FName SocketName, struct ASTExtraWeapon*& Weapon); // Offset: 0x1041acc2c // Return & Params: Num(5) Size(0x18)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.GetEmoteHandle
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	struct UBackpackEmoteHandle* GetEmoteHandle(int ItemID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.GetBPID
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetBPID(int RowName, int& BPID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.Timeline_0__FinishedFunc
	// Flags: [BlueprintEvent]
	void Timeline_0__FinishedFunc(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.Timeline_0__UpdateFunc
	// Flags: [BlueprintEvent]
	void Timeline_0__UpdateFunc(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveTick(float DeltaSeconds); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_3_ComponentOnInputTouchBeginSignature__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_3_ComponentOnInputTouchBeginSignature__DelegateSignature(enum class ETouchIndex FingerIndex, struct UPrimitiveComponent* TouchedComponent); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_0_ComponentOnInputTouchEndSignature__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_0_ComponentOnInputTouchEndSignature__DelegateSignature(enum class ETouchIndex FingerIndex, struct UPrimitiveComponent* TouchedComponent); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.TickClothLeten
	// Flags: [BlueprintCallable|BlueprintEvent]
	void TickClothLeten(float from); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.ExecuteUbergraph_BP_PlayerLobbyPawn
	// Flags: [HasDefaults]
	void ExecuteUbergraph_BP_PlayerLobbyPawn(int EntryPoint); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.OnSceneType2Change__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnSceneType2Change__DelegateSignature(int sceneType); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.OnAvatarComponentAllMeshLoaded__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnAvatarComponentAllMeshLoaded__DelegateSignature(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.OnSetForceUseDefaultIdle__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnSetForceUseDefaultIdle__DelegateSignature(bool force); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.OnEquipClothStateChange__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnEquipClothStateChange__DelegateSignature(struct UBackpackAvatarHandle* AvatarHandle, bool IsEuqiped, int ItemID, int SlotType); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x14)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.OnChangeWeapon__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnChangeWeapon__DelegateSignature(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.OnchangeGender__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnchangeGender__DelegateSignature(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.OnChangeEquipment__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnChangeEquipment__DelegateSignature(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.OnStopAction__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnStopAction__DelegateSignature(int ActionID); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_PlayerLobbyPawn.BP_PlayerLobbyPawn_C.OnPlayAction__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnPlayAction__DelegateSignature(int ActionID); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)
};

