//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Mid_Activity_UIBP.Lobby_Mid_Activity_UIBP_C
// Size: 0x3b8 // Inherited bytes: 0x260
struct ULobby_Mid_Activity_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* Animation_loading; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* Animation_Hand_Loop; // Offset: 0x268 // Size: 0x08
	struct UWidgetAnimation* Animation_Mask; // Offset: 0x270 // Size: 0x08
	struct UWidgetAnimation* Animation_Hand; // Offset: 0x278 // Size: 0x08
	struct UButton* Button_Activity; // Offset: 0x280 // Size: 0x08
	struct UButton* Button_Close; // Offset: 0x288 // Size: 0x08
	struct UButton* Button_EightDay; // Offset: 0x290 // Size: 0x08
	struct UButton* Button_PlayerReturn; // Offset: 0x298 // Size: 0x08
	struct UButton* Button_SpecialActice; // Offset: 0x2a0 // Size: 0x08
	struct UCanvasPanel* Canvas_Panel_HandGuide; // Offset: 0x2a8 // Size: 0x08
	struct UCanvasPanel* Canvas_Panel_HandGuide2; // Offset: 0x2b0 // Size: 0x08
	struct UCanvasPanel* Canvas_Panel_tips; // Offset: 0x2b8 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_2; // Offset: 0x2c0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_7; // Offset: 0x2c8 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_EightDay; // Offset: 0x2d0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_PR; // Offset: 0x2d8 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_SpecialActice; // Offset: 0x2e0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_WorldCup; // Offset: 0x2e8 // Size: 0x08
	struct UCommon_Tips_NoArrow_UIBP_C* Common_Tips_NoArrow_UIBP; // Offset: 0x2f0 // Size: 0x08
	struct UCanvasPanel* FX_Mask; // Offset: 0x2f8 // Size: 0x08
	struct UButton* GuideBtn; // Offset: 0x300 // Size: 0x08
	struct UCanvasPanel* GuidePanel; // Offset: 0x308 // Size: 0x08
	struct UTextBlock* GuideTip; // Offset: 0x310 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_loading; // Offset: 0x318 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x320 // Size: 0x08
	struct UImage* Image_2; // Offset: 0x328 // Size: 0x08
	struct UImage* Image_4; // Offset: 0x330 // Size: 0x08
	struct UImage* Image_17; // Offset: 0x338 // Size: 0x08
	struct UImage* Image_Activice_CDN; // Offset: 0x340 // Size: 0x08
	struct UReddot_Anchor_C* Image_ActivityNewTips; // Offset: 0x348 // Size: 0x08
	struct UImage* Image_Clock; // Offset: 0x350 // Size: 0x08
	struct UMaskBoxItem_C* MaskBoxItem; // Offset: 0x358 // Size: 0x08
	struct USizeBox* Panel_ActivePack; // Offset: 0x360 // Size: 0x08
	struct UCanvasPanel* Panel_Activity; // Offset: 0x368 // Size: 0x08
	struct UCanvasPanel* Panel_Download; // Offset: 0x370 // Size: 0x08
	struct UReddot_Anchor_C* Reddot_Anchor; // Offset: 0x378 // Size: 0x08
	struct UReddot_Anchor_C* Reddot_Anchor_EightDay; // Offset: 0x380 // Size: 0x08
	struct UScaleBox* ScaleBox_5; // Offset: 0x388 // Size: 0x08
	struct UHorizontalBox* SpecialActice_Time; // Offset: 0x390 // Size: 0x08
	struct UTextBlock* TextBlock_1; // Offset: 0x398 // Size: 0x08
	struct UTextBlock* TextBlock_2; // Offset: 0x3a0 // Size: 0x08
	struct UTextBlock* TextBlock_3; // Offset: 0x3a8 // Size: 0x08
	struct UTextBlock* TextBlock_CountDown; // Offset: 0x3b0 // Size: 0x08
};

