//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Downloader_Btn_UIBP.Lobby_Downloader_Btn_UIBP_C
// Size: 0x2a8 // Inherited bytes: 0x260
struct ULobby_Downloader_Btn_UIBP_C : UUserWidget {
	// Fields
	struct UCanvasPanel* CanvasPanel_Downloading_ODPack; // Offset: 0x260 // Size: 0x08
	struct UCommon_DragDrop_Item_C* CommonDragDropItem; // Offset: 0x268 // Size: 0x08
	struct UImage* Image_Progress; // Offset: 0x270 // Size: 0x08
	struct UImage* Image_Reddot; // Offset: 0x278 // Size: 0x08
	struct UCanvasPanel* Panel_Downloader; // Offset: 0x280 // Size: 0x08
	struct UCanvasPanel* Panel_Drag; // Offset: 0x288 // Size: 0x08
	struct UScaleBox* ScaleBox_Downloader; // Offset: 0x290 // Size: 0x08
	struct UTextBlock* Text_Downloading_ODPack; // Offset: 0x298 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Download; // Offset: 0x2a0 // Size: 0x08
};

