//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_FeatureUICfg_type.BP_STRUCT_FeatureUICfg_type
// Size: 0x44 // Inherited bytes: 0x00
struct FBP_STRUCT_FeatureUICfg_type {
	// Fields
	struct FString BattleEventIDs_0_6D247B8029EC8E1478D50F9D0FC4C063; // Offset: 0x00 // Size: 0x10
	int CategoryID_1_6F4276C07523A563488E820901C29EC4; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString CategoryName_2_6AC933C06BF94C4519F7015D029F57F5; // Offset: 0x18 // Size: 0x10
	int SlotCount_3_4B40AEC07DA5B30334A437170D303BF4; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString VoiceKey_4_00E30BC07027C15D12EF1AE30E4404A9; // Offset: 0x30 // Size: 0x10
	int FeatureType_5_11165F802A37C5A86D09A7EA0ACFC375; // Offset: 0x40 // Size: 0x04
};

