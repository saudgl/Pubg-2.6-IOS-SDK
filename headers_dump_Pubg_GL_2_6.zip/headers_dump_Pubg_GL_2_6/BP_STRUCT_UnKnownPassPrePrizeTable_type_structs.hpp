//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_UnKnownPassPrePrizeTable_type.BP_STRUCT_UnKnownPassPrePrizeTable_type
// Size: 0x54 // Inherited bytes: 0x00
struct FBP_STRUCT_UnKnownPassPrePrizeTable_type {
	// Fields
	int BonusPoint1_0_32BF96002EE7025039619F17053858E1; // Offset: 0x00 // Size: 0x04
	int BonusPoint2_1_32C096402EE7025139619F16053858E2; // Offset: 0x04 // Size: 0x04
	int Cost_2_435ECBC05586E6B52691509605D4E924; // Offset: 0x08 // Size: 0x04
	int GiftId_3_7ADD734011504EAF3C7F950604905D24; // Offset: 0x0c // Size: 0x04
	int Id_4_16FE30C04B665A1B01233E090F85D4B4; // Offset: 0x10 // Size: 0x04
	int SeasonId_5_3E5BAB002E21B9B442D798DC040D9724; // Offset: 0x14 // Size: 0x04
	int GiftItemId_6_38EC1700770A2DF21A386D580EDE31A4; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString BuyReward_7_0E54CAC03DBED61908EA002206D195B4; // Offset: 0x20 // Size: 0x10
	struct FString PhaseReward1_8_6F64C740292041AB3925FDAD0DEC8401; // Offset: 0x30 // Size: 0x10
	struct FString PhaseReward2_9_6F65C780292041AC3925FDAC0DEC8402; // Offset: 0x40 // Size: 0x10
	int AppID_11_45B8B10072F3C8F67AF9AA0D0D4C8C84; // Offset: 0x50 // Size: 0x04
};

