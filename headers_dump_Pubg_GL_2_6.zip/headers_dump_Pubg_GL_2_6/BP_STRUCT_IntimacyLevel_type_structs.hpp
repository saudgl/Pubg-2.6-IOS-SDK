//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_IntimacyLevel_type.BP_STRUCT_IntimacyLevel_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_IntimacyLevel_type {
	// Fields
	int Level_0_54F611001D596F340030895701A822CC; // Offset: 0x00 // Size: 0x04
	int MaxExp_1_5EFBC7C050190E932F5853C00A962BE0; // Offset: 0x04 // Size: 0x04
	int MinExp_2_4621874016AB038529E2C3FA0A92CBE0; // Offset: 0x08 // Size: 0x04
	int ID_3_1AD816402E08282F322819440EE71974; // Offset: 0x0c // Size: 0x04
	int Number_4_2D526D407E0CC6ED383562640AF6DFD2; // Offset: 0x10 // Size: 0x04
};

