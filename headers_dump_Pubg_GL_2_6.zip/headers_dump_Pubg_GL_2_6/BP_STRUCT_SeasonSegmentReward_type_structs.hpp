//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SeasonSegmentReward_type.BP_STRUCT_SeasonSegmentReward_type
// Size: 0xa0 // Inherited bytes: 0x00
struct FBP_STRUCT_SeasonSegmentReward_type {
	// Fields
	struct FString Condition1_Desc_0_2042FB402C5056DB6337C70903C8E093; // Offset: 0x00 // Size: 0x10
	int Condition1_Param_1_709777C01C544B1719A325320CF2484D; // Offset: 0x10 // Size: 0x04
	int ID_2_4CC2B10041ADE1C4597AD7D90C66BE04; // Offset: 0x14 // Size: 0x04
	int IsJK_3_5AB0E200671AB2DA7B5D805006BFDB8B; // Offset: 0x18 // Size: 0x04
	int RelateID_4_374AC84063A7037B4DC05F46084E1684; // Offset: 0x1c // Size: 0x04
	int SeasonID_8_398F6B40120B9EAD7161DCD007F0FD94; // Offset: 0x20 // Size: 0x04
	int SortID_9_11F07B007D54FC8866C0DF720F5AFE64; // Offset: 0x24 // Size: 0x04
	int RewardItem_Num1_10_14323AC060263DDB0581BE6D01D1DFA1; // Offset: 0x28 // Size: 0x04
	int RewardItem_Num2_11_14333B0060263DDC0581BE6201D1DFA2; // Offset: 0x2c // Size: 0x04
	int RewardItem_Num3_12_14343B4060263DDD0581BE6301D1DFA3; // Offset: 0x30 // Size: 0x04
	int RewardItem_Time1_13_023AF280397AA41A5770E3230D72B991; // Offset: 0x34 // Size: 0x04
	int RewardItem_Time2_14_023BF2C0397AA41B5770E3220D72B992; // Offset: 0x38 // Size: 0x04
	int RewardItem_Time3_15_023CF300397AA41C5770E32D0D72B993; // Offset: 0x3c // Size: 0x04
	int RewardItemID1_16_49139A4028E218ED3EB828B705A1FEF1; // Offset: 0x40 // Size: 0x04
	int RewardItemID2_17_49149A8028E218EE3EB828B605A1FEF2; // Offset: 0x44 // Size: 0x04
	int RewardItemID3_18_49159AC028E218EF3EB828B105A1FEF3; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct FString Condition1_Type_19_30EF640071D2E9EC6309E0A603D00C65; // Offset: 0x50 // Size: 0x10
	struct FString ImageUrl_blue_1_22_4DBDD9002CC6C1B46D8EAC08044297D1; // Offset: 0x60 // Size: 0x10
	struct FString ImageUrl_blue_2_23_4DBED9402CC6C1B56D8EAC09044297D2; // Offset: 0x70 // Size: 0x10
	struct FString ImageUrl_global_1_24_0B038B405F913C9D4A6C664A04749651; // Offset: 0x80 // Size: 0x10
	struct FString ImageUrl_global_2_25_0B048B805F913C9E4A6C664D04749652; // Offset: 0x90 // Size: 0x10
};

