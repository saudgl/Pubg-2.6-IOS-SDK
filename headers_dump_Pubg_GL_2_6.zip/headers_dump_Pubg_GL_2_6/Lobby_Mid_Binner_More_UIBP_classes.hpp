//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C
// Size: 0x489 // Inherited bytes: 0x418
struct ULobby_Mid_Binner_More_UIBP_C : UUAEUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x418 // Size: 0x08
	struct UWidgetAnimation* NewAnimation_2; // Offset: 0x420 // Size: 0x08
	struct UHorizontalBox* DotPanel; // Offset: 0x428 // Size: 0x08
	struct ULoopScrollBox* LoopScrollBox_1; // Offset: 0x430 // Size: 0x08
	struct TArray<struct ULobby_Activity_BtnItem_C*> ActivityBtnList; // Offset: 0x438 // Size: 0x10
	struct FTimerHandle BtnListMoveTimer; // Offset: 0x448 // Size: 0x08
	float ActivityBtnItemLen; // Offset: 0x450 // Size: 0x04
	char pad_0x454[0x4]; // Offset: 0x454 // Size: 0x04
	struct FTimerHandle BtnPlayingAnimTimer; // Offset: 0x458 // Size: 0x08
	float BtnListPlayAnimTarget; // Offset: 0x460 // Size: 0x04
	bool BtnListIsLastWindow; // Offset: 0x464 // Size: 0x01
	char pad_0x465[0x3]; // Offset: 0x465 // Size: 0x03
	struct FScriptMulticastDelegate EventDispatcherClickItem; // Offset: 0x468 // Size: 0x10
	float alignOffset; // Offset: 0x478 // Size: 0x04
	int pageCount; // Offset: 0x47c // Size: 0x04
	bool bNextDir; // Offset: 0x480 // Size: 0x01
	bool bAniIng; // Offset: 0x481 // Size: 0x01
	char pad_0x482[0x2]; // Offset: 0x482 // Size: 0x02
	float preOffset; // Offset: 0x484 // Size: 0x04
	bool isUserScrolling; // Offset: 0x488 // Size: 0x01

	// Functions

	// Object Name: Function Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C.GetOffset
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetOffset(float& Offset); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C.GetCurrentIndex
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetCurrentIndex(int& Index); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C.OnClickActivityItem
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnClickActivityItem(struct ULobby_Activity_BtnItem_C* Item); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C.UpdateCurrentPage
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateCurrentPage(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C.SetActivityListPageCount
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetActivityListPageCount(int pageCount); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C.ExecuteUbergraph_Lobby_Mid_Binner_More_UIBP
	// Flags: [HasDefaults]
	void ExecuteUbergraph_Lobby_Mid_Binner_More_UIBP(int EntryPoint); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_Mid_Binner_More_UIBP.Lobby_Mid_Binner_More_UIBP_C.EventDispatcherClickItem__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void EventDispatcherClickItem__DelegateSignature(int ID, struct FString JumpUrl); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x18)
};

