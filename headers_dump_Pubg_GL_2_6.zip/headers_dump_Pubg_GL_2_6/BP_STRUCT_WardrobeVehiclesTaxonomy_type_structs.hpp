//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_WardrobeVehiclesTaxonomy_type.BP_STRUCT_WardrobeVehiclesTaxonomy_type
// Size: 0x44 // Inherited bytes: 0x00
struct FBP_STRUCT_WardrobeVehiclesTaxonomy_type {
	// Fields
	struct FString VehicleCategory_0_10BFF70056B8B1E46F44B0120573CC69; // Offset: 0x00 // Size: 0x10
	int ItemType_1_312483C01C043C7F41F1619E07906695; // Offset: 0x10 // Size: 0x04
	int CategoryID_2_7E33CA400EBD22471AAEA58B0943F844; // Offset: 0x14 // Size: 0x04
	int VehicleDefualtSkinID_3_73E9C140593D93EB45B24C6D0601D044; // Offset: 0x18 // Size: 0x04
	int ItemSubType_4_22958E407F58036D2DFC867104D8D965; // Offset: 0x1c // Size: 0x04
	struct FString VehicleName_5_1FF167C0777BABCD7B26BBE7086B2BE5; // Offset: 0x20 // Size: 0x10
	struct FString WardrobeTab_6_46378AC06C962BDF4CEF757E071AF1E2; // Offset: 0x30 // Size: 0x10
	int WardrobePage_7_7429244070874BDD7DCB1D6B01AFDEA5; // Offset: 0x40 // Size: 0x04
};

