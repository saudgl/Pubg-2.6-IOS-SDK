//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_PutOnReport_type.BP_STRUCT_PutOnReport_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_PutOnReport_type {
	// Fields
	struct FString Version_0_5ABF9B80438DAF421345F6CB0E63E45E; // Offset: 0x00 // Size: 0x10
	int ID_1_2D35C5406584F4E37D3516270AA7C1F4; // Offset: 0x10 // Size: 0x04
};

