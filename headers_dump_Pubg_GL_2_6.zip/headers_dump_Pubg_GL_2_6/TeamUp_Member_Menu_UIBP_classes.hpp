//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass TeamUp_Member_Menu_UIBP.TeamUp_Member_Menu_UIBP_C
// Size: 0x618 // Inherited bytes: 0x418
struct UTeamUp_Member_Menu_UIBP_C : UUAEUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x418 // Size: 0x08
	struct UWidgetAnimation* AceImprintAnimation10; // Offset: 0x420 // Size: 0x08
	struct UWidgetAnimation* AceImprintAnimation9; // Offset: 0x428 // Size: 0x08
	struct UWidgetAnimation* AceImprintAnimation8; // Offset: 0x430 // Size: 0x08
	struct UWidgetAnimation* AceImprintAnimation7; // Offset: 0x438 // Size: 0x08
	struct UWidgetAnimation* AceImprintAnimation6; // Offset: 0x440 // Size: 0x08
	struct UWidgetAnimation* AceImprintAnimation5; // Offset: 0x448 // Size: 0x08
	struct UButton* BtnVipGet; // Offset: 0x450 // Size: 0x08
	struct UButton* Button_AddFriend; // Offset: 0x458 // Size: 0x08
	struct UButton* Button_Car_Other; // Offset: 0x460 // Size: 0x08
	struct UButton* Button_GotoIsland; // Offset: 0x468 // Size: 0x08
	struct UButton* Button_Info; // Offset: 0x470 // Size: 0x08
	struct UButton* Button_Leave; // Offset: 0x478 // Size: 0x08
	struct UButton* Button_Tips; // Offset: 0x480 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_2; // Offset: 0x488 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_AceImprint; // Offset: 0x490 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Certification; // Offset: 0x498 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Credit; // Offset: 0x4a0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_FrameSeason; // Offset: 0x4a8 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_IntimacyTip; // Offset: 0x4b0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Island; // Offset: 0x4b8 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Like; // Offset: 0x4c0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_LikeTip; // Offset: 0x4c8 // Size: 0x08
	struct UGridPanel* CanvasPanel_QuickMsg; // Offset: 0x4d0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_SegmentLimit; // Offset: 0x4d8 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_VipGift; // Offset: 0x4e0 // Size: 0x08
	struct UCanvasPanel* CanvasPanelNewSeason; // Offset: 0x4e8 // Size: 0x08
	struct UCommon_KingMark_UIBP_C* Common_KingMark_UIBP_1; // Offset: 0x4f0 // Size: 0x08
	struct UCommon_RankIntegralLevel_Style_Small_UIBP_C* Common_RankIntegralLevel_Style_Small_UIBP; // Offset: 0x4f8 // Size: 0x08
	struct UImage* Image_13; // Offset: 0x500 // Size: 0x08
	struct UImage* Image_17; // Offset: 0x508 // Size: 0x08
	struct UImage* Image_31; // Offset: 0x510 // Size: 0x08
	struct UImage* Image_Certification; // Offset: 0x518 // Size: 0x08
	struct UImage* Image_CropsIcon; // Offset: 0x520 // Size: 0x08
	struct UImage* Image_frame; // Offset: 0x528 // Size: 0x08
	struct UImage* Image_LostConnection; // Offset: 0x530 // Size: 0x08
	struct UImage* Image_Nation; // Offset: 0x538 // Size: 0x08
	struct UImage* Image_PlayerReady; // Offset: 0x540 // Size: 0x08
	struct UImage* Image_PlayerStatus; // Offset: 0x548 // Size: 0x08
	struct ULobby_RoleInfo_IntimacyItem_UIBP_C* Lobby_RoleInfo_IntimacyItem_UIBP; // Offset: 0x550 // Size: 0x08
	struct UCanvasPanel* other_msg_root; // Offset: 0x558 // Size: 0x08
	struct UOverlay* Overlay_InfoMenu; // Offset: 0x560 // Size: 0x08
	struct UTextBlock* TextBlock_2; // Offset: 0x568 // Size: 0x08
	struct UTextBlock* TextBlock_Certification; // Offset: 0x570 // Size: 0x08
	struct UUTRichTextBlock* TextBlock_CorpsName; // Offset: 0x578 // Size: 0x08
	struct UTextBlock* TextBlock_FrameSeason; // Offset: 0x580 // Size: 0x08
	struct UTextBlock* TextBlock_Intimacy; // Offset: 0x588 // Size: 0x08
	struct UTextBlock* TextBlock_Island; // Offset: 0x590 // Size: 0x08
	struct UTextBlock* TextBlock_Like; // Offset: 0x598 // Size: 0x08
	struct UTextBlock* TextBlock_Like_Tip; // Offset: 0x5a0 // Size: 0x08
	struct UTextBlock* TextBlock_PlayerName; // Offset: 0x5a8 // Size: 0x08
	struct UTextBlock* TextBlock_SegmentLimitNotice; // Offset: 0x5b0 // Size: 0x08
	struct UTextBlock* TextBlock_VipGiftCount; // Offset: 0x5b8 // Size: 0x08
	struct UTitle_UIBP_C* Title_UIBP; // Offset: 0x5c0 // Size: 0x08
	struct UUIParticleEmitter* UIParticleEmitter_1; // Offset: 0x5c8 // Size: 0x08
	struct UUIParticleEmitter* UIParticleEmitter_2; // Offset: 0x5d0 // Size: 0x08
	struct UUTRichTextBlock* UTRichText_Credit; // Offset: 0x5d8 // Size: 0x08
	struct UUTRichTextBlock* UTRichText_QuickMsg; // Offset: 0x5e0 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_VipGift; // Offset: 0x5e8 // Size: 0x08
	struct UVerticalBox* VerticalBox_Extra; // Offset: 0x5f0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Car_Other; // Offset: 0x5f8 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_CorpsAndOffline; // Offset: 0x600 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Sound; // Offset: 0x608 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_VoiceState; // Offset: 0x610 // Size: 0x08

	// Functions

	// Object Name: Function TeamUp_Member_Menu_UIBP.TeamUp_Member_Menu_UIBP_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TeamUp_Member_Menu_UIBP.TeamUp_Member_Menu_UIBP_C.ExecuteUbergraph_TeamUp_Member_Menu_UIBP
	// Flags: [None]
	void ExecuteUbergraph_TeamUp_Member_Menu_UIBP(int EntryPoint); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)
};

