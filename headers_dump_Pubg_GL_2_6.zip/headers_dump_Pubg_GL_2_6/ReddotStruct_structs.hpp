//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct ReddotStruct.ReddotStruct
// Size: 0x20 // Inherited bytes: 0x00
struct FReddotStruct {
	// Fields
	struct FAnchors Anchors_2_1D1BE06140EEDD14FCCDB8AD96841144; // Offset: 0x00 // Size: 0x10
	struct FMargin Offsets_7_A38D96FC45596973BE8CC8AFB5139726; // Offset: 0x10 // Size: 0x10
};

