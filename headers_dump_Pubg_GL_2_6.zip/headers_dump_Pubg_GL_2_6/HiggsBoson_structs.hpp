//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct HiggsBoson.PatchPoint
// Size: 0x0c // Inherited bytes: 0x00
struct FPatchPoint {
	// Fields
	int Offset; // Offset: 0x00 // Size: 0x04
	uint32_t Old; // Offset: 0x04 // Size: 0x04
	uint32_t New; // Offset: 0x08 // Size: 0x04
};

