//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass PickUp_BP_Shirt_01_Bra.PickUp_BP_Shirt_01_Bra_C
// Size: 0x858 // Inherited bytes: 0x850
struct APickUp_BP_Shirt_01_Bra_C : APickUpWrapperActor {
	// Fields
	struct UStaticMeshComponent* Bag_03_icon; // Offset: 0x850 // Size: 0x08

	// Functions

	// Object Name: Function PickUp_BP_Shirt_01_Bra.PickUp_BP_Shirt_01_Bra_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)
};

