//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_NewLevelTask_type.BP_STRUCT_NewLevelTask_type
// Size: 0x88 // Inherited bytes: 0x00
struct FBP_STRUCT_NewLevelTask_type {
	// Fields
	int TouristSwitch2_0_07F03A404907C74147D6D7AC0AEBF7E2; // Offset: 0x00 // Size: 0x04
	int Level_1_0F0B10C01F30D35763EAB4540563A09C; // Offset: 0x04 // Size: 0x04
	int TouristSwitch1_2_07EF3A004907C74047D6D7AF0AEBF7E1; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString Task2Detail_3_61BB38C0398B095F4DEFFEE503E7423C; // Offset: 0x10 // Size: 0x10
	struct FString JumpTo2_4_171B770071C2E7202553E80100E88042; // Offset: 0x20 // Size: 0x10
	struct FString Unlock_5_54330DC077D16E993B46B7F904B3F7CB; // Offset: 0x30 // Size: 0x10
	int Task2Award_6_3E5B5FC035CE93AF7BAA12770C3C66D4; // Offset: 0x40 // Size: 0x04
	int Award_7_63A86E802253655463E379D20559B4A4; // Offset: 0x44 // Size: 0x04
	int Task2Cond_8_75434500020FE0D236016D4505C3EFA4; // Offset: 0x48 // Size: 0x04
	int IOSSwitch1_9_72507640177498ED761F6C0B08957BF1; // Offset: 0x4c // Size: 0x04
	struct FString Task1Detail_10_22B2F8802B35ECB859A1B20000E7423C; // Offset: 0x50 // Size: 0x10
	int IOSSwitch2_11_72517680177498EE761F6C0C08957BF2; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct FString JumpTo1_12_171A76C071C2E71F2553E80000E88041; // Offset: 0x68 // Size: 0x10
	int Task1Cond_13_70D2C4C0008AB2212C1CB48805C0EFA4; // Offset: 0x78 // Size: 0x04
	int Task1Award_14_4AA6FF8023DBC7502297C6040C0C66D4; // Offset: 0x7c // Size: 0x04
	int TaskTpye1_15_39750C4057DB62092A31AFDF062E3461; // Offset: 0x80 // Size: 0x04
	int TaskTpye2_16_39760C8057DB620A2A31AFDE062E3462; // Offset: 0x84 // Size: 0x04
};

