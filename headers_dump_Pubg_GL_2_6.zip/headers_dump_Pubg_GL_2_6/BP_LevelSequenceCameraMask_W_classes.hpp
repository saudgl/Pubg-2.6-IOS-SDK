//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass BP_LevelSequenceCameraMask_W.BP_LevelSequenceCameraMask_W_C
// Size: 0x278 // Inherited bytes: 0x260
struct UBP_LevelSequenceCameraMask_W_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* FadeOut; // Offset: 0x260 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_1; // Offset: 0x268 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x270 // Size: 0x08
};

