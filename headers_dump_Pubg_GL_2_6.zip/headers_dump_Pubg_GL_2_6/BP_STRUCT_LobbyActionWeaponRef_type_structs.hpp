//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_LobbyActionWeaponRef_type.BP_STRUCT_LobbyActionWeaponRef_type
// Size: 0x0c // Inherited bytes: 0x00
struct FBP_STRUCT_LobbyActionWeaponRef_type {
	// Fields
	int ActionID_0_284E37801299E72232C748730798C614; // Offset: 0x00 // Size: 0x04
	int WeaponActionID_1_2D2D7200775F04DA5CEAA9680C11A5C4; // Offset: 0x04 // Size: 0x04
	int WeaponID_3_4C59DA80554AE47019513EF506BFC7B4; // Offset: 0x08 // Size: 0x04
};

