//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Skill_Lobby_Entrance_UIBP.Skill_Lobby_Entrance_UIBP_C
// Size: 0x288 // Inherited bytes: 0x260
struct USkill_Lobby_Entrance_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* Fadein_SkillIcon; // Offset: 0x260 // Size: 0x08
	struct UButton* Button_1; // Offset: 0x268 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_GuideTips; // Offset: 0x270 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Root; // Offset: 0x278 // Size: 0x08
	struct UImage* Image_SkillIcon; // Offset: 0x280 // Size: 0x08
};

