//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AI.AESpawnSubsystem
// Size: 0x1b0 // Inherited bytes: 0x130
struct UAESpawnSubsystem : USTSpawnSubsystem {
	// Fields
	struct FMonsterParams CacheMobParams; // Offset: 0x130 // Size: 0x58
	struct FFakePlayerParams CacheFPParams; // Offset: 0x188 // Size: 0x10
	struct FAIPlayerParams CacheAIPParams; // Offset: 0x198 // Size: 0x0c
	char pad_0x1A4[0xc]; // Offset: 0x1a4 // Size: 0x0c

	// Functions

	// Object Name: Function AI.AESpawnSubsystem.SpawnUnit
	// Flags: [Native|Protected|BlueprintCallable]
	struct AActor* SpawnUnit(struct FSTSpawnParam SpawnParam); // Offset: 0x103e1bdf0 // Return & Params: Num(2) Size(0xa8)

	// Object Name: Function AI.AESpawnSubsystem.PreCheck
	// Flags: [Native|Protected|BlueprintCallable]
	bool PreCheck(); // Offset: 0x103e1bdb4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.AESpawnSubsystem.GetUnitConfigID
	// Flags: [Native|Protected|BlueprintCallable|BlueprintPure|Const]
	int GetUnitConfigID(struct AActor* Unit); // Offset: 0x103e1bd20 // Return & Params: Num(2) Size(0xc)
};

// Object Name: Class AI.AESpawner
// Size: 0x580 // Inherited bytes: 0x550
struct AAESpawner : ASTSpawnerBase {
	// Fields
	char bEnableTeamAI : 1; // Offset: 0x54c // Size: 0x01
	struct TArray<struct UActorComponent*> TeamAIClasses; // Offset: 0x550 // Size: 0x10
	int SpawnerCampItemID; // Offset: 0x560 // Size: 0x04
	int SpawnerTeamID; // Offset: 0x564 // Size: 0x04
	enum class EBotCategray SpeciesCategory; // Offset: 0x568 // Size: 0x01
	char pad_0x569_1 : 7; // Offset: 0x569 // Size: 0x01
	char pad_0x56A[0x6]; // Offset: 0x56a // Size: 0x06
	struct TArray<struct UActorComponent*> TeamAIComponents; // Offset: 0x570 // Size: 0x10

	// Functions

	// Object Name: Function AI.AESpawner.SwitchTeamAI
	// Flags: [Final|Native|Public]
	void SwitchTeamAI(bool bEnable); // Offset: 0x103e1ca48 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.AESpawner.OnUnitSpawned
	// Flags: [Native|Public]
	void OnUnitSpawned(uint32_t InSpawnerID, struct APawn* AIPawn, int ConfigId); // Offset: 0x103e1c94c // Return & Params: Num(3) Size(0x14)

	// Object Name: Function AI.AESpawner.OnSpawnTimingRipe
	// Flags: [Native|Protected]
	void OnSpawnTimingRipe(bool IsRipe); // Offset: 0x103e1c8c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.AESpawner.OnOwnedMobDead
	// Flags: [Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable]
	void OnOwnedMobDead(struct ASTExtraSimpleCharacter* DeadCharacter, struct AController* Killer, struct AActor* DamageCauser, struct FHitResult& KillingHitInfo, struct FVector KillingHitImpulseDir, struct UDamageType* KillingHitDamageType); // Offset: 0x103e1c6c0 // Return & Params: Num(6) Size(0xc8)

	// Object Name: Function AI.AESpawner.OnOwnedFakePlayerDead
	// Flags: [Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable]
	void OnOwnedFakePlayerDead(struct ASTExtraBaseCharacter* DeadCharacter, struct AController* Killer, struct AActor* DamageCauser, struct FHitResult& KillingHitInfo, struct FVector KillingHitImpulseDir, struct UDamageType* KillingHitDamageType); // Offset: 0x103e1c4c0 // Return & Params: Num(6) Size(0xc8)

	// Object Name: Function AI.AESpawner.GetSpeciesCategory
	// Flags: [Final|Native|Public|BlueprintCallable]
	enum class EBotCategray GetSpeciesCategory(); // Offset: 0x103e1c4a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.AESpawner.GetSpawnerTeamID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetSpawnerTeamID(); // Offset: 0x103e1c484 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AI.AESpawner.GenerateParamID
	// Flags: [Event|Public|BlueprintEvent]
	int GenerateParamID(int ConfigId, int BaseParamID); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function AI.AESpawner.DeactivateSpawner
	// Flags: [Native|Public|BlueprintCallable]
	void DeactivateSpawner(); // Offset: 0x103e1c468 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.AESpawner.BPOnUnitSpawned
	// Flags: [Event|Public|BlueprintEvent]
	void BPOnUnitSpawned(struct APawn* AIPawn, int ConfigId); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function AI.AESpawner.ActivateSpawner
	// Flags: [Native|Public|BlueprintCallable]
	void ActivateSpawner(); // Offset: 0x103e1c44c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AI.AIActionExecutionComponent
// Size: 0x200 // Inherited bytes: 0x1d8
struct UAIActionExecutionComponent : ULuaActorComponent {
	// Fields
	struct AController* OwnerController; // Offset: 0x1d8 // Size: 0x08
	struct ANewFakePlayerAIController* MyAIController; // Offset: 0x1e0 // Size: 0x08
	struct ASTExtraPlayerController* MyPlayerController; // Offset: 0x1e8 // Size: 0x08
	struct ASTExtraBaseCharacter* MyPlayerPawn; // Offset: 0x1f0 // Size: 0x08
	struct UMLAIControllerComponent* MyMLAIControllerComp; // Offset: 0x1f8 // Size: 0x08

	// Functions

	// Object Name: Function AI.AIActionExecutionComponent.UseItem
	// Flags: [Final|Native|Public]
	void UseItem(int ItemID, int WeaponSlot); // Offset: 0x103e1e1a4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function AI.AIActionExecutionComponent.SwapAttachmentItem
	// Flags: [Final|Native|Public]
	void SwapAttachmentItem(int ItemID, int SourceWeaponSlot, int TargetWeaponSlot); // Offset: 0x103e1e0b4 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function AI.AIActionExecutionComponent.SetGrenadeLastSelectID
	// Flags: [Final|Native|Public]
	void SetGrenadeLastSelectID(int WeaponID); // Offset: 0x103e1e038 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AI.AIActionExecutionComponent.SetFocusRotation
	// Flags: [Final|Native|Public]
	void SetFocusRotation(float InPitch, float InYaw, float InRoll); // Offset: 0x103e1df48 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function AI.AIActionExecutionComponent.SetCurShootingPose
	// Flags: [Final|Native|Public]
	void SetCurShootingPose(); // Offset: 0x103e1df34 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.AIActionExecutionComponent.RescueTarget
	// Flags: [Final|Native|Public]
	void RescueTarget(struct ASTExtraBaseCharacter* RescueCharacter); // Offset: 0x103e1deb8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AI.AIActionExecutionComponent.OpenDoor
	// Flags: [Final|Native|Public]
	void OpenDoor(); // Offset: 0x103e1dea4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.AIActionExecutionComponent.IsValid
	// Flags: [Final|Native|Public]
	bool IsValid(); // Offset: 0x103e1de70 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.AIActionExecutionComponent.IsFreeCamera
	// Flags: [Final|Native|Public]
	bool IsFreeCamera(); // Offset: 0x103e1de3c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.AIActionExecutionComponent.GetPickActorWithID
	// Flags: [Final|Native|Public]
	struct APickUpWrapperActor* GetPickActorWithID(int UId); // Offset: 0x103e1ddb0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AI.AIActionExecutionComponent.GetOwnerBaseCharacter
	// Flags: [Final|Native|Public]
	struct ASTExtraBaseCharacter* GetOwnerBaseCharacter(); // Offset: 0x103e1dd7c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AI.AIActionExecutionComponent.GetBackpackComponent
	// Flags: [Final|Native|Public]
	struct UBackpackComponent* GetBackpackComponent(); // Offset: 0x103e1dd48 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AI.AIActionExecutionComponent.DropItem
	// Flags: [Final|Native|Public]
	void DropItem(int ItemID, int Count); // Offset: 0x103e1dc94 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function AI.AIActionExecutionComponent.DoActionMove
	// Flags: [Final|Native|Public]
	void DoActionMove(bool IsRun, float DirectionX, float DirectionY, float DirectionZ); // Offset: 0x103e1db58 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function AI.AIActionExecutionComponent.DoActionFreeCamera
	// Flags: [Final|Native|Public]
	void DoActionFreeCamera(bool IsEnter, float InPitch, float InYaw, float InRoll); // Offset: 0x103e1da1c // Return & Params: Num(4) Size(0x10)

	// Object Name: Function AI.AIActionExecutionComponent.DisuseItem
	// Flags: [Final|Native|Public]
	void DisuseItem(int ItemID, int WeaponSlot); // Offset: 0x103e1d968 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function AI.AIActionExecutionComponent.CloseDoor
	// Flags: [Final|Native|Public]
	void CloseDoor(); // Offset: 0x103e1d954 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AI.AIPerceptionDynamicItemComponent
// Size: 0x1f8 // Inherited bytes: 0x1d8
struct UAIPerceptionDynamicItemComponent : ULuaActorComponent {
	// Fields
	int Category; // Offset: 0x1d4 // Size: 0x04
	struct TArray<struct FChildDynamicItem> ChildArray; // Offset: 0x1d8 // Size: 0x10
	DelegateProperty GetDynamicItemDurabilityDelegate; // Offset: 0x1e8 // Size: 0x10
};

// Object Name: Class AI.AISoundCollectionComponent
// Size: 0x358 // Inherited bytes: 0x1d8
struct UAISoundCollectionComponent : ULuaActorComponent {
	// Fields
	struct TMap<uint32_t, struct FCacheSoundState> CacheStepSounds; // Offset: 0x1d8 // Size: 0x50
	struct TMap<uint32_t, struct FCacheSoundState> CacheWeaponSounds; // Offset: 0x228 // Size: 0x50
	struct TMap<uint32_t, struct FCacheSoundState> CacheVehicleSounds; // Offset: 0x278 // Size: 0x50
	struct TMap<uint32_t, struct FCacheSoundState> CacheGrenadeSounds; // Offset: 0x2c8 // Size: 0x50
	char pad_0x318[0x18]; // Offset: 0x318 // Size: 0x18
	float ClearStepSoundTime; // Offset: 0x330 // Size: 0x04
	float ClearWeaponSoundTime; // Offset: 0x334 // Size: 0x04
	float ClearVehicleSoundTime; // Offset: 0x338 // Size: 0x04
	float ClearGrenadeSoundTime; // Offset: 0x33c // Size: 0x04
	int StepSoundMaxNum; // Offset: 0x340 // Size: 0x04
	int WeaponSoundMaxNum; // Offset: 0x344 // Size: 0x04
	int VehicleSoundMaxNum; // Offset: 0x348 // Size: 0x04
	int GrenadeSoundMaxNum; // Offset: 0x34c // Size: 0x04
	struct AController* OwnerController; // Offset: 0x350 // Size: 0x08

	// Functions

	// Object Name: Function AI.AISoundCollectionComponent.OnCollectionHearSound
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void OnCollectionHearSound(enum class ESoundType soundType, struct FVector& InPos, struct AActor* InSourceActor); // Offset: 0x103e1fc9c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AI.AISoundCollectionComponent.GetCollectSoundInfo
	// Flags: [Final|Native|Public]
	struct TArray<struct FSoundState> GetCollectSoundInfo(); // Offset: 0x103e1fc38 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AI.AIStateInfoComponent
// Size: 0xba0 // Inherited bytes: 0x110
struct UAIStateInfoComponent : UActorComponent {
	// Fields
	struct TMap<int, int> ProgressSkillConfig; // Offset: 0x110 // Size: 0x50
	struct TMap<int, bool> AvailableBackpacItemTypes; // Offset: 0x160 // Size: 0x50
	struct TMap<int, int> GrenadeTypeConfig; // Offset: 0x1b0 // Size: 0x50
	float VisibleAngle; // Offset: 0x200 // Size: 0x04
	struct FVector HeadOffset; // Offset: 0x204 // Size: 0x0c
	float NearByEnemyRange; // Offset: 0x210 // Size: 0x04
	float FogWeatherRangeScale; // Offset: 0x214 // Size: 0x04
	int NearByEnemyMaxNum; // Offset: 0x218 // Size: 0x04
	bool IsSearchNearItem; // Offset: 0x21c // Size: 0x01
	char pad_0x21D[0x3]; // Offset: 0x21d // Size: 0x03
	int NearbyItemMaxNum; // Offset: 0x220 // Size: 0x04
	int NearbyMaxBoxNum; // Offset: 0x224 // Size: 0x04
	float NearbyAirDropBoxRangeInner; // Offset: 0x228 // Size: 0x04
	float NearbyAirDropBoxRangeOuter; // Offset: 0x22c // Size: 0x04
	float NearbyDeathBoxRange; // Offset: 0x230 // Size: 0x04
	float NearbyPickUpWrapperRange; // Offset: 0x234 // Size: 0x04
	float CacheNearbyItemRangeCoefficient; // Offset: 0x238 // Size: 0x04
	int NearbyMaxTreasureChestNum; // Offset: 0x23c // Size: 0x04
	float NearbyTreasureChestRange; // Offset: 0x240 // Size: 0x04
	float NearbyFindBuildingRange; // Offset: 0x244 // Size: 0x04
	float ItemStateChangedRange; // Offset: 0x248 // Size: 0x04
	bool IsItemVisiable; // Offset: 0x24c // Size: 0x01
	bool IsUseItemSpotLoc; // Offset: 0x24d // Size: 0x01
	char pad_0x24E[0x2]; // Offset: 0x24e // Size: 0x02
	float NearbyObstacleRange; // Offset: 0x250 // Size: 0x04
	float NearbyThrownRange; // Offset: 0x254 // Size: 0x04
	float NearbySmokeRange; // Offset: 0x258 // Size: 0x04
	int NearbyThrownMaxNum; // Offset: 0x25c // Size: 0x04
	char pad_0x260[0x4]; // Offset: 0x260 // Size: 0x04
	int NearbyDoorMaxNum; // Offset: 0x264 // Size: 0x04
	int NearbyVehicleRange; // Offset: 0x268 // Size: 0x04
	int NearbyVehicleMaxNum; // Offset: 0x26c // Size: 0x04
	float NearbyBulletHoleRange; // Offset: 0x270 // Size: 0x04
	int NearbyBulletHoleMaxNum; // Offset: 0x274 // Size: 0x04
	float NearbyDynamicItemsRange; // Offset: 0x278 // Size: 0x04
	int NearbyDynamicItemsMaxNum; // Offset: 0x27c // Size: 0x04
	struct FAIStateInfo CacheAIStateInfo; // Offset: 0x280 // Size: 0x368
	struct FDiffAIStateInfo CacheDiffAIStateInfo; // Offset: 0x5e8 // Size: 0x458
	struct FRedZoneState CacheRedZoneInfo; // Offset: 0xa40 // Size: 0x18
	float AirAttackTotalTime; // Offset: 0xa58 // Size: 0x04
	bool IsTouchedPlayer; // Offset: 0xa5c // Size: 0x01
	bool bIgnoreTreeAIWhenNoPlayerAround; // Offset: 0xa5d // Size: 0x01
	char pad_0xA5E[0x2]; // Offset: 0xa5e // Size: 0x02
	float IgnoreTreeAIRadius; // Offset: 0xa60 // Size: 0x04
	uint32_t FrameNo; // Offset: 0xa64 // Size: 0x04
	bool IsCacheDiffData; // Offset: 0xa68 // Size: 0x01
	char pad_0xA69[0x7]; // Offset: 0xa69 // Size: 0x07
	struct AController* OwnerController; // Offset: 0xa70 // Size: 0x08
	struct ANewFakePlayerAIController* MyAIController; // Offset: 0xa78 // Size: 0x08
	struct ASTExtraPlayerController* MyPlayerController; // Offset: 0xa80 // Size: 0x08
	struct UAirAttackComponent* AirAttackComp; // Offset: 0xa88 // Size: 0x08
	struct UAIActingComponent* AIActingComp; // Offset: 0xa90 // Size: 0x08
	struct APawn* MyOwnerPawn; // Offset: 0xa98 // Size: 0x08
	struct ABattleRoyaleGameModeBase* MyGameMode; // Offset: 0xaa0 // Size: 0x08
	char pad_0xAA8[0x60]; // Offset: 0xaa8 // Size: 0x60
	struct TArray<struct FVehicleDamageInfo> VehicleDamageInfo; // Offset: 0xb08 // Size: 0x10
	struct TMap<int, struct APickUpWrapperActor*> CacheAINearByItem; // Offset: 0xb18 // Size: 0x50
	struct FCacheNearbyItemState CacheNearbyItemState; // Offset: 0xb68 // Size: 0x20
	struct UMLAIControllerComponent* MyMLAIControllerComp; // Offset: 0xb88 // Size: 0x08
	uint32_t CacheModeMapId; // Offset: 0xb90 // Size: 0x04
	char pad_0xB94[0xc]; // Offset: 0xb94 // Size: 0x0c

	// Functions

	// Object Name: Function AI.AIStateInfoComponent.QueryItemStates
	// Flags: [Final|Native|Public]
	struct TArray<struct FItemStateData> QueryItemStates(int MaxBoxNum, int MaxItemNum, float AirDropBoxRangeInner, float AirDropBoxRangeOuter, float DeathBoxRange, float PickUpWrapperRange, float FindBuildingRange, bool InIsUseItemSpotLoc, int MaxTreasureChestNum, float TreasureChestRange); // Offset: 0x103e21f00 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function AI.AIStateInfoComponent.OnVehicleDamageInfo
	// Flags: [Final|Native|Public]
	void OnVehicleDamageInfo(struct AController* InstigatorController, struct AController* VictimController, int DamageTypeId, float Damage, bool bIsFatalHealthCost, struct AActor* DamageCauser, struct AActor* VictimVehicle); // Offset: 0x103e21d14 // Return & Params: Num(7) Size(0x30)

	// Object Name: Function AI.AIStateInfoComponent.OnItemStateChanged
	// Flags: [Final|Native|Public|HasDefaults]
	void OnItemStateChanged(struct FVector Location); // Offset: 0x103e21c98 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AI.AIStateInfoComponent.OnAIStateRequestEnd
	// Flags: [Final|Native|Public]
	void OnAIStateRequestEnd(); // Offset: 0x103e21c84 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.AIStateInfoComponent.OnAirAttackInfo
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	void OnAirAttackInfo(enum class EAirAttackInfo airattacktype, int waveIndex, struct FAirAttackOrder& InAirAttackOrder, struct FVector& InAirAttackArea); // Offset: 0x103e21ae8 // Return & Params: Num(4) Size(0x64)

	// Object Name: Function AI.AIStateInfoComponent.IsValid
	// Flags: [Final|Native|Private]
	bool IsValid(); // Offset: 0x103e21ab4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.AIStateInfoComponent.IsAvailableBackpacItemType
	// Flags: [Final|Native|Public|Const]
	bool IsAvailableBackpacItemType(struct FItemDefineID DefineID); // Offset: 0x103e21a18 // Return & Params: Num(2) Size(0x19)

	// Object Name: Function AI.AIStateInfoComponent.HasPlayerAround
	// Flags: [Final|Native|Private]
	bool HasPlayerAround(); // Offset: 0x103e219e4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.AIStateInfoComponent.GetViewForwardVector
	// Flags: [Final|Native|Private|HasDefaults]
	struct FVector GetViewForwardVector(struct ACharacter* InCharacter); // Offset: 0x103e21954 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function AI.AIStateInfoComponent.GetVehicleStatus
	// Flags: [Final|Native|Static|Public]
	struct FVehicleState GetVehicleStatus(struct ASTExtraVehicleBase* InVehicle, struct ASTExtraBaseCharacter* PawnInCar); // Offset: 0x103e21878 // Return & Params: Num(3) Size(0xa0)

	// Object Name: Function AI.AIStateInfoComponent.GetTLogAIShootInfo
	// Flags: [Final|Native|Public]
	struct FTLogAIShootInfo GetTLogAIShootInfo(); // Offset: 0x103e21840 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AI.AIStateInfoComponent.GetSoundInfo
	// Flags: [Final|Native|Public]
	struct TArray<struct FSoundState> GetSoundInfo(); // Offset: 0x103e217dc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AI.AIStateInfoComponent.GetProgressBarState
	// Flags: [Final|Native|Public]
	struct FProgressBarState GetProgressBarState(); // Offset: 0x103e21778 // Return & Params: Num(1) Size(0x20)

	// Object Name: Function AI.AIStateInfoComponent.GetPlayerInteractInfo
	// Flags: [Final|Native|Public]
	struct FAIPlayerInteractInfo GetPlayerInteractInfo(); // Offset: 0x103e21714 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function AI.AIStateInfoComponent.GetPickActorWithID
	// Flags: [Final|Native|Public]
	struct APickUpWrapperActor* GetPickActorWithID(int UId); // Offset: 0x103e21688 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AI.AIStateInfoComponent.GetOwnerBaseCharacter
	// Flags: [Final|Native|Private]
	struct ASTExtraBaseCharacter* GetOwnerBaseCharacter(); // Offset: 0x103e21654 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AI.AIStateInfoComponent.GetObstaclesState
	// Flags: [Final|Native|Public]
	struct TArray<struct FObstacleState> GetObstaclesState(float Range); // Offset: 0x103e215a0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AI.AIStateInfoComponent.GetNearbyVehicles
	// Flags: [Final|Native|Public]
	struct TArray<struct FVehicleState> GetNearbyVehicles(struct ASTExtraBaseCharacter* InPawn); // Offset: 0x103e214ec // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AI.AIStateInfoComponent.GetFrameNo
	// Flags: [Final|Native|Private]
	uint32_t GetFrameNo(); // Offset: 0x103e214d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AI.AIStateInfoComponent.GetDoorsState
	// Flags: [Final|Native|Public]
	struct TArray<struct FDoorState> GetDoorsState(float Range, int MaxNum); // Offset: 0x103e213e0 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AI.AIStateInfoComponent.GetDiffAIStateInfo
	// Flags: [Final|Native|Public]
	struct FDiffAIStateInfo GetDiffAIStateInfo(); // Offset: 0x103e2137c // Return & Params: Num(1) Size(0x458)

	// Object Name: Function AI.AIStateInfoComponent.GetDamageSources
	// Flags: [Final|Native|Public]
	struct FAIDamageSources GetDamageSources(); // Offset: 0x103e21318 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function AI.AIStateInfoComponent.GetCameraState
	// Flags: [Final|Native|Public]
	struct FCameraState GetCameraState(struct ASTExtraBaseCharacter* InCharacter); // Offset: 0x103e2127c // Return & Params: Num(2) Size(0x2c)

	// Object Name: Function AI.AIStateInfoComponent.GetAllPlayerStateInfo
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FAIStateInfo> GetAllPlayerStateInfo(struct UWorld* InWorld); // Offset: 0x103e211d8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AI.AIStateInfoComponent.GetAIStateInfoInternal
	// Flags: [Final|Native|Public]
	struct FAIStateInfo GetAIStateInfoInternal(); // Offset: 0x103e21174 // Return & Params: Num(1) Size(0x368)

	// Object Name: Function AI.AIStateInfoComponent.GetAIStateInfo
	// Flags: [Final|Native|Public]
	struct FAIStateInfo GetAIStateInfo(); // Offset: 0x103e21110 // Return & Params: Num(1) Size(0x368)

	// Object Name: Function AI.AIStateInfoComponent.GetAIPlayerBackpackItems
	// Flags: [Final|Native|Public]
	struct TArray<struct FAIBackpackItem> GetAIPlayerBackpackItems(); // Offset: 0x103e210ac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AI.AIStateInfoComponent.GetAINearbyThrownState
	// Flags: [Final|Native|Public]
	struct TArray<struct FAINearbyThrown> GetAINearbyThrownState(struct ASTExtraBaseCharacter* InCharacter, float InRange, float InCheckAngle, int MaxNum, float InSmokeRange); // Offset: 0x103e20f0c // Return & Params: Num(6) Size(0x28)

	// Object Name: Function AI.AIStateInfoComponent.ClearVehicleDamageInfo
	// Flags: [Final|Native|Public]
	void ClearVehicleDamageInfo(); // Offset: 0x103e20ef8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.AIStateInfoComponent.ClearPlayerInteractInfo
	// Flags: [Final|Native|Public]
	void ClearPlayerInteractInfo(); // Offset: 0x103e20ee4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.AIStateInfoComponent.ClearDamageSources
	// Flags: [Final|Native|Public]
	void ClearDamageSources(); // Offset: 0x103e20ed0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AI.CustomDamageEventComponent
// Size: 0x310 // Inherited bytes: 0x1d8
struct UCustomDamageEventComponent : ULuaActorComponent {
	// Fields
	struct FScriptMulticastDelegate OnSpawnActor; // Offset: 0x1d8 // Size: 0x10
	struct UDataTable* EventDataTable; // Offset: 0x1e8 // Size: 0x28
	float ActorSpawnGlobalCooldown; // Offset: 0x210 // Size: 0x04
	char pad_0x214[0x4]; // Offset: 0x214 // Size: 0x04
	struct FScriptMulticastDelegate OnThrowBox; // Offset: 0x218 // Size: 0x10
	char pad_0x228[0x4]; // Offset: 0x228 // Size: 0x04
	float OwnerHealthPercentage; // Offset: 0x22c // Size: 0x04
	char pad_0x230[0x10]; // Offset: 0x230 // Size: 0x10
	struct TArray<struct FTriggeredCustomDamageEvent> ClientEvents; // Offset: 0x240 // Size: 0x10
	char pad_0x250[0x70]; // Offset: 0x250 // Size: 0x70
	struct TMap<struct FName, struct UObject*> CacheUObjectMap; // Offset: 0x2c0 // Size: 0x50

	// Functions

	// Object Name: Function AI.CustomDamageEventComponent.OnRep_ClientEvents
	// Flags: [Final|Native|Protected]
	void OnRep_ClientEvents(); // Offset: 0x103e24918 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AI.CharacterCustomDamageEventComponent
// Size: 0x318 // Inherited bytes: 0x310
struct UCharacterCustomDamageEventComponent : UCustomDamageEventComponent {
	// Fields
	char pad_0x310[0x8]; // Offset: 0x310 // Size: 0x08

	// Functions

	// Object Name: Function AI.CharacterCustomDamageEventComponent.OnTakeDamageEvent
	// Flags: [Final|Native|Public|HasOutParms]
	void OnTakeDamageEvent(float Damage, struct FDamageEvent& DamageEvent, struct AActor* Victim, struct AActor* Causer); // Offset: 0x103e24048 // Return & Params: Num(4) Size(0x28)
};

// Object Name: Class AI.MLAIControllerComponent
// Size: 0x300 // Inherited bytes: 0x110
struct UMLAIControllerComponent : UActorComponent {
	// Fields
	struct UActorComponent* AIActionExcutionCompClass; // Offset: 0x110 // Size: 0x08
	struct UActorComponent* AISoundCollectCompClass; // Offset: 0x118 // Size: 0x08
	struct UActorComponent* AIStateInfoCompClass; // Offset: 0x120 // Size: 0x08
	struct UAIActionExecutionComponent* AIActionExecutionComp; // Offset: 0x128 // Size: 0x08
	struct UAIStateInfoComponent* AIStateInfoComp; // Offset: 0x130 // Size: 0x08
	struct UAISoundCollectionComponent* AISoundCollectComp; // Offset: 0x138 // Size: 0x08
	float HearRadius; // Offset: 0x140 // Size: 0x04
	char pad_0x144[0x4]; // Offset: 0x144 // Size: 0x04
	struct TMap<enum class ESTEPoseState, struct FCameraViewPitchLimitData> CameraViewPitchLimitDataMap; // Offset: 0x148 // Size: 0x50
	struct FVector PrePos; // Offset: 0x198 // Size: 0x0c
	float PreTickTime; // Offset: 0x1a4 // Size: 0x04
	struct AController* OwnerController; // Offset: 0x1a8 // Size: 0x08
	struct ANewFakePlayerAIController* MyAIController; // Offset: 0x1b0 // Size: 0x08
	struct ASTExtraPlayerController* MyPlayerController; // Offset: 0x1b8 // Size: 0x08
	char pad_0x1C0[0x14]; // Offset: 0x1c0 // Size: 0x14
	float FindNavLocationRadius; // Offset: 0x1d4 // Size: 0x04
	int MaxNavLocationFindTimes; // Offset: 0x1d8 // Size: 0x04
	bool bUseLerpRotation; // Offset: 0x1dc // Size: 0x01
	char pad_0x1DD[0x3]; // Offset: 0x1dd // Size: 0x03
	float LerpRotationThreshold; // Offset: 0x1e0 // Size: 0x04
	bool IsForceTargetRotation; // Offset: 0x1e4 // Size: 0x01
	char pad_0x1E5[0x3]; // Offset: 0x1e5 // Size: 0x03
	float FirstLerpRotationDeltaTime; // Offset: 0x1e8 // Size: 0x04
	float FreeCameraTurnVelocity; // Offset: 0x1ec // Size: 0x04
	float TurnVelocity; // Offset: 0x1f0 // Size: 0x04
	char pad_0x1F4[0x4]; // Offset: 0x1f4 // Size: 0x04
	struct FAIShootingPoseOffsetInfo shootingPoseOffsetInfo; // Offset: 0x1f8 // Size: 0x70
	float AutoOpenDoorRange; // Offset: 0x268 // Size: 0x04
	char pad_0x26C[0x8]; // Offset: 0x26c // Size: 0x08
	bool IsModifyDamageLuaOverride; // Offset: 0x274 // Size: 0x01
	char pad_0x275[0x3]; // Offset: 0x275 // Size: 0x03
	float RatingDamageScaleLuaOverride; // Offset: 0x278 // Size: 0x04
	bool bShouldSendVehicleInfo; // Offset: 0x27c // Size: 0x01
	char pad_0x27D[0x1b]; // Offset: 0x27d // Size: 0x1b
	bool IsChangeStatePC; // Offset: 0x298 // Size: 0x01
	char pad_0x299[0x67]; // Offset: 0x299 // Size: 0x67

	// Functions

	// Object Name: Function AI.MLAIControllerComponent.UnBindDelegates
	// Flags: [Final|Native|Public]
	void UnBindDelegates(bool IsEndPlay); // Offset: 0x103e257b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.MLAIControllerComponent.SetLuaAIParamConfigString
	// Flags: [Final|Native|Public]
	void SetLuaAIParamConfigString(struct FString InAIParamConfigString); // Offset: 0x103e256fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AI.MLAIControllerComponent.SetCurShootingPose
	// Flags: [Final|Native|Public]
	void SetCurShootingPose(enum class EAIShootingPose InCurAIShootingPose); // Offset: 0x103e25680 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.MLAIControllerComponent.RestartFightBehaviorTree
	// Flags: [Final|Native|Public]
	void RestartFightBehaviorTree(); // Offset: 0x103e2566c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.MLAIControllerComponent.IsValid
	// Flags: [Final|Native|Public]
	bool IsValid(); // Offset: 0x103e25638 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.MLAIControllerComponent.IsFreeCamera
	// Flags: [Final|Native|Public]
	bool IsFreeCamera(); // Offset: 0x103e25604 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.MLAIControllerComponent.GetViewRotation
	// Flags: [Final|Native|Public|HasDefaults]
	struct FRotator GetViewRotation(); // Offset: 0x103e255cc // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AI.MLAIControllerComponent.GetViewForwardVector
	// Flags: [Final|Native|Public|HasDefaults]
	struct FVector GetViewForwardVector(); // Offset: 0x103e25594 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AI.MLAIControllerComponent.GetOwnerBaseCharacter
	// Flags: [Final|Native|Public]
	struct ASTExtraBaseCharacter* GetOwnerBaseCharacter(); // Offset: 0x103e25560 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AI.MLAIControllerComponent.GetBackpackComponent
	// Flags: [Final|Native|Public]
	struct UBackpackComponent* GetBackpackComponent(); // Offset: 0x103e2552c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AI.MLAIControllerComponent.GetAIStateInfoComp
	// Flags: [Final|Native|Public|Const]
	struct UAIStateInfoComponent* GetAIStateInfoComp(); // Offset: 0x103e25510 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AI.MLAIControllerComponent.GetAIActionExecutionComp
	// Flags: [Final|Native|Public|Const]
	struct UAIActionExecutionComponent* GetAIActionExecutionComp(); // Offset: 0x103e254f4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AI.MLAIControllerComponent.DoActionFreeCamera
	// Flags: [Final|Native|Public]
	void DoActionFreeCamera(bool IsEnter, float InPitch, float InYaw, float InRoll); // Offset: 0x103e253b8 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function AI.MLAIControllerComponent.CheckCameraViewPitchLimit
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	bool CheckCameraViewPitchLimit(struct FRotator& InOutTargetRot); // Offset: 0x103e25320 // Return & Params: Num(2) Size(0xd)

	// Object Name: Function AI.MLAIControllerComponent.BindDelegates
	// Flags: [Final|Native|Public]
	void BindDelegates(); // Offset: 0x103e2530c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AI.MLAISubSystem
// Size: 0x448 // Inherited bytes: 0x30
struct UMLAISubSystem : UWorldSubsystem {
	// Fields
	struct FScriptMulticastDelegate OnAIStateRequestEnd; // Offset: 0x30 // Size: 0x10
	struct TMap<uint32_t, struct FAIPlayerState> CacheAIPlayerStates; // Offset: 0x40 // Size: 0x50
	struct TMap<uint32_t, struct FAIPlayerInteractInfo> CachePlayerDamageInfo; // Offset: 0x90 // Size: 0x50
	struct TMap<uint32_t, struct FVehicleDamageInfoContainer> CacheVehicleDamageInfo; // Offset: 0xe0 // Size: 0x50
	int MaxCacheDamageInfoNum; // Offset: 0x130 // Size: 0x04
	char pad_0x134[0x4]; // Offset: 0x134 // Size: 0x04
	struct TMap<uint32_t, struct FAIPlayerWeapon> CacheAIPlayerWeapons; // Offset: 0x138 // Size: 0x50
	struct TMap<uint32_t, struct FAIPlayerEquipment> CacheAIPlayerEquipments; // Offset: 0x188 // Size: 0x50
	struct TArray<struct UAIStateInfoComponent*> AIStateInfoComps; // Offset: 0x1d8 // Size: 0x10
	struct TArray<struct FBulletHoleRecordInfo> CacheBulletHoles; // Offset: 0x1e8 // Size: 0x10
	struct TArray<struct FSpecialZoneState> CacheSpecialZones; // Offset: 0x1f8 // Size: 0x10
	struct TMap<uint32_t, struct FDiffAIPlayerState> CacheDiffAIPlayerStates; // Offset: 0x208 // Size: 0x50
	struct TMap<uint32_t, struct FDiffAIPlayerWeapon> CacheDiffAIPlayerWeapons; // Offset: 0x258 // Size: 0x50
	struct TMap<uint32_t, struct FDiffAIPlayerEquipment> CacheDiffAIPlayerEquipments; // Offset: 0x2a8 // Size: 0x50
	struct TMap<uint32_t, bool> CacheDiffAIPlayerStatesRet; // Offset: 0x2f8 // Size: 0x50
	struct TMap<uint32_t, bool> CacheDiffAIPlayerWeaponsRet; // Offset: 0x348 // Size: 0x50
	struct TMap<uint32_t, bool> CacheDiffAIPlayerEquipmentsRet; // Offset: 0x398 // Size: 0x50
	char pad_0x3E8[0x10]; // Offset: 0x3e8 // Size: 0x10
	struct TMap<struct AActor*, struct ASpecialZoneActor*> CacheSpecialZoneParents; // Offset: 0x3f8 // Size: 0x50

	// Functions

	// Object Name: Function AI.MLAISubSystem.StartRequestCache
	// Flags: [Final|Native|Public]
	void StartRequestCache(); // Offset: 0x103e33b8c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.MLAISubSystem.SetSpecialZoneCustomState
	// Flags: [Final|Native|Public]
	void SetSpecialZoneCustomState(struct AActor* InParent, int InCustomState); // Offset: 0x103e33ad4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function AI.MLAISubSystem.OnVehicleDamageInfo
	// Flags: [Final|Native|Public]
	void OnVehicleDamageInfo(struct AController* InstigatorController, struct AController* VictimController, int DamageTypeId, float Damage, bool bIsFatalHealthCost, struct AActor* DamageCauser, struct AActor* VictimVehicle); // Offset: 0x103e338e8 // Return & Params: Num(7) Size(0x30)

	// Object Name: Function AI.MLAISubSystem.OnPlayerDamageInfo
	// Flags: [Final|Native|Public|HasOutParms]
	void OnPlayerDamageInfo(struct ASTExtraPlayerState* InstigatorPlayerState, struct ASTExtraPlayerState* VictimPlayerState, float Damage, struct FDamageEvent& DamageEvent, float DamageBeforeCalArmor, bool bIsFatalHealthCost, struct AActor* DamageCauser); // Offset: 0x103e336d8 // Return & Params: Num(7) Size(0x38)

	// Object Name: Function AI.MLAISubSystem.OnItemStateChanged
	// Flags: [Final|Native|Public|HasDefaults]
	void OnItemStateChanged(struct FVector Location); // Offset: 0x103e3365c // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AI.MLAISubSystem.IsAIBotGame
	// Flags: [Final|Native|Public]
	bool IsAIBotGame(); // Offset: 0x103e33628 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.MLAISubSystem.EndRequestCache
	// Flags: [Final|Native|Public]
	void EndRequestCache(); // Offset: 0x103e33614 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AI.MLAITrainingComponent
// Size: 0x148 // Inherited bytes: 0x110
struct UMLAITrainingComponent : UActorComponent {
	// Fields
	bool IsBeginRequestAIState; // Offset: 0x110 // Size: 0x01
	bool IsEndRequestAIState; // Offset: 0x111 // Size: 0x01
	bool bPauseGameAfterSendPacket; // Offset: 0x112 // Size: 0x01
	char pad_0x113[0x5]; // Offset: 0x113 // Size: 0x05
	struct APlayerState* PauseGamePlayerState; // Offset: 0x118 // Size: 0x08
	bool bIsPausing; // Offset: 0x120 // Size: 0x01
	char pad_0x121[0x27]; // Offset: 0x121 // Size: 0x27

	// Functions

	// Object Name: Function AI.MLAITrainingComponent.StopRunnable
	// Flags: [Final|Native|Public]
	void StopRunnable(); // Offset: 0x103e3549c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.MLAITrainingComponent.SetPauseGamePlayerState
	// Flags: [Final|Native|Public]
	void SetPauseGamePlayerState(struct APlayerState* InPlayerState); // Offset: 0x103e35420 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AI.MLAITrainingComponent.SetPause
	// Flags: [Final|Native|Public]
	bool SetPause(bool bInPause, float InPauseTime); // Offset: 0x103e35350 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function AI.MLAITrainingComponent.SendAIStateRequest
	// Flags: [Final|Native|Public]
	void SendAIStateRequest(struct TArray<char> Packet); // Offset: 0x103e3526c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AI.MLAITrainingComponent.IsRequestAIState
	// Flags: [Final|Native|Public]
	bool IsRequestAIState(); // Offset: 0x103e35238 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.MLAITrainingComponent.InitRunnable
	// Flags: [Final|Native|Public]
	void InitRunnable(float InStartCollectingInterval, float InSendInterval, float InTimeOutInterval); // Offset: 0x103e35148 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function AI.MLAITrainingComponent.EndRequestAIState
	// Flags: [Final|Native|Public]
	void EndRequestAIState(); // Offset: 0x103e35134 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AI.STStrategyLocation_Range
// Size: 0x140 // Inherited bytes: 0x100
struct USTStrategyLocation_Range : USTStrategyLocation {
	// Fields
	char bUseNavmesh : 1; // Offset: 0x100 // Size: 0x01
	char pad_0x100_1 : 7; // Offset: 0x100 // Size: 0x01
	char pad_0x101[0x3]; // Offset: 0x101 // Size: 0x03
	float Range; // Offset: 0x104 // Size: 0x04
	int MaxTryTimes; // Offset: 0x108 // Size: 0x04
	char bCheckPlayerSight : 1; // Offset: 0x10c // Size: 0x01
	char pad_0x10C_1 : 7; // Offset: 0x10c // Size: 0x01
	char pad_0x10D[0x3]; // Offset: 0x10d // Size: 0x03
	float PlayerViewDistance; // Offset: 0x110 // Size: 0x04
	enum class ECollisionChannel CollisionChannel; // Offset: 0x114 // Size: 0x01
	char pad_0x115[0x3]; // Offset: 0x115 // Size: 0x03
	float MaxLocationTraceHeightZ; // Offset: 0x118 // Size: 0x04
	char pad_0x11C[0x4]; // Offset: 0x11c // Size: 0x04
	struct TArray<struct FSpawnArea> CustomAreas; // Offset: 0x120 // Size: 0x10
	char pad_0x130[0x10]; // Offset: 0x130 // Size: 0x10

	// Functions

	// Object Name: Function AI.STStrategyLocation_Range.ModifyBaseLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void ModifyBaseLocation(struct FVector InLocation); // Offset: 0x103e35cf4 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AI.STStrategyLocation_Range.GetSpawnLocation
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool GetSpawnLocation(struct AActor* Requester, int ReferenceCount, struct TArray<struct FSpawnSpotInfo>& OutArr); // Offset: 0x103e35bbc // Return & Params: Num(4) Size(0x21)

	// Object Name: Function AI.STStrategyLocation_Range.AddSpawnArea
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddSpawnArea(struct FSpawnArea NewArea, bool ForceAdd); // Offset: 0x103e35ac8 // Return & Params: Num(2) Size(0x21)

	// Object Name: Function AI.STStrategyLocation_Range.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void ActivateStrategy(struct ASTSpawnerBase* Owner); // Offset: 0x103e35a44 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class AI.STStrategySpecies_Candidate
// Size: 0x110 // Inherited bytes: 0x110
struct USTStrategySpecies_Candidate : USTStrategySpecies {
	// Functions

	// Object Name: Function AI.STStrategySpecies_Candidate.Supply
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	struct TArray<struct FUnitConfig> Supply(int ReferencedCount, struct TArray<struct FSpawnSpotInfo>& SpotSpecies); // Offset: 0x103e362f8 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function AI.STStrategySpecies_Candidate.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void ActivateStrategy(struct ASTSpawnerBase* Owner); // Offset: 0x103e36274 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class AI.STStrategySpecies_Lua
// Size: 0x110 // Inherited bytes: 0x110
struct USTStrategySpecies_Lua : USTStrategySpecies {
	// Functions

	// Object Name: Function AI.STStrategySpecies_Lua.Supply
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	struct TArray<struct FUnitConfig> Supply(int ReferencedCount, struct TArray<struct FSpawnSpotInfo>& SpotSpecies); // Offset: 0x103e36928 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function AI.STStrategySpecies_Lua.LuaSupply
	// Flags: [Event|Public|BlueprintEvent]
	void LuaSupply(int ReferencedCount); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class AI.STStrategyTiming_Event
// Size: 0x110 // Inherited bytes: 0xf0
struct USTStrategyTiming_Event : USTStrategyTiming {
	// Fields
	struct FString EventId; // Offset: 0xf0 // Size: 0x10
	struct FString EventName; // Offset: 0x100 // Size: 0x10

	// Functions

	// Object Name: Function AI.STStrategyTiming_Event.TickStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void TickStrategy(float DeltaTime); // Offset: 0x103e36f48 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AI.STStrategyTiming_Event.OnSpawnEventBroadcast
	// Flags: [Final|Native|Public]
	void OnSpawnEventBroadcast(); // Offset: 0x103e36f34 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.STStrategyTiming_Event.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void ActivateStrategy(struct ASTSpawnerBase* Owner); // Offset: 0x103e36eb0 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class AI.SpecialZoneShapeComponent
// Size: 0x770 // Inherited bytes: 0x770
struct USpecialZoneShapeComponent : UPrimitiveComponent {
	// Fields
	float SphereRadius; // Offset: 0x768 // Size: 0x04
};

// Object Name: Class AI.SpecialZoneActor
// Size: 0x410 // Inherited bytes: 0x3f0
struct ASpecialZoneActor : AActor {
	// Fields
	int ZoneID; // Offset: 0x3ec // Size: 0x04
	float Radius; // Offset: 0x3f0 // Size: 0x04
	int Type; // Offset: 0x3f4 // Size: 0x04
	int CustomState; // Offset: 0x3f8 // Size: 0x04
	struct USpecialZoneShapeComponent* SpecialZoneShapeComponent; // Offset: 0x400 // Size: 0x08
	struct AActor* CacheParentActor; // Offset: 0x408 // Size: 0x08

	// Functions

	// Object Name: Function AI.SpecialZoneActor.UpdateCustomState
	// Flags: [Final|Native|Public]
	void UpdateCustomState(int InCustomState); // Offset: 0x103e3759c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AI.SpecialZoneActor.GetSpecialZoneState
	// Flags: [Final|Native|Public]
	struct FSpecialZoneState GetSpecialZoneState(); // Offset: 0x103e37544 // Return & Params: Num(1) Size(0x34)
};

// Object Name: Class AI.VehicleAIUserComponent
// Size: 0x228 // Inherited bytes: 0x228
struct UVehicleAIUserComponent : UVehicleUserComponentBase {
	// Functions

	// Object Name: Function AI.VehicleAIUserComponent.ServerVehicleLeanOut
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ServerVehicleLeanOut(bool bLeanOut); // Offset: 0x103e3882c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.VehicleAIUserComponent.ServerExitVehicle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ServerExitVehicle(); // Offset: 0x103e38818 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.VehicleAIUserComponent.ServerEnterVehicle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ServerEnterVehicle(struct ASTExtraVehicleBase* InVehicle, char SeatType); // Offset: 0x103e38760 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function AI.VehicleAIUserComponent.ServerChangeVehicleSeat
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ServerChangeVehicleSeat(int InSeatIndex); // Offset: 0x103e386e4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AI.VehicleAIUserComponent.MulticastExitVehicle
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void MulticastExitVehicle(); // Offset: 0x103e386c8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.VehicleAIUserComponent.MulticastEnterVehicle
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void MulticastEnterVehicle(struct ASTExtraVehicleBase* InVehicle, struct ASTExtraPlayerCharacter* Pawn, bool bSuccess, char SeatType, int SeatIndex); // Offset: 0x103e38548 // Return & Params: Num(5) Size(0x18)

	// Object Name: Function AI.VehicleAIUserComponent.MulticastChangeVehicleSeat
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void MulticastChangeVehicleSeat(int InSeatIndex); // Offset: 0x103e384c4 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class AI.VehicleCustomDamageEventComponent
// Size: 0x318 // Inherited bytes: 0x310
struct UVehicleCustomDamageEventComponent : UCustomDamageEventComponent {
	// Fields
	char pad_0x310[0x8]; // Offset: 0x310 // Size: 0x08

	// Functions

	// Object Name: Function AI.VehicleCustomDamageEventComponent.OnVehicleHPFuelChanged
	// Flags: [Final|Native|Public]
	void OnVehicleHPFuelChanged(float HP, float Fuel); // Offset: 0x103e38e78 // Return & Params: Num(2) Size(0x8)
};

