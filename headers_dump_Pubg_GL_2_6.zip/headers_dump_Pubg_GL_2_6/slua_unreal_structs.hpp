//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct slua_unreal.LuaNetSerialization
// Size: 0x50 // Inherited bytes: 0x00
struct FLuaNetSerialization {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct slua_unreal.unctionProfileInfo
// Size: 0x60 // Inherited bytes: 0x00
struct FunctionProfileInfo {
	// Fields
	struct FString FunctionName; // Offset: 0x00 // Size: 0x10
	struct FString brevName; // Offset: 0x10 // Size: 0x10
	int64_t begTime; // Offset: 0x20 // Size: 0x08
	int64_t EndTime; // Offset: 0x28 // Size: 0x08
	int64_t costTime; // Offset: 0x30 // Size: 0x08
	int64_t mergedCostTime; // Offset: 0x38 // Size: 0x08
	int globalIdx; // Offset: 0x40 // Size: 0x04
	int layerIdx; // Offset: 0x44 // Size: 0x04
	int mergedNum; // Offset: 0x48 // Size: 0x04
	bool beMerged; // Offset: 0x4c // Size: 0x01
	bool isDuplicated; // Offset: 0x4d // Size: 0x01
	char pad_0x4E[0x2]; // Offset: 0x4e // Size: 0x02
	struct TArray<int> mergeIdxArray; // Offset: 0x50 // Size: 0x10
};

// Object Name: ScriptStruct slua_unreal.unctionProfileCallInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FunctionProfileCallInfo {
	// Fields
	struct FString FunctionName; // Offset: 0x00 // Size: 0x10
	int64_t begTime; // Offset: 0x10 // Size: 0x08
	bool bIsCoroutineBegin; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x17]; // Offset: 0x19 // Size: 0x17
};

// Object Name: ScriptStruct slua_unreal.unctionProfileNode
// Size: 0x30 // Inherited bytes: 0x00
struct FunctionProfileNode {
	// Fields
	struct FString FunctionName; // Offset: 0x00 // Size: 0x10
	int64_t costTime; // Offset: 0x10 // Size: 0x08
	int countOfCalls; // Offset: 0x18 // Size: 0x04
	int layerIdx; // Offset: 0x1c // Size: 0x04
	char pad_0x20[0x10]; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct slua_unreal.ProflierMemNode
// Size: 0xa8 // Inherited bytes: 0x00
struct FProflierMemNode {
	// Fields
	char pad_0x0[0xa8]; // Offset: 0x00 // Size: 0xa8
};

// Object Name: ScriptStruct slua_unreal.ileMemInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FileMemInfo {
	// Fields
	struct FString hint; // Offset: 0x00 // Size: 0x10
	struct FString LineNumber; // Offset: 0x10 // Size: 0x10
	float Size; // Offset: 0x20 // Size: 0x04
	float difference; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct slua_unreal.ProfileNodeArray
// Size: 0x10 // Inherited bytes: 0x00
struct FProfileNodeArray {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct slua_unreal.SluaBPVar
// Size: 0x20 // Inherited bytes: 0x00
struct FSluaBPVar {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

