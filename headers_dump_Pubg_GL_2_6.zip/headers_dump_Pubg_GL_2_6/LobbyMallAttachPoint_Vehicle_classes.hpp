//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass LobbyMallAttachPoint_Vehicle.LobbyMallAttachPoint_Vehicle_C
// Size: 0x28 // Inherited bytes: 0x28
struct ULobbyMallAttachPoint_Vehicle_C : UInterface {
	// Functions

	// Object Name: Function LobbyMallAttachPoint_Vehicle.LobbyMallAttachPoint_Vehicle_C.NewFunction_1
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void NewFunction_1(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)
};

