//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Popularity_Rank_Icon_UIBP.Popularity_Rank_Icon_UIBP_C
// Size: 0x300 // Inherited bytes: 0x2d0
struct UPopularity_Rank_Icon_UIBP_C : ULuaUserWidget {
	// Fields
	struct UButton* Button_1; // Offset: 0x2d0 // Size: 0x08
	struct UImage* Image_15; // Offset: 0x2d8 // Size: 0x08
	struct UImage* Image_18; // Offset: 0x2e0 // Size: 0x08
	struct UImage* Image_Rank; // Offset: 0x2e8 // Size: 0x08
	struct UImage* Image_Sweep_Light; // Offset: 0x2f0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_3; // Offset: 0x2f8 // Size: 0x08
};

