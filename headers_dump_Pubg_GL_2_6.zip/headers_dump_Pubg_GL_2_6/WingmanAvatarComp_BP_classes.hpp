//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass WingmanAvatarComp_BP.WingmanAvatarComp_BP_C
// Size: 0x438 // Inherited bytes: 0x438
struct UWingmanAvatarComp_BP_C : UWingmanAvatarComponent {
	// Functions

	// Object Name: Function WingmanAvatarComp_BP.WingmanAvatarComp_BP_C.CreateItemAvatarHandle
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void CreateItemAvatarHandle(int ItemID, struct UBattleItemHandleBase*& ItemHandle); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function WingmanAvatarComp_BP.WingmanAvatarComp_BP_C.GetWingmanAvatarHandle
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	struct UBackpackWingmanAvatarHandle* GetWingmanAvatarHandle(int ItemID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)
};

