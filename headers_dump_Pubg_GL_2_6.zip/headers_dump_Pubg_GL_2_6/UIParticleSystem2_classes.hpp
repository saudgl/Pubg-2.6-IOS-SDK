//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class UIParticleSystem2.ParticleSystemWidget2
// Size: 0x138 // Inherited bytes: 0x100
struct UParticleSystemWidget2 : UWidget {
	// Fields
	struct UObject* ParticleSystemTemplate; // Offset: 0x100 // Size: 0x08
	enum class UIMeshProjectionMethod ProjectionMethod; // Offset: 0x108 // Size: 0x01
	char pad_0x109[0x3]; // Offset: 0x109 // Size: 0x03
	float FieldOfView; // Offset: 0x10c // Size: 0x04
	float DistanceToCamera; // Offset: 0x110 // Size: 0x04
	bool bAutoActivate; // Offset: 0x114 // Size: 0x01
	bool bActivate; // Offset: 0x115 // Size: 0x01
	char pad_0x116[0x2]; // Offset: 0x116 // Size: 0x02
	struct UFXSystemComponent* WorldParticleComponent; // Offset: 0x118 // Size: 0x08
	struct AActor* WorldParticleActor; // Offset: 0x120 // Size: 0x08
	char pad_0x128[0x10]; // Offset: 0x128 // Size: 0x10

	// Functions

	// Object Name: Function UIParticleSystem2.ParticleSystemWidget2.SetParticleSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetParticleSystem(struct UParticleSystem* ParticleSystem); // Offset: 0x1022ed9ac // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UIParticleSystem2.ParticleSystemWidget2.SetNiagaraSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNiagaraSystem(struct UNiagaraSystem* ParticleSystem); // Offset: 0x1022ed930 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UIParticleSystem2.ParticleSystemWidget2.SetActivate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetActivate(bool bIsActivate); // Offset: 0x1022ed8ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UIParticleSystem2.ParticleSystemWidget2.GetParticleComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UParticleSystemComponent* GetParticleComponent(); // Offset: 0x1022ed878 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UIParticleSystem2.ParticleSystemWidget2.GetNiagaraComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UNiagaraComponent* GetNiagaraComponent(); // Offset: 0x1022ed844 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UIParticleSystem2.UIParticleSystemComponent
// Size: 0xa40 // Inherited bytes: 0xa30
struct UUIParticleSystemComponent : UParticleSystemComponent {
	// Fields
	char pad_0xA30[0x10]; // Offset: 0xa30 // Size: 0x10
};

// Object Name: Class UIParticleSystem2.UINiagaraComponent
// Size: 0x950 // Inherited bytes: 0x930
struct UUINiagaraComponent : UNiagaraComponent {
	// Fields
	char pad_0x930[0x20]; // Offset: 0x930 // Size: 0x20
};

