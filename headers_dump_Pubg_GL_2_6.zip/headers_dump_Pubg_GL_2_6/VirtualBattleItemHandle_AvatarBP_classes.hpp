//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass VirtualBattleItemHandle_AvatarBP.VirtualBattleItemHandle_AvatarBP_C
// Size: 0xb40 // Inherited bytes: 0xb32
struct UVirtualBattleItemHandle_AvatarBP_C : UBattleItemHandle_AvatarBP_C {
	// Fields
	char pad_0xB32[0x6]; // Offset: 0xb32 // Size: 0x06
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xb38 // Size: 0x08

	// Functions

	// Object Name: Function VirtualBattleItemHandle_AvatarBP.VirtualBattleItemHandle_AvatarBP_C.GetWrapperClass
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetWrapperClass(struct APickUpWrapperActor*& WrapperClass); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function VirtualBattleItemHandle_AvatarBP.VirtualBattleItemHandle_AvatarBP_C.Constuct
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void Constuct(struct FItemDefineID& InDefineID); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function VirtualBattleItemHandle_AvatarBP.VirtualBattleItemHandle_AvatarBP_C.ExecuteUbergraph_VirtualBattleItemHandle_AvatarBP
	// Flags: [HasDefaults]
	void ExecuteUbergraph_VirtualBattleItemHandle_AvatarBP(int EntryPoint); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)
};

