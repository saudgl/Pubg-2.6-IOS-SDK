//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ClientNet.GCloudNet
// Size: 0x3b0 // Inherited bytes: 0x28
struct UGCloudNet : UObject {
	// Fields
	char pad_0x28[0x230]; // Offset: 0x28 // Size: 0x230
	struct UGCloudSDK* _GCloudSDKInst; // Offset: 0x258 // Size: 0x08
	struct FScriptMulticastDelegate StartTickNetPackageDelegate; // Offset: 0x260 // Size: 0x10
	char pad_0x270[0x140]; // Offset: 0x270 // Size: 0x140

	// Functions

	// Object Name: Function ClientNet.GCloudNet.SetTickNetMsgMaxTime
	// Flags: [Final|Native|Private]
	void SetTickNetMsgMaxTime(float MaxTime); // Offset: 0x103cb0110 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ClientNet.GCloudNet.OnWebviewNotify
	// Flags: [Final|Native|Private|HasOutParms]
	void OnWebviewNotify(struct FWebviewInfoWrapper& webviewinfo); // Offset: 0x103cb0064 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function ClientNet.GCloudNet.OnUAAssistantNotify
	// Flags: [Final|Native|Private|HasOutParms]
	void OnUAAssistantNotify(struct FUAAssistantInfoWrapper& uaAssistantInfo); // Offset: 0x103caffb4 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function ClientNet.GCloudNet.OnTraceCallBack
	// Flags: [Final|Native|Private]
	void OnTraceCallBack(int code, struct FString dataJson); // Offset: 0x103cafeb8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function ClientNet.GCloudNet.OnTConndAuthFailDelegate
	// Flags: [Final|Native|Private]
	void OnTConndAuthFailDelegate(); // Offset: 0x103cafea4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.GCloudNet.OnShareNotify
	// Flags: [Final|Native|Private]
	void OnShareNotify(int Result, int PlatForm); // Offset: 0x103cafdf0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function ClientNet.GCloudNet.OnRequestPermissionsResult
	// Flags: [Final|Native|Private]
	void OnRequestPermissionsResult(int code, struct FString permission, struct FString grantResult); // Offset: 0x103cafc7c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function ClientNet.GCloudNet.OnReceiveDataNotify
	// Flags: [Final|Native|Private]
	void OnReceiveDataNotify(int Result, struct TArray<char> Msg); // Offset: 0x103cafb58 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function ClientNet.GCloudNet.OnQuickLoginNotify
	// Flags: [Final|Native|Private|HasOutParms]
	void OnQuickLoginNotify(struct FWakeupInfoWrapper& wakeupinfo); // Offset: 0x103cafaac // Return & Params: Num(1) Size(0x50)

	// Object Name: Function ClientNet.GCloudNet.OnQRCodeGenQRImg
	// Flags: [Final|Native|Private]
	void OnQRCodeGenQRImg(int Tag, int Ret, struct FString imgPath); // Offset: 0x103caf99c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function ClientNet.GCloudNet.OnMigrateNotify
	// Flags: [Final|Native|Private]
	void OnMigrateNotify(int Result); // Offset: 0x103caf920 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ClientNet.GCloudNet.OnLaunchInfo
	// Flags: [Final|Native|Private]
	void OnLaunchInfo(struct FString roominfo); // Offset: 0x103caf888 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ClientNet.GCloudNet.OnIGShareUploadFinished
	// Flags: [Final|Native|Private]
	void OnIGShareUploadFinished(int Result, struct FString PlatForm); // Offset: 0x103caf7b4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function ClientNet.GCloudNet.OnGroupNotify
	// Flags: [Final|Native|Private|HasOutParms]
	void OnGroupNotify(struct FGroupInfoWrapper& groupInfo); // Offset: 0x103caf704 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function ClientNet.GCloudNet.OnGetWebviewActionNotify
	// Flags: [Final|Native|Private]
	void OnGetWebviewActionNotify(struct FString webviewinfo); // Offset: 0x103caf648 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ClientNet.GCloudNet.OnGetTicketNotify
	// Flags: [Final|Native|Private]
	void OnGetTicketNotify(struct FString TicketInfo); // Offset: 0x103caf58c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ClientNet.GCloudNet.OnGetShortUrlNotify
	// Flags: [Final|Native|Private|HasOutParms]
	void OnGetShortUrlNotify(struct FShortURLInfoWrapper& shorturlinfo); // Offset: 0x103caf4e0 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function ClientNet.GCloudNet.OnGetPlatformFriendsNotify
	// Flags: [Final|Native|Private|HasOutParms]
	void OnGetPlatformFriendsNotify(struct FPlatformFriendInfoMap& platformFriends); // Offset: 0x103caf424 // Return & Params: Num(1) Size(0x58)

	// Object Name: Function ClientNet.GCloudNet.OnGetCountryNoByIMSDK
	// Flags: [Final|Native|Private]
	void OnGetCountryNoByIMSDK(int country); // Offset: 0x103caf3a8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ClientNet.GCloudNet.OnGCloudStateChangeNotify
	// Flags: [Final|Native|Private]
	void OnGCloudStateChangeNotify(int State, int Param1, int Param2, int param3); // Offset: 0x103caf280 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function ClientNet.GCloudNet.OnGCloudDisconnectedNotify
	// Flags: [Final|Native|Private]
	void OnGCloudDisconnectedNotify(int Result); // Offset: 0x103caf204 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ClientNet.GCloudNet.OnGCloudConnectedNotify
	// Flags: [Final|Native|Private]
	void OnGCloudConnectedNotify(int IsConnected, int nResult); // Offset: 0x103caf150 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function ClientNet.GCloudNet.OnGameMasterEvent
	// Flags: [Final|Native|Private]
	void OnGameMasterEvent(struct FString EvenName, int Result); // Offset: 0x103caf054 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function ClientNet.GCloudNet.OnBindIntlNotify
	// Flags: [Final|Native|Private]
	void OnBindIntlNotify(int bindEventID); // Offset: 0x103caefd8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ClientNet.GCloudNet.OnAccountLogoutNotify
	// Flags: [Final|Native|Private]
	void OnAccountLogoutNotify(int Result); // Offset: 0x103caef5c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ClientNet.GCloudNet.OnAccountLoginNotify
	// Flags: [Final|Native|Private]
	void OnAccountLoginNotify(int Result, struct FString OpenID, int Channel, struct FString resultMsg, int thirdRetCode); // Offset: 0x103caed5c // Return & Params: Num(5) Size(0x34)

	// Object Name: Function ClientNet.GCloudNet.OnAccountInitializeNotify
	// Flags: [Final|Native|Private]
	void OnAccountInitializeNotify(int Result); // Offset: 0x103caece0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ClientNet.GCloudNet.OnAccessTokenRefreshedNotify
	// Flags: [Final|Native|Private]
	void OnAccessTokenRefreshedNotify(int Result); // Offset: 0x103caec64 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class ClientNet.GCloudSDK
// Size: 0x140 // Inherited bytes: 0x28
struct UGCloudSDK : UObject {
	// Fields
	char pad_0x28[0x108]; // Offset: 0x28 // Size: 0x108
	bool OpenBuglyLogReport; // Offset: 0x130 // Size: 0x01
	char pad_0x131[0x3]; // Offset: 0x131 // Size: 0x03
	int MaxBufferSize; // Offset: 0x134 // Size: 0x04
	char pad_0x138[0x8]; // Offset: 0x138 // Size: 0x08

	// Functions

	// Object Name: Function ClientNet.GCloudSDK.UploadFile
	// Flags: [Final|Native|Static|Public]
	void UploadFile(struct FString _imgPath, int shareFileType); // Offset: 0x103cb1708 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function ClientNet.GCloudSDK.ShareWithPhotoByChannel_Simple
	// Flags: [Final|Native|Public]
	void ShareWithPhotoByChannel_Simple(struct FString _imgPath, struct FString _title, struct FString _content, int _channel); // Offset: 0x103cb1588 // Return & Params: Num(4) Size(0x34)

	// Object Name: Function ClientNet.GCloudSDK.ShareFacebookLink
	// Flags: [Final|Native|Static|Public]
	void ShareFacebookLink(struct FString ftitle, struct FString fdesc, struct FString fsharelink); // Offset: 0x103cb1450 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function ClientNet.GCloudSDK.SetTestLogin
	// Flags: [Final|Native|Public]
	void SetTestLogin(struct FString OpenID, int Channel); // Offset: 0x103cb1378 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function ClientNet.GCloudSDK.InviteSystemOfflineFriendsExt2
	// Flags: [Final|Native|Public]
	void InviteSystemOfflineFriendsExt2(struct FString _title, struct FString _content, struct FString _link); // Offset: 0x103cb1238 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function ClientNet.GCloudSDK.InviteSystemOfflineFriendsExt
	// Flags: [Final|Native|Public]
	void InviteSystemOfflineFriendsExt(struct FString _title, struct FString _content, struct FString _link); // Offset: 0x103cb10f8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function ClientNet.GCloudSDK.InviteFBFriendsUnregistered_Link
	// Flags: [Final|Native|Public]
	void InviteFBFriendsUnregistered_Link(struct FString _title, struct FString _content, struct FString _link, struct FString _extend); // Offset: 0x103cb0f64 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function ClientNet.GCloudSDK.GetUploadUrlByFile
	// Flags: [Final|Native|Static|Public]
	struct FString GetUploadUrlByFile(struct FString file); // Offset: 0x103cb0e80 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function ClientNet.GCloudSDK.GetUploadUrl
	// Flags: [Final|Native|Static|Public]
	struct FString GetUploadUrl(); // Offset: 0x103cb0e1c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ClientNet.GCloudSDK.GetUploadStatusByFile
	// Flags: [Final|Native|Static|Public]
	int GetUploadStatusByFile(struct FString file); // Offset: 0x103cb0d60 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function ClientNet.GCloudSDK.GetUploadStatus
	// Flags: [Final|Native|Static|Public]
	int GetUploadStatus(); // Offset: 0x103cb0d2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ClientNet.GCloudSDK.ClearFileUpload
	// Flags: [Final|Native|Static|Public]
	void ClearFileUpload(struct FString file); // Offset: 0x103cb0c78 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class ClientNet.GCloudSDKDelegates
// Size: 0x158 // Inherited bytes: 0x28
struct UGCloudSDKDelegates : UObject {
	// Fields
	struct FScriptMulticastDelegate ConnectNotifyDelegate; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate ConnectStateChangedNotifyDelegate; // Offset: 0x38 // Size: 0x10
	struct FScriptMulticastDelegate DisconnectNotifyDelegate; // Offset: 0x48 // Size: 0x10
	struct FScriptMulticastDelegate ReceiveDataNotifyDelegate; // Offset: 0x58 // Size: 0x10
	struct FScriptMulticastDelegate AccountInitializeNotifyDelegate; // Offset: 0x68 // Size: 0x10
	struct FScriptMulticastDelegate AccountLoginNotifyDelegate; // Offset: 0x78 // Size: 0x10
	struct FScriptMulticastDelegate AccessTokenRefreshedNotifyDelegate; // Offset: 0x88 // Size: 0x10
	struct FScriptMulticastDelegate AccountLogoutNotifyDelegate; // Offset: 0x98 // Size: 0x10
	struct FScriptMulticastDelegate ShareNotifyDelegate; // Offset: 0xa8 // Size: 0x10
	struct FScriptMulticastDelegate GroupNotifyDelegate; // Offset: 0xb8 // Size: 0x10
	struct FScriptMulticastDelegate QuickLoginNotifyDelegate; // Offset: 0xc8 // Size: 0x10
	struct FScriptMulticastDelegate QRCodeGenQRImgDelegate; // Offset: 0xd8 // Size: 0x10
	struct FScriptMulticastDelegate QRCodeLaunchDelegate; // Offset: 0xe8 // Size: 0x10
	struct FScriptMulticastDelegate WebviewNotifyDelegate; // Offset: 0xf8 // Size: 0x10
	struct FScriptMulticastDelegate ShortUrlNotifyDelegate; // Offset: 0x108 // Size: 0x10
	struct FScriptMulticastDelegate OnGetTicketNotifyDelegate; // Offset: 0x118 // Size: 0x10
	struct FScriptMulticastDelegate GameMasterEventDelegate; // Offset: 0x128 // Size: 0x10
	struct FScriptMulticastDelegate OnRequestPermissionResultDelegate; // Offset: 0x138 // Size: 0x10
	struct FScriptMulticastDelegate TConndAuthFailDelegate; // Offset: 0x148 // Size: 0x10
};

// Object Name: Class ClientNet.IMSDKConfig
// Size: 0x238 // Inherited bytes: 0x28
struct UIMSDKConfig : UObject {
	// Fields
	struct FString IMSDK_GAME_ID; // Offset: 0x28 // Size: 0x10
	struct FString IMSDK_SERVER_SDKAPI_RELEASE; // Offset: 0x38 // Size: 0x10
	struct FString IMSDK_SERVER_NOTICE_RELEASE; // Offset: 0x48 // Size: 0x10
	struct FString IMSDK_SERVER_HELP_RELEASE; // Offset: 0x58 // Size: 0x10
	struct FString IMSDK_SERVER_HELP_SCHEME_RELEASE; // Offset: 0x68 // Size: 0x10
	struct FString IMSDK_SERVER_CONFIG_RELEASE; // Offset: 0x78 // Size: 0x10
	struct FString IMSDK_LOG_LEVEL_RELEASE; // Offset: 0x88 // Size: 0x10
	struct FString IMSDK_DEBUG_RELEASE; // Offset: 0x98 // Size: 0x10
	struct FString IMSDK_INNER_VOLLEY_DEBUG_RELEASE; // Offset: 0xa8 // Size: 0x10
	struct FString IMSDK_SERVER_SDKAPI_TEST; // Offset: 0xb8 // Size: 0x10
	struct FString IMSDK_SERVER_NOTICE_TEST; // Offset: 0xc8 // Size: 0x10
	struct FString IMSDK_SERVER_HELP_TEST; // Offset: 0xd8 // Size: 0x10
	struct FString IMSDK_SERVER_HELP_SCHEME_TEST; // Offset: 0xe8 // Size: 0x10
	struct FString IMSDK_SERVER_CONFIG_TEST; // Offset: 0xf8 // Size: 0x10
	struct FString IMSDK_LOG_LEVEL_TEST; // Offset: 0x108 // Size: 0x10
	struct FString IMSDK_DEBUG_TEST; // Offset: 0x118 // Size: 0x10
	struct FString IMSDK_INNER_VOLLEY_DEBUG_TEST; // Offset: 0x128 // Size: 0x10
	struct FString IMSDK_SERVER_UNIFIED_ACCOUNT_RELEASE; // Offset: 0x138 // Size: 0x10
	struct FString IMSDK_UNIFIED_ACCOUNT_APP_ID_RELEASE; // Offset: 0x148 // Size: 0x10
	struct FString IMSDK_UNIFIED_ACCOUNT_SDK_KEY_RELEASE; // Offset: 0x158 // Size: 0x10
	struct FString IMSDK_TWITTER_WEB_LOGIN_URL_RELEASE; // Offset: 0x168 // Size: 0x10
	struct FString MIGRATE_WEB_URL_RELEASE; // Offset: 0x178 // Size: 0x10
	struct FString IMSDK_UNIFIED_ACCOUNT_CHECK_PASSWORD; // Offset: 0x188 // Size: 0x10
	struct FString IMSDK_UNIFIED_ACCOUNT_PLATFORM_TYPE; // Offset: 0x198 // Size: 0x10
	struct FString IMSDK_UNIFIED_ACCOUNT_CHANNEL_ID; // Offset: 0x1a8 // Size: 0x10
	struct FString IMSDK_SERVER_UNIFIED_ACCOUNT_TEST; // Offset: 0x1b8 // Size: 0x10
	struct FString IMSDK_UNIFIED_ACCOUNT_APP_ID_TEST; // Offset: 0x1c8 // Size: 0x10
	struct FString IMSDK_UNIFIED_ACCOUNT_SDK_KEY_TEST; // Offset: 0x1d8 // Size: 0x10
	struct FString IMSDK_TWITTER_WEB_LOGIN_URL_TEST; // Offset: 0x1e8 // Size: 0x10
	struct FString MIGRATE_WEB_URL_TEST; // Offset: 0x1f8 // Size: 0x10
	struct FString MIGRATE_WEB_USER_AGENT_STRING; // Offset: 0x208 // Size: 0x10
	struct FString IMSDK_ACCOUNT_CHECK_POPUP_STATUS_ENABLE; // Offset: 0x218 // Size: 0x10
	struct FString IMSDK_ACCOUNT_VERIFY_OPT_SID_ENABLE; // Offset: 0x228 // Size: 0x10

	// Functions

	// Object Name: Function ClientNet.IMSDKConfig.PatchMSDKConfigWithAreaConfig
	// Flags: [Final|Native|Public]
	void PatchMSDKConfigWithAreaConfig(); // Offset: 0x103cb29d0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class ClientNet.IMSDKHelper
// Size: 0x148 // Inherited bytes: 0x28
struct UIMSDKHelper : UObject {
	// Fields
	bool isBindFB; // Offset: 0x28 // Size: 0x01
	bool isBindGPGC; // Offset: 0x29 // Size: 0x01
	bool isBindGP; // Offset: 0x2a // Size: 0x01
	bool isBindGC; // Offset: 0x2b // Size: 0x01
	bool isBindVK; // Offset: 0x2c // Size: 0x01
	bool isBindTwitter; // Offset: 0x2d // Size: 0x01
	bool isBindWeChat; // Offset: 0x2e // Size: 0x01
	bool isBindLine; // Offset: 0x2f // Size: 0x01
	bool isBindQQ; // Offset: 0x30 // Size: 0x01
	bool isBindApple; // Offset: 0x31 // Size: 0x01
	bool isBindUnifiedAccount; // Offset: 0x32 // Size: 0x01
	bool isBindHMS; // Offset: 0x33 // Size: 0x01
	bool isBindDiscord; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
	int iBindFBRetCode; // Offset: 0x38 // Size: 0x04
	int iBindFBThirdRetCode; // Offset: 0x3c // Size: 0x04
	struct FString strBindFBUserName; // Offset: 0x40 // Size: 0x10
	int iBindGPGCRetCode; // Offset: 0x50 // Size: 0x04
	int iBindGPGCThirdRetCode; // Offset: 0x54 // Size: 0x04
	struct FString strBindGPGCUserName; // Offset: 0x58 // Size: 0x10
	struct FString strBindTwitterUserName; // Offset: 0x68 // Size: 0x10
	struct FString strBindWeChatUserName; // Offset: 0x78 // Size: 0x10
	struct FString strBindVKUserName; // Offset: 0x88 // Size: 0x10
	struct FString strBindLineUserName; // Offset: 0x98 // Size: 0x10
	struct FString strBindQQUserName; // Offset: 0xa8 // Size: 0x10
	struct FString strBindAppleUserName; // Offset: 0xb8 // Size: 0x10
	struct FString strBindUnifiedAccountUserName; // Offset: 0xc8 // Size: 0x10
	struct FString strBindHMSUserName; // Offset: 0xd8 // Size: 0x10
	struct FString strBindDiscordUserName; // Offset: 0xe8 // Size: 0x10
	int iDeleteAccountRetCode; // Offset: 0xf8 // Size: 0x04
	int iGenerateTransferCodeRetCode; // Offset: 0xfc // Size: 0x04
	struct FString GeneratedTransferCode; // Offset: 0x100 // Size: 0x10
	int iTransferRetCode; // Offset: 0x110 // Size: 0x04
	int iTransferThirdRetCode; // Offset: 0x114 // Size: 0x04
	struct FString inputTransferCode; // Offset: 0x118 // Size: 0x10
	int iSwitchAccountFBRetCode; // Offset: 0x128 // Size: 0x04
	int iSwitchAccountFBThirdRetCode; // Offset: 0x12c // Size: 0x04
	int iSwitchAccountGPGCRetCode; // Offset: 0x130 // Size: 0x04
	int iSwitchAccountGPGCThirdRetCode; // Offset: 0x134 // Size: 0x04
	bool bGCQuietSwitchAccount; // Offset: 0x138 // Size: 0x01
	char pad_0x139[0xf]; // Offset: 0x139 // Size: 0x0f

	// Functions

	// Object Name: Function ClientNet.IMSDKHelper.Transfer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Transfer(); // Offset: 0x103cb4ccc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.StartNewGame
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartNewGame(); // Offset: 0x103cb4cb8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.SetUserId
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetUserId(struct FString userId); // Offset: 0x103cb4bfc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ClientNet.IMSDKHelper.SetNoAuthOpenid
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNoAuthOpenid(struct FString OpenID); // Offset: 0x103cb4b40 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ClientNet.IMSDKHelper.SetIMSDKEnv
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIMSDKEnv(int iEnv); // Offset: 0x103cb4ac4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ClientNet.IMSDKHelper.SetAdvertiseUnit
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAdvertiseUnit(struct FString unitID); // Offset: 0x103cb4a08 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ClientNet.IMSDKHelper.SaveLastIMSDKChannelID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SaveLastIMSDKChannelID(int channelId); // Offset: 0x103cb498c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ClientNet.IMSDKHelper.RequestVerifyCode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RequestVerifyCode(struct FString InPhoneOrEmail, int InAccountType, int InUseForType, struct FString InPhoneAreaCode, struct FString InLanuageCode, struct FString InExtraJson); // Offset: 0x103cb477c // Return & Params: Num(6) Size(0x48)

	// Object Name: Function ClientNet.IMSDKHelper.ReqBindInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReqBindInfo(); // Offset: 0x103cb4768 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.RecoverGuest
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool RecoverGuest(struct FString channelUserId); // Offset: 0x103cb46c0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function ClientNet.IMSDKHelper.PlayAdvertise
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayAdvertise(); // Offset: 0x103cb46ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.ModifyAccountInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ModifyAccountInfo(struct FString InAccount, int InAccountType, int InVerifyType, struct FString InVerifyData, struct FString InPhoneAreaCode, struct FString InLanuageCode, struct FString InMondifyToAccount, int InModifyAccountType, struct FString InModifyVerifyCode, struct FString InModifyPhoneAreaCode, struct FString InExtraJson); // Offset: 0x103cb4300 // Return & Params: Num(11) Size(0x90)

	// Object Name: Function ClientNet.IMSDKHelper.LogoutWith
	// Flags: [Final|Native|Public|BlueprintCallable]
	void LogoutWith(int InMSDKChannelId); // Offset: 0x103cb4284 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ClientNet.IMSDKHelper.LoadAdvertise
	// Flags: [Final|Native|Public|BlueprintCallable]
	void LoadAdvertise(); // Offset: 0x103cb4270 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.IsEqualCurLoginPlatform
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsEqualCurLoginPlatform(struct FString strChannel); // Offset: 0x103cb41a4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function ClientNet.IMSDKHelper.isBindFBOrGPGC
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool isBindFBOrGPGC(); // Offset: 0x103cb4170 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.IsAlreadyBindWeChat
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsAlreadyBindWeChat(); // Offset: 0x103cb413c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.IsAlreadyBindVK
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsAlreadyBindVK(); // Offset: 0x103cb4108 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.IsAlreadyBindUnifiedAccount
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsAlreadyBindUnifiedAccount(); // Offset: 0x103cb40d4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.IsAlreadyBindTwitter
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsAlreadyBindTwitter(); // Offset: 0x103cb40a0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.IsAlreadyBindQQ
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsAlreadyBindQQ(); // Offset: 0x103cb406c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.IsAlreadyBindLine
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsAlreadyBindLine(); // Offset: 0x103cb4038 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.IsAlreadyBindHMS
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsAlreadyBindHMS(); // Offset: 0x103cb4004 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.IsAlreadyBindGPGC
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsAlreadyBindGPGC(); // Offset: 0x103cb3fd0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.IsAlreadyBindGooglePlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsAlreadyBindGooglePlay(); // Offset: 0x103cb3f9c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.IsAlreadyBindGameCenter
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsAlreadyBindGameCenter(); // Offset: 0x103cb3f68 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.IsAlreadyBindFB
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsAlreadyBindFB(); // Offset: 0x103cb3f34 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.IsAlreadyBindDiscord
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsAlreadyBindDiscord(); // Offset: 0x103cb3f00 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.IsAlreadyBindApple
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsAlreadyBindApple(); // Offset: 0x103cb3ecc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.GetShortUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetShortUrl(struct FString URL, struct FString Mask, struct FString Extra); // Offset: 0x103cb3d20 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function ClientNet.IMSDKHelper.GetPlatformType
	// Flags: [Final|Native|Public|BlueprintCallable]
	enum class EIMSDKPlatformType GetPlatformType(); // Offset: 0x103cb3cec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.GetOpenId
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetOpenId(); // Offset: 0x103cb3c88 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ClientNet.IMSDKHelper.GetLastIMSDKChannelID
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetLastIMSDKChannelID(); // Offset: 0x103cb3c54 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ClientNet.IMSDKHelper.GetIsAdvertiseVaild
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetIsAdvertiseVaild(); // Offset: 0x103cb3c20 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.GetIsAdvertiseLoadSuccess
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetIsAdvertiseLoadSuccess(); // Offset: 0x103cb3bec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.GetIsAdvertiseLoad
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetIsAdvertiseLoad(); // Offset: 0x103cb3bb8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ClientNet.IMSDKHelper.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UIMSDKHelper* GetInstance(); // Offset: 0x103cb3b84 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function ClientNet.IMSDKHelper.GetGCloudChannelID
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetGCloudChannelID(); // Offset: 0x103cb3b50 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ClientNet.IMSDKHelper.GetCurLoginPlatform
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetCurLoginPlatform(); // Offset: 0x103cb3aec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ClientNet.IMSDKHelper.GetChannelNickname
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetChannelNickname(); // Offset: 0x103cb3a88 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ClientNet.IMSDKHelper.GetBindInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetBindInfo(); // Offset: 0x103cb3a74 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.GetBindFBRetCode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetBindFBRetCode(); // Offset: 0x103cb3a60 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.GetBindCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetBindCount(); // Offset: 0x103cb3a2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ClientNet.IMSDKHelper.GenerateTransferCode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GenerateTransferCode(); // Offset: 0x103cb3a18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.CopyTransferCodeToClipboard
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CopyTransferCodeToClipboard(); // Offset: 0x103cb3a04 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.ConvertStrToIMSDKChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	int ConvertStrToIMSDKChannel(struct FString strChannel); // Offset: 0x103cb3938 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function ClientNet.IMSDKHelper.ConvertIMSDKChannelToStr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString ConvertIMSDKChannelToStr(int imsdkChannel); // Offset: 0x103cb3884 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function ClientNet.IMSDKHelper.CheckVerifyCodeValid
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CheckVerifyCodeValid(struct FString InAccount, int InAccountType, struct FString InPhoneAreaCode, struct FString InVerifyCode, int InCodeType, struct FString InLanuageCode, struct FString InExtraJson); // Offset: 0x103cb361c // Return & Params: Num(7) Size(0x60)

	// Object Name: Function ClientNet.IMSDKHelper.CheckIsRegisted
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CheckIsRegisted(struct FString InAccount, int InAccountType, struct FString InPhoneAreaCode, struct FString InLanuageCode, struct FString InExtraJson); // Offset: 0x103cb3448 // Return & Params: Num(5) Size(0x48)

	// Object Name: Function ClientNet.IMSDKHelper.ChangePassword
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChangePassword(struct FString InAccount, int InAccountType, struct FString InVerifyCode, struct FString InNewPassword, struct FString InAreaCode, struct FString InLangType, struct FString InExtraJson); // Offset: 0x103cb31cc // Return & Params: Num(7) Size(0x68)

	// Object Name: Function ClientNet.IMSDKHelper.BindWeChat
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindWeChat(); // Offset: 0x103cb31b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.BindVK
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindVK(); // Offset: 0x103cb31a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.BindUnifiedAccount
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindUnifiedAccount(struct FString InExtraJson); // Offset: 0x103cb310c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ClientNet.IMSDKHelper.BindTwitter
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindTwitter(); // Offset: 0x103cb30f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.BindQQ
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindQQ(); // Offset: 0x103cb30e4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.BindLine
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindLine(); // Offset: 0x103cb30d0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.BindHMS
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindHMS(); // Offset: 0x103cb30bc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.BindGPGC
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindGPGC(); // Offset: 0x103cb30a8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.BindFB
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindFB(); // Offset: 0x103cb3094 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.BindDiscord
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindDiscord(); // Offset: 0x103cb3080 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClientNet.IMSDKHelper.BindApple
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindApple(); // Offset: 0x103cb306c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class ClientNet.iTOPPrefs
// Size: 0xe0 // Inherited bytes: 0x28
struct UiTOPPrefs : USaveGame {
	// Fields
	bool bForceLogin; // Offset: 0x28 // Size: 0x01
	bool bFirstLoginGuestAfterBindFB; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x2]; // Offset: 0x2a // Size: 0x02
	int nGCloudChannelID; // Offset: 0x2c // Size: 0x04
	int nLastIMSDKChannelID; // Offset: 0x30 // Size: 0x04
	bool bNeedFBForceLoginForRelationChainError; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
	int64_t lastTimeSetFBForceLoginForRelationChainError; // Offset: 0x38 // Size: 0x08
	bool bNeedWXForceLoginForRelationChainError; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
	int64_t lastTimeSetWXForceLoginForRelationChainError; // Offset: 0x48 // Size: 0x08
	bool bNeedVKForceLoginForRelationChainError; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x7]; // Offset: 0x51 // Size: 0x07
	int64_t lastTimeSetVKForceLoginForRelationChainError; // Offset: 0x58 // Size: 0x08
	bool bNeedLineForceLoginForRelationChainError; // Offset: 0x60 // Size: 0x01
	char pad_0x61[0x7]; // Offset: 0x61 // Size: 0x07
	int64_t lastTimeSetLineForceLoginForRelationChainError; // Offset: 0x68 // Size: 0x08
	bool bNeedQQForceLoginForRelationChainError; // Offset: 0x70 // Size: 0x01
	char pad_0x71[0x7]; // Offset: 0x71 // Size: 0x07
	int64_t lastTimeSetQQForceLoginForRelationChainError; // Offset: 0x78 // Size: 0x08
	bool bNeedAppleForceLoginForRelationChainError; // Offset: 0x80 // Size: 0x01
	char pad_0x81[0x7]; // Offset: 0x81 // Size: 0x07
	int64_t lastTimeSetAppleForceLoginForRelationChainError; // Offset: 0x88 // Size: 0x08
	bool bNeedUnifiedAccountForceLoginForRelationChainError; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x7]; // Offset: 0x91 // Size: 0x07
	int64_t lastTimeSetUnifiedAccountForceLoginForRelationChainError; // Offset: 0x98 // Size: 0x08
	bool bNeedHMSForceLoginForRelationChainError; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x7]; // Offset: 0xa1 // Size: 0x07
	int64_t lastTimeSetHMSForceLoginForRelationChainError; // Offset: 0xa8 // Size: 0x08
	bool bNeedDiscordForceLoginForRelationChainError; // Offset: 0xb0 // Size: 0x01
	char pad_0xB1[0x7]; // Offset: 0xb1 // Size: 0x07
	int64_t lastTimeSetDiscordForceLoginForRelationChainError; // Offset: 0xb8 // Size: 0x08
	bool bNeedForceLoginForRelationChainError; // Offset: 0xc0 // Size: 0x01
	char pad_0xC1[0x7]; // Offset: 0xc1 // Size: 0x07
	int64_t lastTimeSetForceLoginForRelationChainError; // Offset: 0xc8 // Size: 0x08
	struct FString lastLoginArea; // Offset: 0xd0 // Size: 0x10
};

