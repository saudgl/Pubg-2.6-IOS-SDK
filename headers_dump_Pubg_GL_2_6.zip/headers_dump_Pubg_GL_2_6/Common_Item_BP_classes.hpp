//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Common_Item_BP.Common_Item_BP_C
// Size: 0x33c // Inherited bytes: 0x2d0
struct UCommon_Item_BP_C : UCommonItemBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x2d0 // Size: 0x08
	struct UCommon_DragDrop_Item_C* Common_DragDrop_Item; // Offset: 0x2d8 // Size: 0x08
	struct UGridPanel* GridPanel_1; // Offset: 0x2e0 // Size: 0x08
	struct UCanvasPanel* Panel_Download; // Offset: 0x2e8 // Size: 0x08
	struct UButton* Button_Item; // Offset: 0x2f0 // Size: 0x08
	struct FScriptMulticastDelegate OnClickItemCallback; // Offset: 0x2f8 // Size: 0x10
	struct FScriptMulticastDelegate OnPressItemCallback; // Offset: 0x308 // Size: 0x10
	struct FScriptMulticastDelegate OnReleaseItemCallback; // Offset: 0x318 // Size: 0x10
	struct UObject* ODPaksDownload_Component; // Offset: 0x328 // Size: 0x08
	struct UUserWidget* targetUI; // Offset: 0x330 // Size: 0x08
	int resID; // Offset: 0x338 // Size: 0x04

	// Functions

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetTexture
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetTexture(struct UImage* Control, struct FString Path); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetEveryPackIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetEveryPackIcon(int specailIconTable); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetLight
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetLight(bool bShow); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetNameColor
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetNameColor(struct FSlateColor Color); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x28)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetLimitCount
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetLimitCount(bool IsShow, int Has, int Max); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetCostCount
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetCostCount(bool IsShow, int Has, int Cost); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.HideQualityOfBG
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void HideQualityOfBG(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.HideQuality
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void HideQuality(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetTimeLimitIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetTimeLimitIcon(bool Show); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetValidTime
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetValidTime(int validTime); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetIsShowSubTransparentBg
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIsShowSubTransparentBg(bool IsShow); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetGrayBg
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetGrayBg(bool IsShow); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetBlackBg
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetBlackBg(bool IsShow); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetAwardState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetAwardState(int State); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetCombatReadinessIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetCombatReadinessIcon(bool Visibility); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetIsWear
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIsWear(bool isWear); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.PlayDecomposeAni
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void PlayDecomposeAni(int OldItemID, int NewItemID, int newCnt); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetTakeState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetTakeState(bool canTake); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetHasGet
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetHasGet(bool hasGet); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.EnableItemPreview
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void EnableItemPreview(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetIconFromTexture
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIconFromTexture(struct UTexture2D* Texture); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.ShowItemName
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ShowItemName(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.DisableItemPreview
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void DisableItemPreview(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.OnReleaseItem
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnReleaseItem(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.OnPressItem
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnPressItem(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.OnClickItem
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnClickItem(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetUseCount
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetUseCount(int UseCount, bool isRolewear); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetSmallerIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetSmallerIcon(bool IsNeedSmall); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetSpecialIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetSpecialIcon(struct FString Path); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetDecomposeEffectIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetDecomposeEffectIcon(int from_id, int to_id, int to_cnt, float playAnimDelayTime); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.PlayDecomposeAnim
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void PlayDecomposeAnim(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.EnableShowLimit
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void EnableShowLimit(bool Enable); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetColorAndPattern
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetColorAndPattern(int Color, int Pattern); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetIsolated
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIsolated(bool bShow); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.ShowMask
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ShowMask(bool IsShow); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetBGVisibility
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetBGVisibility(bool Visible); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.EnableShowTips
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void EnableShowTips(bool Enable); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.HideNameAddrStr
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void HideNameAddrStr(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetIsTryOn
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIsTryOn(bool tryOn); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetNameAddStr
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetNameAddStr(struct FString NewParam); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetIconAlpha
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIconAlpha(float Alpha); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetIsLock
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIsLock(bool isLock); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetIsNew
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIsNew(bool isNew); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetQuality
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetQuality(int Quality); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetUsingState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetUsingState(bool isUsing); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetSelected
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetSelected(bool isSelected); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.SetNumber
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetNumber(int Number); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.InitView
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void InitView(int resID, int Count, int Style, int validHour, bool isShowTips, bool isRedEmotion, struct UCommon_Item_BP_C*& Item); // Offset: 0x1041acc2c // Return & Params: Num(7) Size(0x20)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.OnClickEvent
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnClickEvent(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.OnPressEvent
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnPressEvent(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.OnReleaseEvent
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnReleaseEvent(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C._BindEvent
	// Flags: [BlueprintCallable|BlueprintEvent]
	void _BindEvent(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C._ClearEvent
	// Flags: [BlueprintCallable|BlueprintEvent]
	void _ClearEvent(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C._BindDragEvent
	// Flags: [BlueprintCallable|BlueprintEvent]
	void _BindDragEvent(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C._ClearDragEvent
	// Flags: [BlueprintCallable|BlueprintEvent]
	void _ClearDragEvent(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.ExecuteUbergraph_Common_Item_BP
	// Flags: [None]
	void ExecuteUbergraph_Common_Item_BP(int EntryPoint); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.OnReleaseItemCallback__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnReleaseItemCallback__DelegateSignature(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.OnPressItemCallback__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnPressItemCallback__DelegateSignature(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Item_BP.Common_Item_BP_C.OnClickItemCallback__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnClickItemCallback__DelegateSignature(int resID); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)
};

