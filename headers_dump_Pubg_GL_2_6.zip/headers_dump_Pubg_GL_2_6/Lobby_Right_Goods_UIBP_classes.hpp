//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Right_Goods_UIBP.Lobby_Right_Goods_UIBP_C
// Size: 0x310 // Inherited bytes: 0x260
struct ULobby_Right_Goods_UIBP_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* Open; // Offset: 0x268 // Size: 0x08
	struct UButton* Button_Enter; // Offset: 0x270 // Size: 0x08
	struct UButton* Button_Question; // Offset: 0x278 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_2; // Offset: 0x280 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_7; // Offset: 0x288 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_AttachPos; // Offset: 0x290 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Discout; // Offset: 0x298 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_TipsRoot; // Offset: 0x2a0 // Size: 0x08
	struct UImage* Image_6; // Offset: 0x2a8 // Size: 0x08
	struct UImage* Image_7; // Offset: 0x2b0 // Size: 0x08
	struct UImage* Image_New; // Offset: 0x2b8 // Size: 0x08
	struct UImage* Image_People; // Offset: 0x2c0 // Size: 0x08
	struct UImage* Image_Pinzhi; // Offset: 0x2c8 // Size: 0x08
	struct UImage* Image_Title; // Offset: 0x2d0 // Size: 0x08
	struct UTextBlock* TextBlock_Price; // Offset: 0x2d8 // Size: 0x08
	struct UTextBlock* TextBlock_Price_Discout; // Offset: 0x2e0 // Size: 0x08
	struct UTextBlock* TextBlock_Title1; // Offset: 0x2e8 // Size: 0x08
	struct UTextBlock* TextBlock_Title2; // Offset: 0x2f0 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_2; // Offset: 0x2f8 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Entrance; // Offset: 0x300 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_People; // Offset: 0x308 // Size: 0x08

	// Functions

	// Object Name: Function Lobby_Right_Goods_UIBP.Lobby_Right_Goods_UIBP_C.BndEvt__Button_Enter_K2Node_ComponentBoundEvent_65_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Button_Enter_K2Node_ComponentBoundEvent_65_OnButtonClickedEvent__DelegateSignature(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Right_Goods_UIBP.Lobby_Right_Goods_UIBP_C.ExecuteUbergraph_Lobby_Right_Goods_UIBP
	// Flags: [None]
	void ExecuteUbergraph_Lobby_Right_Goods_UIBP(int EntryPoint); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)
};

