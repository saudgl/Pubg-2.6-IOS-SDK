//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_ItemSoundTable_type.BP_STRUCT_ItemSoundTable_type
// Size: 0x88 // Inherited bytes: 0x00
struct FBP_STRUCT_ItemSoundTable_type {
	// Fields
	struct FString EquipSound_0_068B68C066212493052EBF3305D63E14; // Offset: 0x00 // Size: 0x10
	struct FString DropSound_1_4DD7CD003E11476C25039DA50902AA34; // Offset: 0x10 // Size: 0x10
	int ID_2_42F748C040D81BA3690F7C020EF58C44; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FString PickUpSound_3_0B99FAC07345086D4963B6D504877D14; // Offset: 0x28 // Size: 0x10
	struct FString DropBank_4_1D8769C022E35E311709B3FF07910C6B; // Offset: 0x38 // Size: 0x10
	struct FString EquipBank_5_30BCE58001E2251E07D41C7C055C432B; // Offset: 0x48 // Size: 0x10
	struct FString UnEquipBank_6_4FF4964008C1F90F14F8C45904D7459B; // Offset: 0x58 // Size: 0x10
	struct FString UnEquipSound_7_0376B980772F43423C77A2D80D665704; // Offset: 0x68 // Size: 0x10
	struct FString PickUpBank_8_3C7477801367726A5EFE3B0D0549773B; // Offset: 0x78 // Size: 0x10
};

