//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_WEP_Machete_BattleItemHandle.BP_WEP_Machete_BattleItemHandle_C
// Size: 0x6f1 // Inherited bytes: 0x6f1
struct UBP_WEP_Machete_BattleItemHandle_C : UBattleItemHandle_MeleeWeapon_C {
};

