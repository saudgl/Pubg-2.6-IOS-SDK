//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_UPassEliteRewardCfg_type.BP_STRUCT_UPassEliteRewardCfg_type
// Size: 0x30 // Inherited bytes: 0x00
struct FBP_STRUCT_UPassEliteRewardCfg_type {
	// Fields
	int ID_1_4A60FDC02F212C5F33B2F7E7006E1014; // Offset: 0x00 // Size: 0x04
	int item_id_2_3_7C3AF580419A56DC31446D750ED4C682; // Offset: 0x04 // Size: 0x04
	int season_index_4_7F42DA804443A1486C5A6E110105A298; // Offset: 0x08 // Size: 0x04
	int show_buy_6_24341680369D439E3B7777D30F034A99; // Offset: 0x0c // Size: 0x04
	int level_11_193BC0806CF5EBD432C1B902013ECA5C; // Offset: 0x10 // Size: 0x04
	int item_id_1_12_7C39F540419A56DB31446D740ED4C681; // Offset: 0x14 // Size: 0x04
	int spec_show_13_75930D406BCC049746BEFF560D77A907; // Offset: 0x18 // Size: 0x04
	int item_id_3_20_7C3BF5C0419A56DD31446D720ED4C683; // Offset: 0x1c // Size: 0x04
	int item_id_exp_1_21_4C99004043A04F9907D077C306F222E1; // Offset: 0x20 // Size: 0x04
	int item_id_exp_2_22_4C9A008043A04F9A07D077C206F222E2; // Offset: 0x24 // Size: 0x04
	int item_id_exp_sub_1_23_1F38AA80473528C82241814302AC4601; // Offset: 0x28 // Size: 0x04
	int item_id_exp_sub_2_24_1F39AAC0473528C92241814002AC4602; // Offset: 0x2c // Size: 0x04
};

