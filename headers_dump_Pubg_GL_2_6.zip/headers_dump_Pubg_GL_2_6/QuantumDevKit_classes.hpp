//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class QuantumDevKit.FirebaseHelper
// Size: 0x38 // Inherited bytes: 0x28
struct UFirebaseHelper : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10

	// Functions

	// Object Name: Function QuantumDevKit.FirebaseHelper.GetInstance
	// Flags: [Final|Native|Static|Public]
	struct UFirebaseHelper* GetInstance(); // Offset: 0x1026195c8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function QuantumDevKit.FirebaseHelper.GetFIRInstallId
	// Flags: [Final|Native|Public]
	struct FString GetFIRInstallId(); // Offset: 0x102619564 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function QuantumDevKit.FirebaseHelper.GetFIRAppInstanceId
	// Flags: [Final|Native|Public]
	struct FString GetFIRAppInstanceId(); // Offset: 0x102619500 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function QuantumDevKit.FirebaseHelper.GetFCMToken
	// Flags: [Final|Native|Public]
	struct FString GetFCMToken(); // Offset: 0x10261949c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class QuantumDevKit.QuantumFirebaseRemoteConfig
// Size: 0xd0 // Inherited bytes: 0x28
struct UQuantumFirebaseRemoteConfig : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct TArray<struct FString> QueryConfigNamesArray; // Offset: 0x30 // Size: 0x10
	char pad_0x40[0x90]; // Offset: 0x40 // Size: 0x90

	// Functions

	// Object Name: Function QuantumDevKit.QuantumFirebaseRemoteConfig.GetStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	enum class EQuantumFirebaseRemoteConfigStatus GetStatus(); // Offset: 0x1026199f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function QuantumDevKit.QuantumFirebaseRemoteConfig.GetRemoteConfig
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetRemoteConfig(struct FString ConfigNameToQuery); // Offset: 0x102619904 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function QuantumDevKit.QuantumFirebaseRemoteConfig.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UQuantumFirebaseRemoteConfig* GetInstance(); // Offset: 0x1026198d0 // Return & Params: Num(1) Size(0x8)
};

