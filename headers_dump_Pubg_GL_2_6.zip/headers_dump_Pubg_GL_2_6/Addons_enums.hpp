//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum Addons.EPterosaurSwoopStage
enum class EPterosaurSwoopStage : uint8 {
	ESwoopStage_None = 0,
	ESwoopStage_Ready = 1,
	ESwoopStage_DirectionCorrect = 2,
	ESwoopStage_SwoopMove = 3,
	ESwoopStage_PreCatch = 4,
	ESwoopStage_Catch = 5,
	ESwoopStage_Finish = 6,
	ESwoopStage_FinishNoCatch = 7,
	ESwoopStage_FinishNoCatchWithHit = 8,
	ESwoopStage_MAX = 9
};

// Object Name: Enum Addons.EBoneDirection
enum class EBoneDirection : uint8 {
	ForwardDirection = 0,
	BackWardDirection = 1,
	LeftDirection = 2,
	RightDirection = 3,
	UpDirection = 4,
	DownDirection = 5,
	EBoneDirection_MAX = 6
};

// Object Name: Enum Addons.EBioVehicleTerrainAdaptingType
enum class EBioVehicleTerrainAdaptingType : uint8 {
	TaskThread = 0,
	MainThread = 1,
	None = 2,
	EBioVehicleTerrainAdaptingType_MAX = 3
};

// Object Name: Enum Addons.EBioVehiclePoseType
enum class EBioVehiclePoseType : uint8 {
	EBioVehiclePose_UntamedIdle = 0,
	EBioVehiclePose_Idle = 1,
	EBioVehiclePose_RandomIdle1 = 2,
	EBioVehiclePose_RandomIdle2 = 3,
	EBioVehiclePose_Movement = 4,
	EBioVehiclePose_Death = 5,
	EBioVehiclePose_JumpStart = 6,
	EBioVehiclePose_Falling = 7,
	EBioVehiclePose_RunLanding = 8,
	EBioVehiclePose_IdleLanding = 9,
	EBioVehiclePose_TurnStart = 10,
	EBioVehiclePose_Turning = 11,
	EBioVehiclePose_TurnEnd = 12,
	EBioVehiclePose_ExtraDeath = 13,
	EBioVehiclePose_StartFlying = 14,
	EBioVehiclePose_ArrestMovement = 15,
	EBioVehiclePose_FlyingAO = 16,
	EBioVehiclePose_StartLanding1 = 17,
	EBioVehiclePose_StartLanding2 = 18,
	EBioVehiclePose_Landing1 = 19,
	EBioVehiclePose_Landing2 = 20,
	EBioVehiclePose_Landing3 = 21,
	EBioVehiclePose_TakingOff = 22,
	EBioVehiclePose_RiseUp = 23,
	EBioVehiclePose_RiseDown = 24,
	EBioVehiclePose_DivingStart = 25,
	EBioVehiclePose_Diving = 26,
	EBioVehiclePose_DivingEnd = 27,
	EBioVehiclePose_GroundDeath = 28,
	EBioVehiclePose_DeathFalling = 29,
	EBioVehiclePose_DeathFallingGround = 30,
	EBioVehiclePose_Max = 31
};

// Object Name: Enum Addons.EPterosaurMoveMode
enum class EPterosaurMoveMode : uint8 {
	EMove_Idle = 0,
	EMove_TakingOff = 1,
	EMove_RegularFlying = 2,
	EMove_Diving = 3,
	EMove_Landing = 4,
	EMove_SwoopDown = 5,
	EMove_MAX = 6
};

// Object Name: Enum Addons.EBioVehicleSkillStopReason
enum class EBioVehicleSkillStopReason : uint8 {
	StopReason_FINISH = 0,
	StopReason_INTERRUPT = 1,
	StopReason_MAX = 2
};

// Object Name: Enum Addons.ETyranState
enum class ETyranState : uint8 {
	None = 0,
	Normal = 2,
	BreakOut = 4,
	ETyranState_MAX = 5
};

