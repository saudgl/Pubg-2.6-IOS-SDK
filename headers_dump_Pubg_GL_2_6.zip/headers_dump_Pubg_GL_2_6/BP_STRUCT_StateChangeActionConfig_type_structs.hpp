//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_StateChangeActionConfig_type.BP_STRUCT_StateChangeActionConfig_type
// Size: 0x10 // Inherited bytes: 0x00
struct FBP_STRUCT_StateChangeActionConfig_type {
	// Fields
	int ActionID_0_697DDF0062B97FDA4EE0B3AA03BCF704; // Offset: 0x00 // Size: 0x04
	int AfterClothID_1_2B06228044B197EA5224F0FC0E021404; // Offset: 0x04 // Size: 0x04
	int BeforeClothID_2_0D189AC0358CFCF777A2F25F0C188F14; // Offset: 0x08 // Size: 0x04
	int ID_3_195147803C84F0FC34596E590914B574; // Offset: 0x0c // Size: 0x04
};

