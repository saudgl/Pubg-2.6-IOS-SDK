//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Activity_Novice_BigItem02.Activity_Novice_BigItem02_C
// Size: 0x2e8 // Inherited bytes: 0x260
struct UActivity_Novice_BigItem02_C : UUserWidget {
	// Fields
	struct UButton* Button_Click; // Offset: 0x260 // Size: 0x08
	struct UImage* FX_01; // Offset: 0x268 // Size: 0x08
	struct UImage* FX_02; // Offset: 0x270 // Size: 0x08
	struct UImage* FX_03; // Offset: 0x278 // Size: 0x08
	struct UCanvasPanel* FX_BGLight; // Offset: 0x280 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x288 // Size: 0x08
	struct UImage* Image_3; // Offset: 0x290 // Size: 0x08
	struct UImage* Image_Item; // Offset: 0x298 // Size: 0x08
	struct UImage* Image_Item_Mask; // Offset: 0x2a0 // Size: 0x08
	struct UImage* Image_ItemWeapon; // Offset: 0x2a8 // Size: 0x08
	struct UImage* Image_ItemWeapon_Mask; // Offset: 0x2b0 // Size: 0x08
	struct UImage* Image_LimitTime; // Offset: 0x2b8 // Size: 0x08
	struct UTextBlock* TextBlock_ItemName; // Offset: 0x2c0 // Size: 0x08
	struct UTextBlock* TextBlock_Number; // Offset: 0x2c8 // Size: 0x08
	struct UHorizontalBox* TimePanel; // Offset: 0x2d0 // Size: 0x08
	struct UTextBlock* TimeText; // Offset: 0x2d8 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Icon; // Offset: 0x2e0 // Size: 0x08
};

