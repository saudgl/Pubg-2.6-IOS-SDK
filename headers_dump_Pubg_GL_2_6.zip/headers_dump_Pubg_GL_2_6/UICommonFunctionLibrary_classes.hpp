//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass UICommonFunctionLibrary.UICommonFunctionLibrary_C
// Size: 0x98 // Inherited bytes: 0x98
struct UUICommonFunctionLibrary_C : UBlueprintFunctionOverride {
	// Functions

	// Object Name: Function UICommonFunctionLibrary.UICommonFunctionLibrary_C.SetAdaptation
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetAdaptation(struct UWidget* Widget, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)
};

