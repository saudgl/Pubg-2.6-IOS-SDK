//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Activity_EightDaysUIBP.Activity_EightDaysUIBP_C
// Size: 0x2e0 // Inherited bytes: 0x260
struct UActivity_EightDaysUIBP_C : UUserWidget {
	// Fields
	struct UActivity_EightDays_Item_Small_UIBP_C* Activity_Novice_DailyItem1; // Offset: 0x260 // Size: 0x08
	struct UActivity_EightDays_Item_Small_UIBP_C* Activity_Novice_DailyItem2; // Offset: 0x268 // Size: 0x08
	struct UActivity_EightDays_Item_Small_UIBP_C* Activity_Novice_DailyItem3; // Offset: 0x270 // Size: 0x08
	struct UActivity_EightDays_Item_Small_UIBP_C* Activity_Novice_DailyItem4; // Offset: 0x278 // Size: 0x08
	struct UActivity_EightDays_Item_Small_UIBP_C* Activity_Novice_DailyItem5; // Offset: 0x280 // Size: 0x08
	struct UActivity_EightDays_Item_Small_UIBP_C* Activity_Novice_DailyItem6; // Offset: 0x288 // Size: 0x08
	struct UActivity_EightDays_Item_Small_UIBP_C* Activity_Novice_DailyItem7; // Offset: 0x290 // Size: 0x08
	struct UActivity_EightDays_Item_Big_UIBP_C* Activity_Novice_DailyItem8; // Offset: 0x298 // Size: 0x08
	struct UButton* Button_CloseUI; // Offset: 0x2a0 // Size: 0x08
	struct UCommon_BackgroundBlur_C* Common_BackgroundBlur; // Offset: 0x2a8 // Size: 0x08
	struct UCommon_UIPopupBG_C* Common_UIPopupBG; // Offset: 0x2b0 // Size: 0x08
	struct UScaleBox* ScaleBox_IPX; // Offset: 0x2b8 // Size: 0x08
	struct UTextBlock* TextBlock_3; // Offset: 0x2c0 // Size: 0x08
	struct UTextBlock* TextBlock_5; // Offset: 0x2c8 // Size: 0x08
	struct UTextBlock* TextBlock_RefreshTime; // Offset: 0x2d0 // Size: 0x08
	struct UTextBlock* TextBlock_Time; // Offset: 0x2d8 // Size: 0x08
};

