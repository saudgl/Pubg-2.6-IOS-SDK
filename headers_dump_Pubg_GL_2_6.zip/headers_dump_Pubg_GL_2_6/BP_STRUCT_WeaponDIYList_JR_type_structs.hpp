//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_WeaponDIYList_JR_type.BP_STRUCT_WeaponDIYList_JR_type
// Size: 0x18c // Inherited bytes: 0x00
struct FBP_STRUCT_WeaponDIYList_JR_type {
	// Fields
	struct FString begin_time_0_3E6DA4000A58231C3FFF63070DAC9585; // Offset: 0x00 // Size: 0x10
	struct FString DefaultIcon_1_4B0812C01B0F1DF95CA4808F02B944EE; // Offset: 0x10 // Size: 0x10
	int DefaultStep_2_2CDC578044A3549E5C992FC702B81070; // Offset: 0x20 // Size: 0x04
	int DIYMaxIcon_3_548B84803A6B927C2E8EF1F70024C89E; // Offset: 0x24 // Size: 0x04
	int DIYMaxLayer_4_772741804E1C1D0851BA1A8F025163C2; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString icon0_5_2D89D58004B917CE1E3C61AA0AA4A420; // Offset: 0x30 // Size: 0x10
	struct FString icon1_6_2D8AD5C004B917CF1E3C61A90AA4A421; // Offset: 0x40 // Size: 0x10
	struct FString icon2_7_2D8BD60004B917D01E3C61A80AA4A422; // Offset: 0x50 // Size: 0x10
	struct FString icon3_8_2D8CD64004B917D11E3C61970AA4A423; // Offset: 0x60 // Size: 0x10
	struct FString icon4_9_2D8DD68004B917D21E3C61960AA4A424; // Offset: 0x70 // Size: 0x10
	int ID_10_4E5A628049A378BA5CF9D55E0063A864; // Offset: 0x80 // Size: 0x04
	char pad_0x84[0x4]; // Offset: 0x84 // Size: 0x04
	struct FString name_11_66F16780456CBBC6661FDA1D03ABF855; // Offset: 0x88 // Size: 0x10
	struct FString part0_12_028B99003B15D1423D366DFB0ABD8F40; // Offset: 0x98 // Size: 0x10
	struct FString part1_13_028C99403B15D1433D366DF40ABD8F41; // Offset: 0xa8 // Size: 0x10
	struct FString part2_14_028D99803B15D1443D366DF50ABD8F42; // Offset: 0xb8 // Size: 0x10
	struct FString part3_15_028E99C03B15D1453D366DF60ABD8F43; // Offset: 0xc8 // Size: 0x10
	struct FString part4_16_028F9A003B15D1463D366DF70ABD8F44; // Offset: 0xd8 // Size: 0x10
	int Sort_17_760E694053F5201F6022DA1103A936F4; // Offset: 0xe8 // Size: 0x04
	char pad_0xEC[0x4]; // Offset: 0xec // Size: 0x04
	struct FString preName_18_16CC114039448EA17AEC888E0C907E85; // Offset: 0xf0 // Size: 0x10
	struct FString icon_select0_19_2B78AD402C8C423F444C73210408FBB0; // Offset: 0x100 // Size: 0x10
	struct FString icon_select1_20_2B79AD802C8C4240444C73200408FBB1; // Offset: 0x110 // Size: 0x10
	struct FString icon_select2_21_2B7AADC02C8C4241444C73270408FBB2; // Offset: 0x120 // Size: 0x10
	struct FString icon_select3_22_2B7BAE002C8C4242444C73260408FBB3; // Offset: 0x130 // Size: 0x10
	struct FString icon_select4_23_2B7CAE402C8C4243444C73250408FBB4; // Offset: 0x140 // Size: 0x10
	int direction0_24_657D9B807C1E154618E04DA20800E6F0; // Offset: 0x150 // Size: 0x04
	int direction1_25_657E9BC07C1E154718E04DA30800E6F1; // Offset: 0x154 // Size: 0x04
	int direction2_26_657F9C007C1E154818E04DA40800E6F2; // Offset: 0x158 // Size: 0x04
	int direction3_27_65809C407C1E154918E04DA50800E6F3; // Offset: 0x15c // Size: 0x04
	int direction4_28_65819C807C1E154A18E04DA60800E6F4; // Offset: 0x160 // Size: 0x04
	int slotType0_29_23B0A4400C5CD8AD2B803EC100A2B5B0; // Offset: 0x164 // Size: 0x04
	int slotType1_30_23B1A4800C5CD8AE2B803EC200A2B5B1; // Offset: 0x168 // Size: 0x04
	int slotType2_31_23B2A4C00C5CD8AF2B803EC300A2B5B2; // Offset: 0x16c // Size: 0x04
	int slotType3_32_23B3A5000C5CD8B02B803ECC00A2B5B3; // Offset: 0x170 // Size: 0x04
	int slotType4_33_23B4A5400C5CD8B12B803ECD00A2B5B4; // Offset: 0x174 // Size: 0x04
	int banDecal0_34_1E428DC06418925D4ACA947404913470; // Offset: 0x178 // Size: 0x04
	int banDecal1_35_1E438E006418925E4ACA947704913471; // Offset: 0x17c // Size: 0x04
	int banDecal2_36_1E448E406418925F4ACA947604913472; // Offset: 0x180 // Size: 0x04
	int banDecal3_37_1E458E80641892604ACA947104913473; // Offset: 0x184 // Size: 0x04
	int banDecal4_38_1E468EC0641892614ACA947004913474; // Offset: 0x188 // Size: 0x04
};

