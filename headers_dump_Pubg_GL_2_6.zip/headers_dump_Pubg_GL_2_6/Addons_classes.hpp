//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Addons.AnimPoseRecorder
// Size: 0xe8 // Inherited bytes: 0x28
struct UAnimPoseRecorder : UObject {
	// Fields
	char pad_0x28[0xc0]; // Offset: 0x28 // Size: 0xc0
};

// Object Name: Class Addons.AssetPlayerSyncNode
// Size: 0xc8 // Inherited bytes: 0x28
struct UAssetPlayerSyncNode : UObject {
	// Fields
	struct TMap<struct FName, float> SyncGroupInternalTimerMap; // Offset: 0x28 // Size: 0x50
	struct TMap<struct FName, int> SyncGroupSequenceIndexMap; // Offset: 0x78 // Size: 0x50

	// Functions

	// Object Name: Function Addons.AssetPlayerSyncNode.SetGroupTimer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGroupTimer(struct FName GroupName, float InternalTime); // Offset: 0x103ecfe68 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Addons.AssetPlayerSyncNode.SetGroupIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGroupIndex(struct FName GroupName, int SequenceIndex); // Offset: 0x103ecfdb0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Addons.AssetPlayerSyncNode.GetGroupTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetGroupTime(struct FName GroupName); // Offset: 0x103ecfd24 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Addons.AssetPlayerSyncNode.GetGroupIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetGroupIndex(struct FName GroupName); // Offset: 0x103ecfc98 // Return & Params: Num(2) Size(0xc)
};

// Object Name: Class Addons.BioVehicleAnimInstanceBase
// Size: 0x600 // Inherited bytes: 0x3c0
struct UBioVehicleAnimInstanceBase : UAnimInstance {
	// Fields
	char pad_0x3C0[0x60]; // Offset: 0x3c0 // Size: 0x60
	struct TArray<float> LOD_Level_DistanceFactor; // Offset: 0x420 // Size: 0x10
	bool bEnableTerrainAdapting; // Offset: 0x430 // Size: 0x01
	bool bEnableRootPositionAdaption; // Offset: 0x431 // Size: 0x01
	bool bEnableRootRotationAdaption; // Offset: 0x432 // Size: 0x01
	bool bEnableFootPositionAdaption; // Offset: 0x433 // Size: 0x01
	bool bEnableFootRotationAdaption; // Offset: 0x434 // Size: 0x01
	char pad_0x435[0x3]; // Offset: 0x435 // Size: 0x03
	struct TMap<int, int> DeviceLevelToEvaluateSkipMap; // Offset: 0x438 // Size: 0x50
	int DefaultSkipEvaluateTimes; // Offset: 0x488 // Size: 0x04
	char pad_0x48C[0x4]; // Offset: 0x48c // Size: 0x04
	struct ABioVehicleBase* OwnerVehicle; // Offset: 0x490 // Size: 0x08
	bool bIsServer; // Offset: 0x498 // Size: 0x01
	bool bIsDead; // Offset: 0x499 // Size: 0x01
	bool bHasBeenTamed; // Offset: 0x49a // Size: 0x01
	bool bAnimVarHasCached; // Offset: 0x49b // Size: 0x01
	bool bHasDrivers; // Offset: 0x49c // Size: 0x01
	bool bHasAnyPassengers; // Offset: 0x49d // Size: 0x01
	char pad_0x49E[0x2]; // Offset: 0x49e // Size: 0x02
	float CurrentDistanceFactor; // Offset: 0x4a0 // Size: 0x04
	int EvaluateSkipTimes; // Offset: 0x4a4 // Size: 0x04
	int AnimLOD; // Offset: 0x4a8 // Size: 0x04
	char pad_0x4AC[0x4]; // Offset: 0x4ac // Size: 0x04
	struct FScriptMulticastDelegate OnAnimLODChanged; // Offset: 0x4b0 // Size: 0x10
	struct UAnimSequence* DeathAnim; // Offset: 0x4c0 // Size: 0x08
	struct TWeakObjectPtr<struct UBioVehicleRiderAnimInstanceBase> DriverAnimInstance; // Offset: 0x4c8 // Size: 0x08
	char pad_0x4D0[0x8]; // Offset: 0x4d0 // Size: 0x08
	struct FString LuaFilePath; // Offset: 0x4d8 // Size: 0x10
	struct TArray<enum class ECollisionChannel> TerrainAdaption_ObjectTypesToQuery; // Offset: 0x4e8 // Size: 0x10
	bool bShouldUseSkipQueryOpt; // Offset: 0x4f8 // Size: 0x01
	char pad_0x4F9[0x7]; // Offset: 0x4f9 // Size: 0x07
	struct FName RootTraceBoneName; // Offset: 0x500 // Size: 0x08
	float RootTraceSphereRadius; // Offset: 0x508 // Size: 0x04
	float RootOffsetMaxZ; // Offset: 0x50c // Size: 0x04
	float RootOffsetMaxPitch; // Offset: 0x510 // Size: 0x04
	float RootPositionLerpSpeed; // Offset: 0x514 // Size: 0x04
	float RootRotationLerpSpeed; // Offset: 0x518 // Size: 0x04
	float RootTraceUpOffset; // Offset: 0x51c // Size: 0x04
	float RootTraceDownOffset; // Offset: 0x520 // Size: 0x04
	char pad_0x524[0x4]; // Offset: 0x524 // Size: 0x04
	struct FName LeftFootTraceBoneName; // Offset: 0x528 // Size: 0x08
	struct FName RightFootTraceBoneName; // Offset: 0x530 // Size: 0x08
	float FootTraceSphereRadius; // Offset: 0x538 // Size: 0x04
	float FootPositionLerpSpeed; // Offset: 0x53c // Size: 0x04
	float FootRotationLerpSpeed; // Offset: 0x540 // Size: 0x04
	float FootOffsetMaxZ; // Offset: 0x544 // Size: 0x04
	float FootOffsetMaxPitch; // Offset: 0x548 // Size: 0x04
	float FootOffsetMaxRoll; // Offset: 0x54c // Size: 0x04
	float FootTraceUpOffset; // Offset: 0x550 // Size: 0x04
	float FootTraceDownOffset; // Offset: 0x554 // Size: 0x04
	enum class EBioVehicleTerrainAdaptingType TerrainAdaptingType; // Offset: 0x558 // Size: 0x01
	char pad_0x559[0x3]; // Offset: 0x559 // Size: 0x03
	float LeftFootOffsetZ; // Offset: 0x55c // Size: 0x04
	struct FRotator LeftFootRotatorOffset; // Offset: 0x560 // Size: 0x0c
	float RightFootOffsetZ; // Offset: 0x56c // Size: 0x04
	struct FRotator RightFootRotatorOffset; // Offset: 0x570 // Size: 0x0c
	float RootOffsetZ; // Offset: 0x57c // Size: 0x04
	float RootOffsetPitch; // Offset: 0x580 // Size: 0x04
	char pad_0x584[0x7c]; // Offset: 0x584 // Size: 0x7c

	// Functions

	// Object Name: Function Addons.BioVehicleAnimInstanceBase.UpdateTerrainAdapting
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void UpdateTerrainAdapting(float DeltaSeconds); // Offset: 0x103ed07cc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleAnimInstanceBase.TraceQuery
	// Flags: [Final|Native|Protected]
	void TraceQuery(); // Offset: 0x103ed07b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.BioVehicleAnimInstanceBase.NotifyDriverToDoTransition
	// Flags: [Final|Native|Public|BlueprintCallable]
	void NotifyDriverToDoTransition(struct FString ToStateMachineName); // Offset: 0x103ed06fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Addons.BioVehicleAnimInstanceBase.LuaOnAnimLodChanged
	// Flags: [Native|Event|Public|BlueprintEvent]
	void LuaOnAnimLodChanged(int NewAnimLod); // Offset: 0x103ed0678 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleAnimInstanceBase.LuaInitializeWithDeviceLevel
	// Flags: [Native|Event|Public|BlueprintEvent]
	void LuaInitializeWithDeviceLevel(int DeviceLevel); // Offset: 0x103ed05f4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleAnimInstanceBase.LuaInitializeAnimation
	// Flags: [Native|Event|Public|BlueprintEvent]
	void LuaInitializeAnimation(); // Offset: 0x103ed05d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.BioVehicleAnimInstanceBase.LuaCacheAnimVarWithAnimList
	// Flags: [Native|Event|Public|BlueprintEvent]
	void LuaCacheAnimVarWithAnimList(struct UBioVehicleAnimListComponent* RiderAnimListComponent); // Offset: 0x103ed0554 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Addons.BioVehicleAnimInstanceBase.GetDriverAnimInstance
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UBioVehicleRiderAnimInstanceBase* GetDriverAnimInstance(); // Offset: 0x103ed0520 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Addons.BioVehicleAnimInstanceBase.CacheAnimVarWithAnimList
	// Flags: [Native|Public|BlueprintCallable]
	void CacheAnimVarWithAnimList(struct UBioVehicleAnimListComponent* AnimListComponent); // Offset: 0x103ed049c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Addons.BioVehicleAnimInstanceBase.BoneTrace
	// Flags: [Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable]
	bool BoneTrace(struct FName BoneName, float UpOffset, float DownOffset, float TraceSphereRadius, struct FVector& ImpactPoint, struct FVector& ImpactNormal); // Offset: 0x103ed02d0 // Return & Params: Num(7) Size(0x2d)
};

// Object Name: Class Addons.BioVehicleAnimListComponent
// Size: 0x190 // Inherited bytes: 0x110
struct UBioVehicleAnimListComponent : UActorComponent {
	// Fields
	bool bEnableAnimListOnDS; // Offset: 0x110 // Size: 0x01
	char pad_0x111[0x7]; // Offset: 0x111 // Size: 0x07
	struct TArray<struct FBioVehicleRiderAnim> BioVehicleRiderAnimData; // Offset: 0x118 // Size: 0x10
	struct FScriptMulticastDelegate OnAnimListLoadingFinished; // Offset: 0x128 // Size: 0x10
	char pad_0x138[0x8]; // Offset: 0x138 // Size: 0x08
	struct TMap<enum class EBioVehiclePoseType, struct UAnimationAsset*> BioVehicleRiderAnimDataMap; // Offset: 0x140 // Size: 0x50
};

// Object Name: Class Addons.BioVehicleBase
// Size: 0x17c0 // Inherited bytes: 0x1450
struct ABioVehicleBase : ASTExtraVehicleBase {
	// Fields
	char pad_0x1450[0x8]; // Offset: 0x1450 // Size: 0x08
	struct FScriptMulticastDelegate OnBioVehicleFrozen; // Offset: 0x1458 // Size: 0x10
	struct FScriptMulticastDelegate OnBioVehicleRunOutFuel; // Offset: 0x1468 // Size: 0x10
	bool bFuelExhausted; // Offset: 0x1478 // Size: 0x01
	char pad_0x1479[0x7]; // Offset: 0x1479 // Size: 0x07
	struct UBioVehicleMovementComponent* VehicleMovement; // Offset: 0x1480 // Size: 0x08
	struct UCapsuleComponent* CapsuleComponent; // Offset: 0x1488 // Size: 0x08
	struct UBoxComponent* BodyBoxComponent; // Offset: 0x1490 // Size: 0x08
	struct UCapsuleComponent* HeadCapsuleComponent; // Offset: 0x1498 // Size: 0x08
	struct UVehicleSpringArmComponent* BioVehicleSpringArm; // Offset: 0x14a0 // Size: 0x08
	struct FScriptMulticastDelegate OnBeginAccelerate; // Offset: 0x14a8 // Size: 0x10
	struct FScriptMulticastDelegate OnEndAccelerate; // Offset: 0x14b8 // Size: 0x10
	bool bHasAcceleration; // Offset: 0x14c8 // Size: 0x01
	bool bHasAccelerationLastFrame; // Offset: 0x14c9 // Size: 0x01
	char pad_0x14CA[0x1e]; // Offset: 0x14ca // Size: 0x1e
	struct FBasedMovementInfo BasedMovement; // Offset: 0x14e8 // Size: 0x30
	struct FBasedMovementInfo ReplicatedBasedMovement; // Offset: 0x1518 // Size: 0x30
	struct FVector BaseTranslationOffset; // Offset: 0x1548 // Size: 0x0c
	char pad_0x1554[0xc]; // Offset: 0x1554 // Size: 0x0c
	struct FQuat BaseRotationOffset; // Offset: 0x1560 // Size: 0x10
	bool bInBaseReplication; // Offset: 0x1570 // Size: 0x01
	char pad_0x1571[0xf]; // Offset: 0x1571 // Size: 0x0f
	struct FRootMotionMovementParams ClientRootMotionParams; // Offset: 0x1580 // Size: 0x40
	bool bCanVehicleJump; // Offset: 0x15c0 // Size: 0x01
	char bSimGravityDisabled : 1; // Offset: 0x15c1 // Size: 0x01
	char bPressedJump : 1; // Offset: 0x15c1 // Size: 0x01
	char bWasJumping : 1; // Offset: 0x15c1 // Size: 0x01
	char pad_0x15C1_3 : 5; // Offset: 0x15c1 // Size: 0x01
	char pad_0x15C2[0x2]; // Offset: 0x15c2 // Size: 0x02
	float JumpKeyHoldTime; // Offset: 0x15c4 // Size: 0x04
	float JumpForceTimeRemaining; // Offset: 0x15c8 // Size: 0x04
	float ProxyJumpForceStartedTime; // Offset: 0x15cc // Size: 0x04
	float JumpMaxHoldTime; // Offset: 0x15d0 // Size: 0x04
	int JumpMaxCount; // Offset: 0x15d4 // Size: 0x04
	int JumpCurrentCount; // Offset: 0x15d8 // Size: 0x04
	float BioVehicleLaunchCollDownTime; // Offset: 0x15dc // Size: 0x04
	struct FScriptMulticastDelegate OnReachedJumpApex; // Offset: 0x15e0 // Size: 0x10
	char pad_0x15F0[0x10]; // Offset: 0x15f0 // Size: 0x10
	struct FScriptMulticastDelegate MovementModeChangedDelegate; // Offset: 0x1600 // Size: 0x10
	struct FScriptMulticastDelegate OnBioVehicleJumped; // Offset: 0x1610 // Size: 0x10
	struct FScriptMulticastDelegate OnCharacterMovementUpdated; // Offset: 0x1620 // Size: 0x10
	char ReplicatedMovementMode; // Offset: 0x1630 // Size: 0x01
	char bClientCheckEncroachmentOnNetUpdate : 1; // Offset: 0x1631 // Size: 0x01
	char bClientUpdating : 1; // Offset: 0x1631 // Size: 0x01
	char bClientWasFalling : 1; // Offset: 0x1631 // Size: 0x01
	char pad_0x1631_3 : 5; // Offset: 0x1631 // Size: 0x01
	char pad_0x1632[0xa]; // Offset: 0x1632 // Size: 0x0a
	bool HasBeenTamed; // Offset: 0x163c // Size: 0x01
	char pad_0x163D[0xf]; // Offset: 0x163d // Size: 0x0f
	bool bCanbeDamagedByTrex; // Offset: 0x164c // Size: 0x01
	bool bShouldGenerateStaticDeadBodyWhileDeath; // Offset: 0x164d // Size: 0x01
	char pad_0x164E[0x2]; // Offset: 0x164e // Size: 0x02
	float OverlapTestScale; // Offset: 0x1650 // Size: 0x04
	char pad_0x1654[0x4]; // Offset: 0x1654 // Size: 0x04
	struct FName AnimCompTagName; // Offset: 0x1658 // Size: 0x08
	struct FScriptMulticastDelegate OnBioVehicleBeenTamed; // Offset: 0x1660 // Size: 0x10
	struct USkeletalMesh* UntamedMesh; // Offset: 0x1670 // Size: 0x08
	struct USkeletalMesh* TamedMesh; // Offset: 0x1678 // Size: 0x08
	struct TMap<struct FName, struct FFootStepEffect> FootStepEffects; // Offset: 0x1680 // Size: 0x50
	struct TMap<struct FName, struct UParticleSystemComponent*> FootStepEffectRuntimeData; // Offset: 0x16d0 // Size: 0x50
	struct FScriptMulticastDelegate OnAnimInstanceActive; // Offset: 0x1720 // Size: 0x10
	bool bShouldPlayRandomIdleWhilePassengersOn; // Offset: 0x1730 // Size: 0x01
	char pad_0x1731[0x3]; // Offset: 0x1731 // Size: 0x03
	float RandomIdleResetTimeMin; // Offset: 0x1734 // Size: 0x04
	float RandomIdleResetTimeMax; // Offset: 0x1738 // Size: 0x04
	int RandomIdleIndexMin; // Offset: 0x173c // Size: 0x04
	int RandomIdleIndexMax; // Offset: 0x1740 // Size: 0x04
	char pad_0x1744[0x4]; // Offset: 0x1744 // Size: 0x04
	struct FScriptMulticastDelegate OnBioVehicleDoRandomIdle; // Offset: 0x1748 // Size: 0x10
	char pad_0x1758[0x8]; // Offset: 0x1758 // Size: 0x08
	bool bEnableSimulatedOptimize; // Offset: 0x1760 // Size: 0x01
	char pad_0x1761[0x7]; // Offset: 0x1761 // Size: 0x07
	struct TArray<struct FSimulateThresholds> BioVehicleSimulateThresholds; // Offset: 0x1768 // Size: 0x10
	bool bEnableCollisionOptimization; // Offset: 0x1778 // Size: 0x01
	char pad_0x1779[0x3]; // Offset: 0x1779 // Size: 0x03
	float OpenCollisionMinDistSq; // Offset: 0x177c // Size: 0x04
	float ShooterOpenCollisionMaxCosTheta; // Offset: 0x1780 // Size: 0x04
	char pad_0x1784[0x4]; // Offset: 0x1784 // Size: 0x04
	struct TArray<struct FOpenCollisionLODAngle> BioVehicleCollisionDistSqAngles; // Offset: 0x1788 // Size: 0x10
	float CheckCollisionOpenInternal; // Offset: 0x1798 // Size: 0x04
	char pad_0x179C[0x4]; // Offset: 0x179c // Size: 0x04
	struct FName CreatureVehicleMesh_ProfileName; // Offset: 0x17a0 // Size: 0x08
	bool bDebugCollisionLine; // Offset: 0x17a8 // Size: 0x01
	char pad_0x17A9[0xf]; // Offset: 0x17a9 // Size: 0x0f
	struct ASTExtraBaseCharacter* CacheNearlyCharacer; // Offset: 0x17b8 // Size: 0x08

	// Functions

	// Object Name: Function Addons.BioVehicleBase.StopJumping
	// Flags: [Native|Public|BlueprintCallable]
	void StopJumping(); // Offset: 0x103ed2328 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.BioVehicleBase.SetSimulatePhysics
	// Flags: [Native|Public|BlueprintCallable]
	void SetSimulatePhysics(bool bSimulate); // Offset: 0x103ed229c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.BioVehicleBase.SetReplicateMovement
	// Flags: [Native|Public|BlueprintCallable]
	void SetReplicateMovement(bool bInReplicateMovement); // Offset: 0x103ed2210 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.BioVehicleBase.SetHandBrake
	// Flags: [Native|Public|BlueprintCallable]
	void SetHandBrake(float Rate); // Offset: 0x103ed218c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleBase.SetBoosting
	// Flags: [Native|Public|BlueprintCallable]
	void SetBoosting(bool bEnalbed); // Offset: 0x103ed2100 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.BioVehicleBase.ServerResetToPosition
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	void ServerResetToPosition(struct FVector NewLocation, struct FRotator NewRotation); // Offset: 0x103ed2040 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Addons.BioVehicleBase.OnWalkingOffLedge
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	void OnWalkingOffLedge(struct FVector& PreviousFloorImpactNormal, struct FVector& PreviousFloorContactNormal, struct FVector& PreviousLocation, float TimeDelta); // Offset: 0x103ed1ed4 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Addons.BioVehicleBase.OnTakingDamage
	// Flags: [Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	void OnTakingDamage(struct AActor* HitActor, struct AActor* HitInstigator, struct FHitResult& HitInfo, struct FVector& ImpulseDir, float Damage); // Offset: 0x103ed1cec // Return & Params: Num(5) Size(0xb8)

	// Object Name: Function Addons.BioVehicleBase.OnRep_ReplicatedBasedMovement
	// Flags: [Native|Public]
	void OnRep_ReplicatedBasedMovement(); // Offset: 0x103ed1cd0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.BioVehicleBase.OnRep_HasBeenTamed
	// Flags: [Final|Native|Public]
	void OnRep_HasBeenTamed(); // Offset: 0x103ed1cbc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.BioVehicleBase.OnRep_FuelExhausted
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnRep_FuelExhausted(bool bPrevFuelExhausted); // Offset: 0x103ed1c38 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.BioVehicleBase.OnLaunched
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	void OnLaunched(struct FVector& LaunchVelocity, bool bXYOverride, bool bZOverride); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0xe)

	// Object Name: Function Addons.BioVehicleBase.OnLanded
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void OnLanded(struct FHitResult& Hit); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x98)

	// Object Name: Function Addons.BioVehicleBase.OnJumped
	// Flags: [Native|Event|Public|BlueprintEvent]
	void OnJumped(); // Offset: 0x103ed1c1c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.BioVehicleBase.OnExitingVehicleOnServer
	// Flags: [Event|Public|BlueprintEvent]
	void OnExitingVehicleOnServer(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.BioVehicleBase.OnEnteringVehicleOnServer
	// Flags: [Event|Public|BlueprintEvent]
	void OnEnteringVehicleOnServer(bool IsSucc); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.BioVehicleBase.OnAnimListLoadFinished
	// Flags: [Final|Native|Public]
	void OnAnimListLoadFinished(struct UBioVehicleAnimListComponent* AnimListComponent); // Offset: 0x103ed1ba0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Addons.BioVehicleBase.MoveUp
	// Flags: [Native|Public|BlueprintCallable]
	void MoveUp(float Rate); // Offset: 0x103ed1b1c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleBase.LaunchCharacter
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void LaunchCharacter(struct FVector& LaunchVelocity, bool bXYOverride, bool bZOverride); // Offset: 0x103ed19fc // Return & Params: Num(3) Size(0xe)

	// Object Name: Function Addons.BioVehicleBase.K2_UpdateCustomMovement
	// Flags: [Event|Public|BlueprintEvent]
	void K2_UpdateCustomMovement(float DeltaTime); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleBase.K2_OnMovementModeChanged
	// Flags: [Event|Public|BlueprintEvent]
	void K2_OnMovementModeChanged(enum class EMovementMode PrevMovementMode, enum class EMovementMode NewMovementMode, char PrevCustomMode, char NewCustomMode); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x4)

	// Object Name: Function Addons.BioVehicleBase.Jump
	// Flags: [Native|Public|BlueprintCallable]
	void Jump(); // Offset: 0x103ed19e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.BioVehicleBase.IsPlayingRootMotion
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPlayingRootMotion(); // Offset: 0x103ed19ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.BioVehicleBase.IsJumpProvidingForce
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsJumpProvidingForce(); // Offset: 0x103ed1970 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.BioVehicleBase.HandleOnRiderAnimInstanceActive
	// Flags: [Native|Public]
	void HandleOnRiderAnimInstanceActive(struct UAnimInstance* ActivedAnimInstance); // Offset: 0x103ed18ec // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Addons.BioVehicleBase.HandleOnClientBeenTamed
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void HandleOnClientBeenTamed(); // Offset: 0x103ed18d0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.BioVehicleBase.GetVehicleOriginToLand
	// Flags: [Native|Public]
	float GetVehicleOriginToLand(); // Offset: 0x103ed1894 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleBase.GetVehicleBreakOutState
	// Flags: [Native|Public]
	bool GetVehicleBreakOutState(); // Offset: 0x103ed1858 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.BioVehicleBase.GetRotationInputDir
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	struct FVector GetRotationInputDir(); // Offset: 0x103ed1818 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Addons.BioVehicleBase.GetPlayerLookAtRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FRotator GetPlayerLookAtRotation(); // Offset: 0x103ed17e0 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Addons.BioVehicleBase.GetConsumeFuelRate
	// Flags: [Native|Public|Const]
	float GetConsumeFuelRate(); // Offset: 0x103ed17a4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleBase.GetBodyShapeComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UBoxComponent* GetBodyShapeComponent(); // Offset: 0x103ed1788 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Addons.BioVehicleBase.GetBioVehicleMovement
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UBioVehicleMovementComponent* GetBioVehicleMovement(); // Offset: 0x103ed176c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Addons.BioVehicleBase.GetBaseTranslationOffset
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetBaseTranslationOffset(); // Offset: 0x103ed1748 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Addons.BioVehicleBase.ExitVehicle
	// Flags: [Final|Native|Public]
	void ExitVehicle(); // Offset: 0x103ed1734 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.BioVehicleBase.EnterVehicle
	// Flags: [Final|Native|Public]
	void EnterVehicle(bool IsSucc); // Offset: 0x103ed16b0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.BioVehicleBase.ClientEnterVehicle
	// Flags: [Final|Native|Public]
	void ClientEnterVehicle(struct ASTExtraPlayerCharacter* Character, enum class ESTExtraVehicleSeatType SeatType); // Offset: 0x103ed15f8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Addons.BioVehicleBase.CanJumpInternal
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	bool CanJumpInternal(); // Offset: 0x103ed15bc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.BioVehicleBase.CanJump
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool CanJump(); // Offset: 0x103ed1588 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.BioVehicleBase.CanConsumeFuel
	// Flags: [Native|Public|Const]
	bool CanConsumeFuel(); // Offset: 0x103ed154c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.BioVehicleBase.CanCharacterEnterVehicle
	// Flags: [Native|Public|BlueprintCallable]
	bool CanCharacterEnterVehicle(struct ASTExtraPlayerCharacter* InCharacter, enum class ESTExtraVehicleSeatType SeatType); // Offset: 0x103ed147c // Return & Params: Num(3) Size(0xa)

	// Object Name: Function Addons.BioVehicleBase.CacheInitialMeshOffset
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	void CacheInitialMeshOffset(struct FVector MeshRelativeLocation, struct FRotator MeshRelativeRotation); // Offset: 0x103ed13bc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Addons.BioVehicleBase.BroadCastPlayingRandomIdleAnim
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void BroadCastPlayingRandomIdleAnim(int RandomIdleAnim); // Offset: 0x103ed1338 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleBase.BPCanCharacterEnterVehicle
	// Flags: [Event|Public|BlueprintEvent]
	bool BPCanCharacterEnterVehicle(struct ASTExtraPlayerCharacter* InCharacter); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Addons.BioVehicleBase.ActiveFootParticleEffect
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void ActiveFootParticleEffect(struct FName EffectName, struct FVector ActivedLocation); // Offset: 0x103ed1280 // Return & Params: Num(2) Size(0x14)
};

// Object Name: Class Addons.BioVehicleDamageComponent
// Size: 0x4f0 // Inherited bytes: 0x4d0
struct UBioVehicleDamageComponent : UVehicleDamageComponent {
	// Fields
	float HitByVehicleImpulseScale; // Offset: 0x4c8 // Size: 0x04
	float VehicleDamageBioVehicleFactor; // Offset: 0x4cc // Size: 0x04
	float MaxHitByVehicleImpulseVelocity; // Offset: 0x4d0 // Size: 0x04
	float MinHitByVehicleImpulseVelocity; // Offset: 0x4d4 // Size: 0x04
	float ImpulseSelfCD; // Offset: 0x4d8 // Size: 0x04
	char pad_0x4E4[0xc]; // Offset: 0x4e4 // Size: 0x0c
};

// Object Name: Class Addons.BioVehicleMovementComponent
// Size: 0xaf0 // Inherited bytes: 0x190
struct UBioVehicleMovementComponent : UPawnMovementComponent {
	// Fields
	char pad_0x190[0x10]; // Offset: 0x190 // Size: 0x10
	char bHasRequestedVelocity : 1; // Offset: 0x1a0 // Size: 0x01
	char bNeedSLerpRequestedVelocity : 1; // Offset: 0x1a0 // Size: 0x01
	char bRequestedMoveWithMaxSpeed : 1; // Offset: 0x1a0 // Size: 0x01
	char bWasAvoidanceUpdated : 1; // Offset: 0x1a0 // Size: 0x01
	char pad_0x1A0_4 : 2; // Offset: 0x1a0 // Size: 0x01
	char bProjectNavMeshWalking : 1; // Offset: 0x1a0 // Size: 0x01
	char bProjectNavMeshOnBothWorldChannels : 1; // Offset: 0x1a0 // Size: 0x01
	char bNeedSlowDownRequestedVelocity : 1; // Offset: 0x1a1 // Size: 0x01
	char pad_0x1A1_1 : 7; // Offset: 0x1a1 // Size: 0x01
	char pad_0x1A2[0x2]; // Offset: 0x1a2 // Size: 0x02
	float SlowDownRequestedVelocityFactor; // Offset: 0x1a4 // Size: 0x04
	char pad_0x1A8[0x10]; // Offset: 0x1a8 // Size: 0x10
	float GravityScale; // Offset: 0x1b8 // Size: 0x04
	enum class EMovementMode MovementMode; // Offset: 0x1bc // Size: 0x01
	char CustomMovementMode; // Offset: 0x1bd // Size: 0x01
	char pad_0x1BE[0x22]; // Offset: 0x1be // Size: 0x22
	float MaxStepHeight; // Offset: 0x1e0 // Size: 0x04
	float WalkableFloorAngle; // Offset: 0x1e4 // Size: 0x04
	float WalkableFloorZ; // Offset: 0x1e8 // Size: 0x04
	float WalkableHeadHitZ; // Offset: 0x1ec // Size: 0x04
	float StepForwardMinDelta; // Offset: 0x1f0 // Size: 0x04
	float GroundFriction; // Offset: 0x1f4 // Size: 0x04
	float MaxWalkSpeed; // Offset: 0x1f8 // Size: 0x04
	float MaxWalkSpeedCrouched; // Offset: 0x1fc // Size: 0x04
	bool bCanStandOnOthervehicle; // Offset: 0x200 // Size: 0x01
	char pad_0x201[0x3]; // Offset: 0x201 // Size: 0x03
	float MaxSwimSpeed; // Offset: 0x204 // Size: 0x04
	float MaxFlySpeed; // Offset: 0x208 // Size: 0x04
	float MaxFlyBackSpeed; // Offset: 0x20c // Size: 0x04
	float MaxCustomMovementSpeed; // Offset: 0x210 // Size: 0x04
	float MaxAcceleration; // Offset: 0x214 // Size: 0x04
	float MinAnalogWalkSpeed; // Offset: 0x218 // Size: 0x04
	float BrakingFrictionFactor; // Offset: 0x21c // Size: 0x04
	float BrakingFriction; // Offset: 0x220 // Size: 0x04
	float BrakingDecelerationWalking; // Offset: 0x224 // Size: 0x04
	float BrakingDecelerationFalling; // Offset: 0x228 // Size: 0x04
	float BrakingDecelerationSwimming; // Offset: 0x22c // Size: 0x04
	float SwimFriction; // Offset: 0x230 // Size: 0x04
	float BrakingDecelerationFlying; // Offset: 0x234 // Size: 0x04
	bool bEnableAirControl; // Offset: 0x238 // Size: 0x01
	char pad_0x239[0x7]; // Offset: 0x239 // Size: 0x07
	struct UCurveFloat* CurveAirControl; // Offset: 0x240 // Size: 0x08
	float AirControl; // Offset: 0x248 // Size: 0x04
	float AirControlBoostMultiplier; // Offset: 0x24c // Size: 0x04
	float AirControlBoostVelocityThreshold; // Offset: 0x250 // Size: 0x04
	float FallingLateralFriction; // Offset: 0x254 // Size: 0x04
	float CrouchedHalfHeight; // Offset: 0x258 // Size: 0x04
	float Buoyancy; // Offset: 0x25c // Size: 0x04
	float SwimVelocityZLimitScale; // Offset: 0x260 // Size: 0x04
	float FloatingUpZ; // Offset: 0x264 // Size: 0x04
	float PerchRadiusThreshold; // Offset: 0x268 // Size: 0x04
	float PerchAdditionalHeight; // Offset: 0x26c // Size: 0x04
	struct FRotator RotationRate; // Offset: 0x270 // Size: 0x0c
	float SmoothRotationLerpFactor; // Offset: 0x27c // Size: 0x04
	float RotateToCameraLerpSpeed; // Offset: 0x280 // Size: 0x04
	struct FRotator DeltaRotated; // Offset: 0x284 // Size: 0x0c
	char bUseControllerDesiredRotation : 1; // Offset: 0x290 // Size: 0x01
	char bOrientRotationToMovement : 1; // Offset: 0x290 // Size: 0x01
	char bNeedBackward : 1; // Offset: 0x290 // Size: 0x01
	char bSweepWhileNavWalking : 1; // Offset: 0x290 // Size: 0x01
	char bAutoFloatingUp : 1; // Offset: 0x290 // Size: 0x01
	char bSeriousInjuried : 1; // Offset: 0x290 // Size: 0x01
	char bJumpAllowedWhenSeriousInjuried : 1; // Offset: 0x290 // Size: 0x01
	char pad_0x290_7 : 1; // Offset: 0x290 // Size: 0x01
	char bMovementInProgress : 1; // Offset: 0x291 // Size: 0x01
	char bEnableScopedMovementUpdates : 1; // Offset: 0x291 // Size: 0x01
	char bForceMaxAccel : 1; // Offset: 0x291 // Size: 0x01
	char bRunPhysicsWithNoController : 1; // Offset: 0x291 // Size: 0x01
	char bForceNextFloorCheck : 1; // Offset: 0x291 // Size: 0x01
	char bShrinkProxyCapsule : 1; // Offset: 0x291 // Size: 0x01
	char bCanWalkOffLedges : 1; // Offset: 0x291 // Size: 0x01
	char bCanWalkOffLedgesWhenCrouching : 1; // Offset: 0x291 // Size: 0x01
	char pad_0x292[0x2]; // Offset: 0x292 // Size: 0x02
	float HeadCollisionScaleOnDS; // Offset: 0x294 // Size: 0x04
	bool bWalkingBlockHeadSlide; // Offset: 0x298 // Size: 0x01
	bool bWalkingDoubleCheckWhenPenetrate; // Offset: 0x299 // Size: 0x01
	char pad_0x29A[0x2]; // Offset: 0x29a // Size: 0x02
	float WalkingHeadPenetrateCheckRadius; // Offset: 0x29c // Size: 0x04
	float WalkingHeadPenetrateCheckHeight; // Offset: 0x2a0 // Size: 0x04
	bool bFallingBlockHeadSlide; // Offset: 0x2a4 // Size: 0x01
	bool bDoubleCheckSlide; // Offset: 0x2a5 // Size: 0x01
	char pad_0x2A6[0x2]; // Offset: 0x2a6 // Size: 0x02
	float HeadSlideCollisionScaleHeight; // Offset: 0x2a8 // Size: 0x04
	float HeadSlideCollisionScaleRadius; // Offset: 0x2ac // Size: 0x04
	float HeadSlideFallingCollisionScale; // Offset: 0x2b0 // Size: 0x04
	bool bHeadCheckSlope; // Offset: 0x2b4 // Size: 0x01
	bool AllowBodySlideSurface; // Offset: 0x2b5 // Size: 0x01
	bool bEableHeadBlockVelocityLimit; // Offset: 0x2b6 // Size: 0x01
	char pad_0x2B7[0x1]; // Offset: 0x2b7 // Size: 0x01
	float HeadBlockLimitVelocity; // Offset: 0x2b8 // Size: 0x04
	bool bEableHeadBlockLimitThrottle; // Offset: 0x2bc // Size: 0x01
	bool bLastHeadWalkingCheck; // Offset: 0x2bd // Size: 0x01
	char pad_0x2BE[0x2]; // Offset: 0x2be // Size: 0x02
	float bLastHeadRotationCheck; // Offset: 0x2c0 // Size: 0x04
	bool bClientResolveServerPenetration; // Offset: 0x2c4 // Size: 0x01
	char pad_0x2C5_0 : 1; // Offset: 0x2c5 // Size: 0x01
	char bNetworkSkipProxyPredictionOnNetUpdate : 1; // Offset: 0x2c5 // Size: 0x01
	char bForceNoSimulatePrediction : 1; // Offset: 0x2c5 // Size: 0x01
	char bDeferUpdateMoveComponent : 1; // Offset: 0x2c5 // Size: 0x01
	char pad_0x2C5_4 : 4; // Offset: 0x2c5 // Size: 0x01
	char pad_0x2C6[0x2]; // Offset: 0x2c6 // Size: 0x02
	struct USceneComponent* DeferredUpdatedMoveComponent; // Offset: 0x2c8 // Size: 0x08
	float MaxOutOfWaterStepHeight; // Offset: 0x2d0 // Size: 0x04
	float OutofWaterZ; // Offset: 0x2d4 // Size: 0x04
	float Mass; // Offset: 0x2d8 // Size: 0x04
	bool bEnablePhysicsInteraction; // Offset: 0x2dc // Size: 0x01
	bool bTouchForceScaledToMass; // Offset: 0x2dd // Size: 0x01
	bool bPushForceScaledToMass; // Offset: 0x2de // Size: 0x01
	bool bPushForceUsingZOffset; // Offset: 0x2df // Size: 0x01
	bool bScalePushForceToVelocity; // Offset: 0x2e0 // Size: 0x01
	char pad_0x2E1[0x3]; // Offset: 0x2e1 // Size: 0x03
	float StandingDownwardForceScale; // Offset: 0x2e4 // Size: 0x04
	float InitialPushForceFactor; // Offset: 0x2e8 // Size: 0x04
	float PushForceFactor; // Offset: 0x2ec // Size: 0x04
	float PushForcePointZOffsetFactor; // Offset: 0x2f0 // Size: 0x04
	float TouchForceFactor; // Offset: 0x2f4 // Size: 0x04
	float MinTouchForce; // Offset: 0x2f8 // Size: 0x04
	float MaxTouchForce; // Offset: 0x2fc // Size: 0x04
	float RepulsionForce; // Offset: 0x300 // Size: 0x04
	char pad_0x304[0x4]; // Offset: 0x304 // Size: 0x04
	struct FVector Acceleration; // Offset: 0x308 // Size: 0x0c
	struct FVector PendingDirectionalBrakingAccelerationToApply; // Offset: 0x314 // Size: 0x0c
	struct FVector LastUpdateLocation; // Offset: 0x320 // Size: 0x0c
	char pad_0x32C[0x4]; // Offset: 0x32c // Size: 0x04
	struct FQuat LastUpdateRotation; // Offset: 0x330 // Size: 0x10
	struct FVector LastUpdateVelocity; // Offset: 0x340 // Size: 0x0c
	float ServerLastTransformUpdateTimeStamp; // Offset: 0x34c // Size: 0x04
	struct FVector PendingImpulseToApply; // Offset: 0x350 // Size: 0x0c
	struct FVector PendingForceToApply; // Offset: 0x35c // Size: 0x0c
	float AnalogInputModifier; // Offset: 0x368 // Size: 0x04
	char pad_0x36C[0x8]; // Offset: 0x36c // Size: 0x08
	float MaxSimulationTimeStep; // Offset: 0x374 // Size: 0x04
	int MaxSimulationIterations; // Offset: 0x378 // Size: 0x04
	float MaxDepenetrationWithGeometry; // Offset: 0x37c // Size: 0x04
	float MaxDepenetrationWithGeometryAsProxy; // Offset: 0x380 // Size: 0x04
	float MaxDepenetrationWithPawn; // Offset: 0x384 // Size: 0x04
	float MaxDepenetrationWithPawnAsProxy; // Offset: 0x388 // Size: 0x04
	float NetworkSimulatedSmoothLocationTime; // Offset: 0x38c // Size: 0x04
	float NetworkSimulatedSmoothRotationTime; // Offset: 0x390 // Size: 0x04
	float ListenServerNetworkSimulatedSmoothLocationTime; // Offset: 0x394 // Size: 0x04
	float ListenServerNetworkSimulatedSmoothRotationTime; // Offset: 0x398 // Size: 0x04
	float NetProxyShrinkRadius; // Offset: 0x39c // Size: 0x04
	float NetProxyShrinkHalfHeight; // Offset: 0x3a0 // Size: 0x04
	float NetworkMaxSmoothUpdateDistance; // Offset: 0x3a4 // Size: 0x04
	float NetworkMaxSmoothScale; // Offset: 0x3a8 // Size: 0x04
	float NetworkNoSmoothUpdateDistance; // Offset: 0x3ac // Size: 0x04
	bool bReplaySmoothUseInterp; // Offset: 0x3b0 // Size: 0x01
	enum class ENetworkSmoothingMode NetworkSmoothingMode; // Offset: 0x3b1 // Size: 0x01
	char pad_0x3B2[0x2]; // Offset: 0x3b2 // Size: 0x02
	float LedgeCheckThreshold; // Offset: 0x3b4 // Size: 0x04
	float JumpOutOfWaterPitch; // Offset: 0x3b8 // Size: 0x04
	char pad_0x3BC[0x4]; // Offset: 0x3bc // Size: 0x04
	struct FFindFloorResult CurrentFloor; // Offset: 0x3c0 // Size: 0xa8
	enum class EMovementMode DefaultLandMovementMode; // Offset: 0x468 // Size: 0x01
	enum class EMovementMode DefaultWaterMovementMode; // Offset: 0x469 // Size: 0x01
	enum class EMovementMode GroundMovementMode; // Offset: 0x46a // Size: 0x01
	char bMaintainHorizontalGroundVelocity : 1; // Offset: 0x46b // Size: 0x01
	char bImpartBaseVelocityX : 1; // Offset: 0x46b // Size: 0x01
	char bImpartBaseVelocityY : 1; // Offset: 0x46b // Size: 0x01
	char bImpartBaseVelocityZ : 1; // Offset: 0x46b // Size: 0x01
	char bImpartBaseAngularVelocity : 1; // Offset: 0x46b // Size: 0x01
	char bJustTeleported : 1; // Offset: 0x46b // Size: 0x01
	char bNetworkUpdateReceived : 1; // Offset: 0x46b // Size: 0x01
	char bNetworkMovementModeChanged : 1; // Offset: 0x46b // Size: 0x01
	char bIgnoreClientMovementErrorChecksAndCorrection : 1; // Offset: 0x46c // Size: 0x01
	char bNotifyApex : 1; // Offset: 0x46c // Size: 0x01
	char bCheatFlying : 1; // Offset: 0x46c // Size: 0x01
	char bWantsToCrouch : 1; // Offset: 0x46c // Size: 0x01
	char bCustomAction0 : 1; // Offset: 0x46c // Size: 0x01
	char bCrouchMaintainsBaseLocation : 1; // Offset: 0x46c // Size: 0x01
	char bIgnoreBaseRotation : 1; // Offset: 0x46c // Size: 0x01
	char bFastAttachedMove : 1; // Offset: 0x46c // Size: 0x01
	char bAlwaysCheckFloor : 1; // Offset: 0x46d // Size: 0x01
	char bUseFlatBaseForFloorChecks : 1; // Offset: 0x46d // Size: 0x01
	char bPerformingJumpOff : 1; // Offset: 0x46d // Size: 0x01
	char bWantsToLeaveNavWalking : 1; // Offset: 0x46d // Size: 0x01
	char bUseRVOAvoidance : 1; // Offset: 0x46d // Size: 0x01
	char bRequestedMoveUseAcceleration : 1; // Offset: 0x46d // Size: 0x01
	char pad_0x46D_6 : 2; // Offset: 0x46d // Size: 0x01
	char pad_0x46E[0x2]; // Offset: 0x46e // Size: 0x02
	float AvoidanceConsiderationRadius; // Offset: 0x470 // Size: 0x04
	struct FVector RequestedVelocity; // Offset: 0x474 // Size: 0x0c
	int AvoidanceUID; // Offset: 0x480 // Size: 0x04
	struct FNavAvoidanceMask AvoidanceGroup; // Offset: 0x484 // Size: 0x04
	struct FNavAvoidanceMask GroupsToAvoid; // Offset: 0x488 // Size: 0x04
	struct FNavAvoidanceMask GroupsToIgnore; // Offset: 0x48c // Size: 0x04
	float AvoidanceWeight; // Offset: 0x490 // Size: 0x04
	struct FVector PendingLaunchVelocity; // Offset: 0x494 // Size: 0x0c
	char pad_0x4A0[0xb0]; // Offset: 0x4a0 // Size: 0xb0
	float NavMeshProjectionInterval; // Offset: 0x550 // Size: 0x04
	float NavMeshProjectionTimer; // Offset: 0x554 // Size: 0x04
	float NavMeshProjectionInterpSpeed; // Offset: 0x558 // Size: 0x04
	float NavMeshProjectionHeightScaleUp; // Offset: 0x55c // Size: 0x04
	float NavMeshProjectionHeightScaleDown; // Offset: 0x560 // Size: 0x04
	float NavWalkingFloorDistTolerance; // Offset: 0x564 // Size: 0x04
	float NavRotationFactor; // Offset: 0x568 // Size: 0x04
	float NavWantedSpeed; // Offset: 0x56c // Size: 0x04
	char bForceBraking : 1; // Offset: 0x570 // Size: 0x01
	char pad_0x570_1 : 7; // Offset: 0x570 // Size: 0x01
	char pad_0x571[0x3]; // Offset: 0x571 // Size: 0x03
	float CrouchedSpeedMultiplier; // Offset: 0x574 // Size: 0x04
	float UpperImpactNormalScale; // Offset: 0x578 // Size: 0x04
	char pad_0x57C[0x4]; // Offset: 0x57c // Size: 0x04
	struct FBioVehicleMovementPostPhysicsTickFunction PostPhysicsTickFunction; // Offset: 0x580 // Size: 0x58
	bool bEnableSimulatedVelocity; // Offset: 0x5d8 // Size: 0x01
	bool bSpectatorSmoothVelocity; // Offset: 0x5d9 // Size: 0x01
	char pad_0x5DA[0x2]; // Offset: 0x5da // Size: 0x02
	float ClientServerVelocitySizeSquareThreshold; // Offset: 0x5dc // Size: 0x04
	bool bDSSmoothVelocity; // Offset: 0x5e0 // Size: 0x01
	bool bAdjustClientWithRotation; // Offset: 0x5e1 // Size: 0x01
	char pad_0x5E2[0x12]; // Offset: 0x5e2 // Size: 0x12
	bool EnabledResetPredictionData; // Offset: 0x5f4 // Size: 0x01
	char pad_0x5F5[0x13]; // Offset: 0x5f5 // Size: 0x13
	float MinTimeBetweenTimeStampResets; // Offset: 0x608 // Size: 0x04
	char pad_0x60C[0x4]; // Offset: 0x60c // Size: 0x04
	struct FRootMotionSourceGroup CurrentRootMotion; // Offset: 0x610 // Size: 0x100
	char pad_0x710[0x90]; // Offset: 0x710 // Size: 0x90
	struct FRootMotionMovementParams RootMotionParams; // Offset: 0x7a0 // Size: 0x40
	struct FVector AnimRootMotionVelocity; // Offset: 0x7e0 // Size: 0x0c
	bool bWasSimulatingRootMotion; // Offset: 0x7ec // Size: 0x01
	char bAllowPhysicsRotationDuringAnimRootMotion : 1; // Offset: 0x7ed // Size: 0x01
	char pad_0x7ED_1 : 7; // Offset: 0x7ed // Size: 0x01
	char pad_0x7EE[0x2]; // Offset: 0x7ee // Size: 0x02
	struct ABioVehicleBase* VehicleOwner; // Offset: 0x7f0 // Size: 0x08
	char pad_0x7F8[0x10]; // Offset: 0x7f8 // Size: 0x10
	bool bIsAcceptInput; // Offset: 0x808 // Size: 0x01
	char pad_0x809[0x3]; // Offset: 0x809 // Size: 0x03
	float NetThrottleInput; // Offset: 0x80c // Size: 0x04
	float NetSteeringInput; // Offset: 0x810 // Size: 0x04
	float NetRisingInput; // Offset: 0x814 // Size: 0x04
	char pad_0x818[0xc]; // Offset: 0x818 // Size: 0x0c
	float ForwardSpeed; // Offset: 0x824 // Size: 0x04
	float AngularSpeed; // Offset: 0x828 // Size: 0x04
	float HandBrakeRate; // Offset: 0x82c // Size: 0x04
	bool bOpenCustomBodyBox; // Offset: 0x830 // Size: 0x01
	bool bOpenCustomHeadCapsule; // Offset: 0x831 // Size: 0x01
	bool bRotationCheckHeadCapsule; // Offset: 0x832 // Size: 0x01
	bool bBlockRevertTransfrom; // Offset: 0x833 // Size: 0x01
	float FloorCheckXReduce; // Offset: 0x834 // Size: 0x04
	bool bFollowBasedVehicle; // Offset: 0x838 // Size: 0x01
	bool bCanWalkOnBioVehicle; // Offset: 0x839 // Size: 0x01
	char pad_0x83A[0x6]; // Offset: 0x83a // Size: 0x06
	struct UCurveFloat* AngularVelocityCurve; // Offset: 0x840 // Size: 0x08
	struct UCurveFloat* AccResistanceCurve; // Offset: 0x848 // Size: 0x08
	struct UCurveFloat* DecResistanceCurve; // Offset: 0x850 // Size: 0x08
	struct UCurveFloat* BreakAccelerationCurve; // Offset: 0x858 // Size: 0x08
	struct UCurveFloat* SlopeSpeedFactorCurve; // Offset: 0x860 // Size: 0x08
	float DefaultAcceleration; // Offset: 0x868 // Size: 0x04
	float MaxBackAcceleration; // Offset: 0x86c // Size: 0x04
	float AngularAcceleration; // Offset: 0x870 // Size: 0x04
	float DefaultAngularVelocity; // Offset: 0x874 // Size: 0x04
	float DefaultResistanceCoefficient; // Offset: 0x878 // Size: 0x04
	float DefaultStaticResistance; // Offset: 0x87c // Size: 0x04
	float DefaultBrakeAcceleration; // Offset: 0x880 // Size: 0x04
	float DefaultSpeed; // Offset: 0x884 // Size: 0x04
	float MaxBackSpeed; // Offset: 0x888 // Size: 0x04
	float DeltaDotFactor; // Offset: 0x88c // Size: 0x04
	float SlopeBlockDotFactorMax; // Offset: 0x890 // Size: 0x04
	float SlopeBlockDotFactorMin; // Offset: 0x894 // Size: 0x04
	float FallingHeadResolveSpeed; // Offset: 0x898 // Size: 0x04
	char pad_0x89C[0x4]; // Offset: 0x89c // Size: 0x04
	float SeriousInjuredSpeedFactor; // Offset: 0x8a0 // Size: 0x04
	char pad_0x8A4[0x1]; // Offset: 0x8a4 // Size: 0x01
	char bDisableOBSmooth : 1; // Offset: 0x8a5 // Size: 0x01
	char pad_0x8A5_1 : 7; // Offset: 0x8a5 // Size: 0x01
	char pad_0x8A6[0x2]; // Offset: 0x8a6 // Size: 0x02
	float MinJumpSpeed; // Offset: 0x8a8 // Size: 0x04
	bool bForceClientNoCombineWhenRot; // Offset: 0x8ac // Size: 0x01
	bool bForceClientNoCombineWhenJump; // Offset: 0x8ad // Size: 0x01
	bool bForceClientNoCombineWhenHeadBlock; // Offset: 0x8ae // Size: 0x01
	bool bForceClientNoCombineWhenStepup; // Offset: 0x8af // Size: 0x01
	float HeadBlockNoCombineInterval; // Offset: 0x8b0 // Size: 0x04
	float StepUpNoCombineInterval; // Offset: 0x8b4 // Size: 0x04
	char pad_0x8B8[0x8]; // Offset: 0x8b8 // Size: 0x08
	char NoCombineDeviceLevel; // Offset: 0x8c0 // Size: 0x01
	char pad_0x8C1[0x3]; // Offset: 0x8c1 // Size: 0x03
	float NoCombineSecondsPerFrame; // Offset: 0x8c4 // Size: 0x04
	float AutonomousMoveWeakNetScaleMSecsMin; // Offset: 0x8c8 // Size: 0x04
	float AutonomousMoveWeakNetScaleMSecsMax; // Offset: 0x8cc // Size: 0x04
	float AutonomousMoveWeakNetScaleRate; // Offset: 0x8d0 // Size: 0x04
	bool bServerMoveCheckPassWall; // Offset: 0x8d4 // Size: 0x01
	bool bTeleportIgnoreCheckPassWall; // Offset: 0x8d5 // Size: 0x01
	char pad_0x8D6[0x2]; // Offset: 0x8d6 // Size: 0x02
	float RadiusScaleWhenCheckPassWall; // Offset: 0x8d8 // Size: 0x04
	float HeightScaleWhenCheckPassWall; // Offset: 0x8dc // Size: 0x04
	bool bEnablePenetrationResolve; // Offset: 0x8e0 // Size: 0x01
	char pad_0x8E1[0x3]; // Offset: 0x8e1 // Size: 0x03
	int PenetrationUnResolveCount; // Offset: 0x8e4 // Size: 0x04
	float PenetrationUnResolveDistanceSq; // Offset: 0x8e8 // Size: 0x04
	float PenetrationResolveValidDistanceSq; // Offset: 0x8ec // Size: 0x04
	float PenetrationResolveValidDistanceMax; // Offset: 0x8f0 // Size: 0x04
	char pad_0x8F4[0xc]; // Offset: 0x8f4 // Size: 0x0c
	struct FResolvePenetrationMoveData ResolvePenetrationMove; // Offset: 0x900 // Size: 0x50
	struct FResolvePenetrationParams ResolvePenetrationParams; // Offset: 0x950 // Size: 0x58
	char pad_0x9A8[0x38]; // Offset: 0x9a8 // Size: 0x38
	struct FResolvePenetrationMoveData LastResolvePenetrationMove; // Offset: 0x9e0 // Size: 0x50
	char pad_0xA30[0x30]; // Offset: 0xa30 // Size: 0x30
	struct FScriptMulticastDelegate OnBioVehicleResolvePenetrationDelegate; // Offset: 0xa60 // Size: 0x10
	char pad_0xA70[0xc]; // Offset: 0xa70 // Size: 0x0c
	float DefaultJumpHeight; // Offset: 0xa7c // Size: 0x04
	struct UCurveFloat* JumpingHeightCurve; // Offset: 0xa80 // Size: 0x08
	struct UCurveFloat* JumpingHeightByObsHeightCurve; // Offset: 0xa88 // Size: 0x08
	char bIsControlJumpHeight : 1; // Offset: 0xa90 // Size: 0x01
	char bApplyGravityWhileJumping : 1; // Offset: 0xa90 // Size: 0x01
	char pad_0xA90_2 : 6; // Offset: 0xa90 // Size: 0x01
	char pad_0xA91[0x3]; // Offset: 0xa91 // Size: 0x03
	float JumpHorizontalVelocityScale; // Offset: 0xa94 // Size: 0x04
	float StandByJumpSpeed; // Offset: 0xa98 // Size: 0x04
	float StandByJumpSpeedZ; // Offset: 0xa9c // Size: 0x04
	float JumpZVelocity; // Offset: 0xaa0 // Size: 0x04
	float JumpOffJumpZFactor; // Offset: 0xaa4 // Size: 0x04
	float JumpOffVelocityScale; // Offset: 0xaa8 // Size: 0x04
	bool bSimulateZeroVelocityDeferFindFloor; // Offset: 0xaac // Size: 0x01
	char pad_0xAAD[0x3]; // Offset: 0xaad // Size: 0x03
	float SimulateFindFloorInternal; // Offset: 0xab0 // Size: 0x04
	int SimulateOptimizeCountsNum; // Offset: 0xab4 // Size: 0x04
	char pad_0xAB8[0x4]; // Offset: 0xab8 // Size: 0x04
	bool bUseSelfLocDiffThreshold; // Offset: 0xabc // Size: 0x01
	char pad_0xABD[0x3]; // Offset: 0xabd // Size: 0x03
	float MaxAllowedLocDiffSquare; // Offset: 0xac0 // Size: 0x04
	bool bForceApplyServerMovementMode; // Offset: 0xac4 // Size: 0x01
	bool bServerCheckJumpZLocDiff; // Offset: 0xac5 // Size: 0x01
	char pad_0xAC6[0x2]; // Offset: 0xac6 // Size: 0x02
	float JumpProtectionZThreshold; // Offset: 0xac8 // Size: 0x04
	bool bSimulateProtection; // Offset: 0xacc // Size: 0x01
	char pad_0xACD[0x3]; // Offset: 0xacd // Size: 0x03
	float SimulateProtectionInterval; // Offset: 0xad0 // Size: 0x04
	char pad_0xAD4[0x18]; // Offset: 0xad4 // Size: 0x18
	bool bSimulateMovement; // Offset: 0xaec // Size: 0x01
	char pad_0xAED[0x3]; // Offset: 0xaed // Size: 0x03

	// Functions

	// Object Name: Function Addons.BioVehicleMovementComponent.UnpackAccelerationToInput
	// Flags: [Final|Native|Public|HasDefaults]
	void UnpackAccelerationToInput(struct FVector InAccel); // Offset: 0x103edbb94 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Addons.BioVehicleMovementComponent.SetWalkableFloorZ
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWalkableFloorZ(float InWalkableFloorZ); // Offset: 0x103edbb18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.SetWalkableFloorAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWalkableFloorAngle(float InWalkableFloorAngle); // Offset: 0x103edba9c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.SetThrottleInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetThrottleInput(float Rate); // Offset: 0x103edba20 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.SetSteeringInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSteeringInput(float Rate); // Offset: 0x103edb9a4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.SetRisingInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRisingInput(float Rate); // Offset: 0x103edb928 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.SetMovementMode
	// Flags: [Native|Public|BlueprintCallable]
	void SetMovementMode(enum class EMovementMode NewMovementMode, char NewCustomMode); // Offset: 0x103edb868 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Addons.BioVehicleMovementComponent.SetGroupsToIgnoreMask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetGroupsToIgnoreMask(struct FNavAvoidanceMask& GroupMask); // Offset: 0x103edb7e0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.SetGroupsToIgnore
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGroupsToIgnore(int GroupFlags); // Offset: 0x103edb764 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.SetGroupsToAvoidMask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetGroupsToAvoidMask(struct FNavAvoidanceMask& GroupMask); // Offset: 0x103edb6dc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.SetGroupsToAvoid
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGroupsToAvoid(int GroupFlags); // Offset: 0x103edb660 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.SetAvoidanceGroupMask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetAvoidanceGroupMask(struct FNavAvoidanceMask& GroupMask); // Offset: 0x103edb5d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.SetAvoidanceGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAvoidanceGroup(int GroupFlags); // Offset: 0x103edb55c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.SetAvoidanceEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAvoidanceEnabled(bool bEnable); // Offset: 0x103edb4d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.BioVehicleMovementComponent.SetAcceptInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAcceptInput(bool bIsAccept); // Offset: 0x103edb454 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.BioVehicleMovementComponent.ServerSetThrottleInput
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerSetThrottleInput(float Rate); // Offset: 0x103edb3a8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.ServerSetSteeringInput
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerSetSteeringInput(float Rate); // Offset: 0x103edb2fc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.ServerSetRisingInput
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerSetRisingInput(float Rate); // Offset: 0x103edb250 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.ServerMoveOld
	// Flags: [Net|Native|Event|Public|NetServer|NetValidate]
	void ServerMoveOld(float OldTimeStamp, struct FVector_NetQuantize10 OldAccel, char OldMoveFlags); // Offset: 0x103edb120 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Addons.BioVehicleMovementComponent.ServerMoveDualHybridRootMotion
	// Flags: [Net|Native|Event|Public|NetServer|NetValidate]
	void ServerMoveDualHybridRootMotion(float TimeStamp0, struct FVector_NetQuantize10 InAccel0, char PendingFlags, uint32_t View0, float TimeStamp, struct FVector_NetQuantize10 InAccel, struct FVector_NetQuantize100 ClientLoc, char NewFlags, char ClientRoll, uint32_t View, struct UPrimitiveComponent* ClientMovementBase, struct FName ClientBaseBoneName, char ClientMovementMode); // Offset: 0x103edad60 // Return & Params: Num(13) Size(0x51)

	// Object Name: Function Addons.BioVehicleMovementComponent.ServerMoveDual
	// Flags: [Net|Native|Event|Public|NetServer|NetValidate]
	void ServerMoveDual(float TimeStamp0, struct FVector_NetQuantize10 InAccel0, char PendingFlags, uint32_t View0, float TimeStamp, struct FVector_NetQuantize10 InAccel, struct FVector_NetQuantize100 ClientLoc, char NewFlags, char ClientRoll, uint32_t View, struct UPrimitiveComponent* ClientMovementBase, struct FName ClientBaseBoneName, char ClientMovementMode); // Offset: 0x103eda9a0 // Return & Params: Num(13) Size(0x51)

	// Object Name: Function Addons.BioVehicleMovementComponent.ServerMove
	// Flags: [Net|Native|Event|Public|NetServer|NetValidate]
	void ServerMove(float TimeStamp, struct FVector_NetQuantize10 InAccel, struct FVector_NetQuantize100 ClientLoc, char CompressedMoveFlags, char ClientRoll, uint32_t View, struct UPrimitiveComponent* ClientMovementBase, struct FName ClientBaseBoneName, char ClientMovementMode); // Offset: 0x103eda6fc // Return & Params: Num(9) Size(0x39)

	// Object Name: Function Addons.BioVehicleMovementComponent.PackInputToAcceleration
	// Flags: [Final|Native|Public|HasDefaults|Const]
	struct FVector PackInputToAcceleration(); // Offset: 0x103eda6c4 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Addons.BioVehicleMovementComponent.K2_GetWalkableFloorZ
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float K2_GetWalkableFloorZ(); // Offset: 0x103eda690 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.K2_GetWalkableFloorAngle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float K2_GetWalkableFloorAngle(); // Offset: 0x103eda65c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.K2_GetModifiedMaxAcceleration
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	float K2_GetModifiedMaxAcceleration(); // Offset: 0x103eda620 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.K2_FindFloor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	void K2_FindFloor(struct FVector CapsuleLocation, struct FFindFloorResult& FloorResult); // Offset: 0x103eda510 // Return & Params: Num(2) Size(0xb8)

	// Object Name: Function Addons.BioVehicleMovementComponent.K2_ComputeFloorDist
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	void K2_ComputeFloorDist(struct FVector CapsuleLocation, float LineDistance, float SweepDistance, float SweepRadius, struct FFindFloorResult& FloorResult); // Offset: 0x103eda350 // Return & Params: Num(5) Size(0xc0)

	// Object Name: Function Addons.BioVehicleMovementComponent.IsWalking
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsWalking(); // Offset: 0x103eda314 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.BioVehicleMovementComponent.IsWalkable
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsWalkable(struct FHitResult& Hit); // Offset: 0x103eda23c // Return & Params: Num(2) Size(0x99)

	// Object Name: Function Addons.BioVehicleMovementComponent.IsSwimming
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsSwimming(); // Offset: 0x103eda200 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.BioVehicleMovementComponent.IsSeriousInjuriedAllowJumping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsSeriousInjuriedAllowJumping(); // Offset: 0x103eda1cc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.BioVehicleMovementComponent.HandleOnSeatDetached
	// Flags: [Native|Public]
	void HandleOnSeatDetached(struct ASTExtraPlayerCharacter* Character, enum class ESTExtraVehicleSeatType SeatType, int SeatIdx); // Offset: 0x103eda0d0 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Addons.BioVehicleMovementComponent.HandleOnSeatChanged
	// Flags: [Native|Public]
	void HandleOnSeatChanged(struct ASTExtraPlayerCharacter* Character, enum class ESTExtraVehicleSeatType LastSeatType, int LastSeatIdx, enum class ESTExtraVehicleSeatType NewSeatType, int NewSeatIdx); // Offset: 0x103ed9f5c // Return & Params: Num(5) Size(0x18)

	// Object Name: Function Addons.BioVehicleMovementComponent.HandleOnSeatAttached
	// Flags: [Native|Public]
	void HandleOnSeatAttached(struct ASTExtraPlayerCharacter* Character, enum class ESTExtraVehicleSeatType SeatType, int SeatIdx); // Offset: 0x103ed9e60 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Addons.BioVehicleMovementComponent.HandleOnExitVehicleAnim
	// Flags: [Final|Native|Public]
	void HandleOnExitVehicleAnim(struct ASTExtraPlayerCharacter* Character, int SeatInx); // Offset: 0x103ed9da8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetWalkingDecResistance
	// Flags: [Native|Public|BlueprintCallable]
	float GetWalkingDecResistance(float Speed); // Offset: 0x103ed9d14 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetWalkingAccResistance
	// Flags: [Native|Public|BlueprintCallable]
	float GetWalkingAccResistance(float Speed); // Offset: 0x103ed9c80 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetValidPerchRadius
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetValidPerchRadius(); // Offset: 0x103ed9c4c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetThrottleInput
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetThrottleInput(); // Offset: 0x103ed9c18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetSteeringInput
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetSteeringInput(); // Offset: 0x103ed9be4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetSlopeSpeedFactor
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetSlopeSpeedFactor(float Slope); // Offset: 0x103ed9b50 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetRisingInput
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetRisingInput(); // Offset: 0x103ed9b1c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetPredictVelocity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	struct FVector GetPredictVelocity(float PredictTime); // Offset: 0x103ed9a8c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetPerchRadiusThreshold
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetPerchRadiusThreshold(); // Offset: 0x103ed9a58 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetMovementBase
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UPrimitiveComponent* GetMovementBase(); // Offset: 0x103ed9a24 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetMinAnalogSpeed
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMinAnalogSpeed(); // Offset: 0x103ed99e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetMaxJumpHeightWithJumpTime
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMaxJumpHeightWithJumpTime(); // Offset: 0x103ed99ac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetMaxJumpHeight
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMaxJumpHeight(); // Offset: 0x103ed9970 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetMaxBrakingDeceleration
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMaxBrakingDeceleration(); // Offset: 0x103ed9934 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetMaxAcceleration
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMaxAcceleration(); // Offset: 0x103ed98f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetJumpVelocityZ
	// Flags: [Native|Public|BlueprintCallable]
	float GetJumpVelocityZ(); // Offset: 0x103ed98bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetJumpingHeightBySpeed
	// Flags: [Native|Public|BlueprintCallable]
	float GetJumpingHeightBySpeed(float Speed); // Offset: 0x103ed9828 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetJumpingHeightByObsHeight
	// Flags: [Native|Public|BlueprintCallable]
	float GetJumpingHeightByObsHeight(float ObsHeight); // Offset: 0x103ed9794 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetImpartedMovementBaseVelocity
	// Flags: [Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetImpartedMovementBaseVelocity(); // Offset: 0x103ed9754 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetDesireAcceleration
	// Flags: [Native|Public|BlueprintCallable]
	float GetDesireAcceleration(); // Offset: 0x103ed9718 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetCurrentAcceleration
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetCurrentAcceleration(); // Offset: 0x103ed96e0 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetBreakAcceleration
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetBreakAcceleration(float Speed); // Offset: 0x103ed964c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetAngularVelocityByCurve
	// Flags: [Native|Public|BlueprintCallable]
	float GetAngularVelocityByCurve(float Speed, bool AsForce); // Offset: 0x103ed9574 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Addons.BioVehicleMovementComponent.GetAnalogInputModifier
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetAnalogInputModifier(); // Offset: 0x103ed9540 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.DisableMovement
	// Flags: [Native|Public|BlueprintCallable]
	void DisableMovement(); // Offset: 0x103ed9524 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.BioVehicleMovementComponent.DealWithCustomAction
	// Flags: [Native|Public]
	void DealWithCustomAction(float DeltaTime); // Offset: 0x103ed94a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.ClientVeryShortAdjustPosition
	// Flags: [Net|Native|Event|Public|HasDefaults|NetClient]
	void ClientVeryShortAdjustPosition(float TimeStamp, struct FVector NewLoc, struct UPrimitiveComponent* NewBase, struct FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, char ServerMovementMode); // Offset: 0x103ed92a0 // Return & Params: Num(7) Size(0x23)

	// Object Name: Function Addons.BioVehicleMovementComponent.ClientAdjustRootMotionSourcePosition
	// Flags: [Net|Native|Event|Public|HasDefaults|NetClient]
	void ClientAdjustRootMotionSourcePosition(float TimeStamp, struct FRootMotionSourceGroup ServerRootMotion, bool bHasAnimRootMotion, float ServerMontageTrackPosition, struct FVector ServerLoc, struct FVector_NetQuantizeNormal ServerRotation, float ServerVelZ, struct UPrimitiveComponent* ServerBase, struct FName ServerBoneName, bool bHasBase, bool bBaseRelativePosition, char ServerMovementMode); // Offset: 0x103ed8ee0 // Return & Params: Num(12) Size(0x143)

	// Object Name: Function Addons.BioVehicleMovementComponent.ClientAdjustRootMotionPosition
	// Flags: [Net|Native|Event|Public|HasDefaults|NetClient]
	void ClientAdjustRootMotionPosition(float TimeStamp, float ServerMontageTrackPosition, struct FVector ServerLoc, struct FVector_NetQuantizeNormal ServerRotation, float ServerVelZ, struct UPrimitiveComponent* ServerBase, struct FName ServerBoneName, bool bHasBase, bool bBaseRelativePosition, char ServerMovementMode); // Offset: 0x103ed8c2c // Return & Params: Num(10) Size(0x3b)

	// Object Name: Function Addons.BioVehicleMovementComponent.ClientAdjustPositionAndRotation
	// Flags: [Net|Native|Event|Public|HasDefaults|NetClient]
	void ClientAdjustPositionAndRotation(float TimeStamp, struct FVector NewLoc, struct FRotator NewRot, struct FVector NewVel, struct UPrimitiveComponent* NewBase, struct FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, char ServerMovementMode); // Offset: 0x103ed89b0 // Return & Params: Num(9) Size(0x3b)

	// Object Name: Function Addons.BioVehicleMovementComponent.ClientAdjustPosition
	// Flags: [Net|Native|Event|Public|HasDefaults|NetClient]
	void ClientAdjustPosition(float TimeStamp, struct FVector NewLoc, struct FVector NewVel, struct UPrimitiveComponent* NewBase, struct FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, char ServerMovementMode); // Offset: 0x103ed8774 // Return & Params: Num(8) Size(0x33)

	// Object Name: Function Addons.BioVehicleMovementComponent.ClientAckGoodMove
	// Flags: [Net|Native|Event|Public|NetClient]
	void ClientAckGoodMove(float TimeStamp); // Offset: 0x103ed86f0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.ClearAccumulatedForces
	// Flags: [Native|Public|BlueprintCallable]
	void ClearAccumulatedForces(); // Offset: 0x103ed86d4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.BioVehicleMovementComponent.CapsuleTouched
	// Flags: [Native|Protected|HasOutParms]
	void CapsuleTouched(struct UPrimitiveComponent* OverlappedComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, int OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Offset: 0x103ed84d4 // Return & Params: Num(6) Size(0xb8)

	// Object Name: Function Addons.BioVehicleMovementComponent.CalcVelocity
	// Flags: [Native|Public|BlueprintCallable]
	void CalcVelocity(float DeltaTime, float Friction, bool bFluid, float BrakingDeceleration); // Offset: 0x103ed8390 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Addons.BioVehicleMovementComponent.CalculateVelocityWithResistance
	// Flags: [Native|Public|BlueprintCallable]
	void CalculateVelocityWithResistance(float DeltaTime, bool bFluid); // Offset: 0x103ed82c8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Addons.BioVehicleMovementComponent.CalculateCurrentForwardSpeed
	// Flags: [Native|Public|BlueprintCallable]
	float CalculateCurrentForwardSpeed(); // Offset: 0x103ed828c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.BioVehicleMovementComponent.AddImpulse
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	void AddImpulse(struct FVector Impulse, bool bVelocityChange); // Offset: 0x103ed81c4 // Return & Params: Num(2) Size(0xd)

	// Object Name: Function Addons.BioVehicleMovementComponent.AddForce
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	void AddForce(struct FVector force); // Offset: 0x103ed8140 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Addons.BioVehicleMovementComponent.AddDirectionalBrakingAcceleration
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	void AddDirectionalBrakingAcceleration(struct FVector BrakingAcceleration); // Offset: 0x103ed80bc // Return & Params: Num(1) Size(0xc)
};

// Object Name: Class Addons.BioVehicleRiderAnimInstanceBase
// Size: 0x560 // Inherited bytes: 0x420
struct UBioVehicleRiderAnimInstanceBase : UCharacterAnimStateBase {
	// Fields
	char pad_0x420[0x60]; // Offset: 0x420 // Size: 0x60
	bool bAnimVarHasCached; // Offset: 0x480 // Size: 0x01
	char pad_0x481[0x7]; // Offset: 0x481 // Size: 0x07
	struct UAnimMontage* MountAnimMontage; // Offset: 0x488 // Size: 0x08
	struct FString TransPropertyPrefix; // Offset: 0x490 // Size: 0x10
	bool bIsDead; // Offset: 0x4a0 // Size: 0x01
	bool bEnableTerrainAdaption; // Offset: 0x4a1 // Size: 0x01
	char pad_0x4A2[0x2]; // Offset: 0x4a2 // Size: 0x02
	int AnimLOD; // Offset: 0x4a4 // Size: 0x04
	char pad_0x4A8[0xa0]; // Offset: 0x4a8 // Size: 0xa0
	struct FString LuaFilePath; // Offset: 0x548 // Size: 0x10
	char pad_0x558[0x8]; // Offset: 0x558 // Size: 0x08

	// Functions

	// Object Name: Function Addons.BioVehicleRiderAnimInstanceBase.LuaInitializeAnimation
	// Flags: [Native|Event|Public|BlueprintEvent]
	void LuaInitializeAnimation(); // Offset: 0x103ede434 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.BioVehicleRiderAnimInstanceBase.LuaCacheAnimVarWithAnimList
	// Flags: [Native|Event|Public|BlueprintEvent]
	void LuaCacheAnimVarWithAnimList(struct UBioVehicleAnimListComponent* RiderAnimListComponent); // Offset: 0x103ede3b0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Addons.BioVehicleRiderAnimInstanceBase.DoTransition
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DoTransition(struct FString State); // Offset: 0x103ede318 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Addons.BioVehicleRiderAnimInstanceBase.ConfirmTransition
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ConfirmTransition(struct FString State); // Offset: 0x103ede280 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Addons.BioVehicleRiderAnimInstanceBase.CacheAnimVarWithAnimList
	// Flags: [Native|Public|BlueprintCallable]
	void CacheAnimVarWithAnimList(struct UBioVehicleAnimListComponent* RiderAnimListComponent); // Offset: 0x103ede1fc // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Addons.BioVehicleSkeletalMeshComponent
// Size: 0xf30 // Inherited bytes: 0xf30
struct UBioVehicleSkeletalMeshComponent : UUAESkeletalMeshComponent {
};

// Object Name: Class Addons.DinosaurMonsterAnimInstanceBase
// Size: 0x640 // Inherited bytes: 0x640
struct UDinosaurMonsterAnimInstanceBase : USTExtraMonsterAnimInstance {
};

// Object Name: Class Addons.DistanceMatchingComponent
// Size: 0x158 // Inherited bytes: 0x110
struct UDistanceMatchingComponent : UActorComponent {
	// Fields
	bool bEnableDistanceMatching; // Offset: 0x110 // Size: 0x01
	char pad_0x111[0x3]; // Offset: 0x111 // Size: 0x03
	float SpeedThreshold; // Offset: 0x114 // Size: 0x04
	float SweepUpOffset; // Offset: 0x118 // Size: 0x04
	float SweepDownOffset; // Offset: 0x11c // Size: 0x04
	struct FVector PredictedLocation; // Offset: 0x120 // Size: 0x0c
	char pad_0x12C[0x4]; // Offset: 0x12c // Size: 0x04
	struct FScriptMulticastDelegate OnDistanceMatchSuccess; // Offset: 0x130 // Size: 0x10
	bool bShouldOnlyDistanceMatchingOnAutonomousProxy; // Offset: 0x140 // Size: 0x01
	char pad_0x141[0x7]; // Offset: 0x141 // Size: 0x07
	struct UBioVehicleMovementComponent* BioVehicleMovement; // Offset: 0x148 // Size: 0x08
	struct UCapsuleComponent* CapsuleComponent; // Offset: 0x150 // Size: 0x08

	// Functions

	// Object Name: Function Addons.DistanceMatchingComponent.ServerOnDistanceMatchSuccess
	// Flags: [Final|Net|NetReliableNative|Event|Private|NetServer|HasDefaults|NetValidate]
	void ServerOnDistanceMatchSuccess(struct FVector PredictedStopLocation); // Offset: 0x103edeb0c // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Addons.DistanceMatchingComponent.PredictStopLocation
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	bool PredictStopLocation(struct FVector& OutLocation); // Offset: 0x103edea74 // Return & Params: Num(2) Size(0xd)

	// Object Name: Function Addons.DistanceMatchingComponent.OnEndAccelerating
	// Flags: [Final|Native|Private]
	void OnEndAccelerating(); // Offset: 0x103edea60 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.DistanceMatchingComponent.GetBioVehicleAnimInstance
	// Flags: [Final|Native|Private|Const]
	struct UAnimInstance* GetBioVehicleAnimInstance(); // Offset: 0x103edea2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Addons.DistanceMatchingComponent.BroadCastOnDistanceMatchSuccess
	// Flags: [Final|Net|NetReliableNative|Event|NetMulticast|Private|HasDefaults]
	void BroadCastOnDistanceMatchSuccess(struct FVector PredictedStopLocation); // Offset: 0x103ede9a8 // Return & Params: Num(1) Size(0xc)
};

// Object Name: Class Addons.DistanceMatchingInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UDistanceMatchingInterface : UInterface {
	// Functions

	// Object Name: Function Addons.DistanceMatchingInterface.OnDistanceMatchingSuccess
	// Flags: [Native|Public|HasDefaults]
	void OnDistanceMatchingSuccess(struct FVector PredictedStopLocation); // Offset: 0x103edee34 // Return & Params: Num(1) Size(0xc)
};

// Object Name: Class Addons.LandingCreatureAnimInstance
// Size: 0x710 // Inherited bytes: 0x600
struct ULandingCreatureAnimInstance : UBioVehicleAnimInstanceBase {
	// Fields
	char pad_0x600[0x8]; // Offset: 0x600 // Size: 0x08
	float MaxDirection; // Offset: 0x608 // Size: 0x04
	float DirectionLerpSpeed; // Offset: 0x60c // Size: 0x04
	float SpeedLerpSpeed; // Offset: 0x610 // Size: 0x04
	float BlockedSpeed; // Offset: 0x614 // Size: 0x04
	float RunStopSpeedThreshold; // Offset: 0x618 // Size: 0x04
	float LegIKAlphaLerpSpeed; // Offset: 0x61c // Size: 0x04
	struct ABioVehicleBase* OwnerDinosaur; // Offset: 0x620 // Size: 0x08
	struct FScriptMulticastDelegate OnLandingCreatureJump; // Offset: 0x628 // Size: 0x10
	float ThrottleInput; // Offset: 0x638 // Size: 0x04
	float SteeringInput; // Offset: 0x63c // Size: 0x04
	bool bHasAcceleration; // Offset: 0x640 // Size: 0x01
	bool bIsJumping; // Offset: 0x641 // Size: 0x01
	bool bIsRunStopping; // Offset: 0x642 // Size: 0x01
	bool bIsStopping; // Offset: 0x643 // Size: 0x01
	bool bIsInAir; // Offset: 0x644 // Size: 0x01
	bool bShouldUseExtraDeadAnim; // Offset: 0x645 // Size: 0x01
	char pad_0x646[0x2]; // Offset: 0x646 // Size: 0x02
	int RandomIdleIndex; // Offset: 0x648 // Size: 0x04
	bool bDoRandomIdle; // Offset: 0x64c // Size: 0x01
	char pad_0x64D[0x3]; // Offset: 0x64d // Size: 0x03
	float Speed; // Offset: 0x650 // Size: 0x04
	float Direction; // Offset: 0x654 // Size: 0x04
	float LegIKAlpha; // Offset: 0x658 // Size: 0x04
	char pad_0x65C[0x4]; // Offset: 0x65c // Size: 0x04
	struct UAnimPoseRecorder* AnimPoseRecorder; // Offset: 0x660 // Size: 0x08
	bool bEnableDistanceMatching; // Offset: 0x668 // Size: 0x01
	char pad_0x669[0x3]; // Offset: 0x669 // Size: 0x03
	struct FVector PredictedStopPoint; // Offset: 0x66c // Size: 0x0c
	float DistanceFromStopPoint; // Offset: 0x678 // Size: 0x04
	char pad_0x67C[0x4]; // Offset: 0x67c // Size: 0x04
	struct UAnimSequence* ExtraDeathAnim; // Offset: 0x680 // Size: 0x08
	struct UAnimSequence* UntamedIdleAnim; // Offset: 0x688 // Size: 0x08
	struct UAnimSequence* IdleAnim; // Offset: 0x690 // Size: 0x08
	struct UAnimSequence* RandomIdleAnim1; // Offset: 0x698 // Size: 0x08
	struct UAnimSequence* RandomIdleAnim2; // Offset: 0x6a0 // Size: 0x08
	struct UBlendSpace* MovementAnim; // Offset: 0x6a8 // Size: 0x08
	struct UAnimSequence* JumpStartAnim; // Offset: 0x6b0 // Size: 0x08
	struct UAnimSequence* FallingAnim; // Offset: 0x6b8 // Size: 0x08
	struct UAnimSequence* IdleLandingAnim; // Offset: 0x6c0 // Size: 0x08
	struct UAnimSequence* RunLandingAnim; // Offset: 0x6c8 // Size: 0x08
	struct UBlendSpace1D* TurnStartAnim; // Offset: 0x6d0 // Size: 0x08
	struct UBlendSpace1D* TurningAnim; // Offset: 0x6d8 // Size: 0x08
	struct UBlendSpace1D* TurnEndAnim; // Offset: 0x6e0 // Size: 0x08
	char pad_0x6E8[0x28]; // Offset: 0x6e8 // Size: 0x28

	// Functions

	// Object Name: Function Addons.LandingCreatureAnimInstance.SetJump
	// Flags: [Final|Native|Public]
	void SetJump(); // Offset: 0x103edf10c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.LandingCreatureAnimInstance.ResetStop
	// Flags: [Final|Native|Private]
	void ResetStop(); // Offset: 0x103edf0f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.LandingCreatureAnimInstance.ResetJump
	// Flags: [Final|Native|Public]
	void ResetJump(); // Offset: 0x103edf0e4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.LandingCreatureAnimInstance.ResetDoRandomIdle
	// Flags: [Final|Native|Private]
	void ResetDoRandomIdle(); // Offset: 0x103edf0d0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.LandingCreatureAnimInstance.DoRandomIdle
	// Flags: [Final|Native|Private]
	void DoRandomIdle(int Index); // Offset: 0x103edf054 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Addons.MonsterRaptorAnimInstance
// Size: 0x680 // Inherited bytes: 0x640
struct UMonsterRaptorAnimInstance : UDinosaurMonsterAnimInstanceBase {
	// Fields
	bool bResetIdleState; // Offset: 0x640 // Size: 0x01
	char pad_0x641[0x3]; // Offset: 0x641 // Size: 0x03
	int PlayedIdleIndex; // Offset: 0x644 // Size: 0x04
	struct TArray<int> NotBattleIdleIndex; // Offset: 0x648 // Size: 0x10
	struct TArray<int> BattleIdleIndex; // Offset: 0x658 // Size: 0x10
	int DefaultBattleIdleIndex; // Offset: 0x668 // Size: 0x04
	int DefaultNotBattleIdleIndex; // Offset: 0x66c // Size: 0x04
	bool bHasLockedTarget; // Offset: 0x670 // Size: 0x01
	bool bInBattle; // Offset: 0x671 // Size: 0x01
	char pad_0x672[0xe]; // Offset: 0x672 // Size: 0x0e

	// Functions

	// Object Name: Function Addons.MonsterRaptorAnimInstance.OnResetPlayedIdleIndex
	// Flags: [Final|Native|Public]
	void OnResetPlayedIdleIndex(int NewIndex); // Offset: 0x103edf3d8 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Addons.PterosaurAnimInstance
// Size: 0x740 // Inherited bytes: 0x600
struct UPterosaurAnimInstance : UBioVehicleAnimInstanceBase {
	// Fields
	struct APterosaurVehicle* OwnerDinosaur; // Offset: 0x600 // Size: 0x08
	float HorizontalSpeedLerpSpeed; // Offset: 0x608 // Size: 0x04
	float VerticalSpeedLerpSpeed; // Offset: 0x60c // Size: 0x04
	float MinStartLeanRollSpeed; // Offset: 0x610 // Size: 0x04
	float MinStartLeanPitchSpeed; // Offset: 0x614 // Size: 0x04
	float StartFlyingSpeedThreshold; // Offset: 0x618 // Size: 0x04
	float MaxDirection; // Offset: 0x61c // Size: 0x04
	float SwoopDirectionThreshold; // Offset: 0x620 // Size: 0x04
	float DirectionLerpSpeed; // Offset: 0x624 // Size: 0x04
	float MaxLeanAnglePitch; // Offset: 0x628 // Size: 0x04
	float MaxLeanAngleRoll; // Offset: 0x62c // Size: 0x04
	float LeanAngleRollLerpSpeed; // Offset: 0x630 // Size: 0x04
	float LeanAnglePitchLerpSpeed; // Offset: 0x634 // Size: 0x04
	struct UAssetPlayerSyncNode* BlendSpaceSyncNode; // Offset: 0x638 // Size: 0x08
	enum class EPterosaurMoveMode MoveState; // Offset: 0x640 // Size: 0x01
	enum class EPterosaurSwoopStage SwoopStage; // Offset: 0x641 // Size: 0x01
	char pad_0x642[0x2]; // Offset: 0x642 // Size: 0x02
	int LandingIndex; // Offset: 0x644 // Size: 0x04
	bool bHasCatchedPassenger; // Offset: 0x648 // Size: 0x01
	bool bIsLanding; // Offset: 0x649 // Size: 0x01
	bool bIsGroundDead; // Offset: 0x64a // Size: 0x01
	bool bIsSwoopingDown; // Offset: 0x64b // Size: 0x01
	bool bIsInAir; // Offset: 0x64c // Size: 0x01
	bool bIsFalling; // Offset: 0x64d // Size: 0x01
	bool bIsTryingToLand; // Offset: 0x64e // Size: 0x01
	bool bStartFlying; // Offset: 0x64f // Size: 0x01
	float TotalSpeed; // Offset: 0x650 // Size: 0x04
	float HorizontalSpeed; // Offset: 0x654 // Size: 0x04
	float VerticalSpeed; // Offset: 0x658 // Size: 0x04
	float ThrottleInput; // Offset: 0x65c // Size: 0x04
	float SteeringInput; // Offset: 0x660 // Size: 0x04
	float RisingInput; // Offset: 0x664 // Size: 0x04
	float Direction; // Offset: 0x668 // Size: 0x04
	float HeadYawDelta; // Offset: 0x66c // Size: 0x04
	float HeadPitchDelta; // Offset: 0x670 // Size: 0x04
	float HeadYawInterpolateSpeed; // Offset: 0x674 // Size: 0x04
	float HeadPitchInterpolateSpeed; // Offset: 0x678 // Size: 0x04
	float BodyLeanAngleRoll; // Offset: 0x67c // Size: 0x04
	float BodyLeanAnglePitch; // Offset: 0x680 // Size: 0x04
	char pad_0x684[0x4]; // Offset: 0x684 // Size: 0x04
	struct UBlendSpace* ArrestMovementAnim; // Offset: 0x688 // Size: 0x08
	struct UAnimSequence* UntamedIdleAnim; // Offset: 0x690 // Size: 0x08
	struct UAnimSequence* GroundIdleAnim; // Offset: 0x698 // Size: 0x08
	struct UAnimSequence* RandomIdleAnim1; // Offset: 0x6a0 // Size: 0x08
	struct UAnimSequence* RandomIdleAnim2; // Offset: 0x6a8 // Size: 0x08
	struct UBlendSpace* MovementAnim; // Offset: 0x6b0 // Size: 0x08
	struct UBlendSpace* FlyingAO_Anim; // Offset: 0x6b8 // Size: 0x08
	struct UAnimSequence* StartFlyingAnim; // Offset: 0x6c0 // Size: 0x08
	struct UAnimSequence* StartLandingAnim1; // Offset: 0x6c8 // Size: 0x08
	struct UAnimSequence* StartLandingAnim2; // Offset: 0x6d0 // Size: 0x08
	struct UAnimSequence* LandingAnim1; // Offset: 0x6d8 // Size: 0x08
	struct UAnimSequence* LandingAnim2; // Offset: 0x6e0 // Size: 0x08
	struct UAnimSequence* LandingAnim3; // Offset: 0x6e8 // Size: 0x08
	struct UAnimSequence* TakingOffAnim; // Offset: 0x6f0 // Size: 0x08
	struct UAnimSequence* RiseUpAnim; // Offset: 0x6f8 // Size: 0x08
	struct UAnimSequence* RiseDownAnim; // Offset: 0x700 // Size: 0x08
	struct UAnimSequence* DivingStartAnim; // Offset: 0x708 // Size: 0x08
	struct UAnimSequence* DivingAnim; // Offset: 0x710 // Size: 0x08
	struct UAnimSequence* DivingEndAnim; // Offset: 0x718 // Size: 0x08
	struct UAnimSequence* GroundDeathAnim; // Offset: 0x720 // Size: 0x08
	struct UAnimSequence* DeathFallingAnim; // Offset: 0x728 // Size: 0x08
	struct UAnimSequence* DeathFallingGround; // Offset: 0x730 // Size: 0x08
	char pad_0x738[0x8]; // Offset: 0x738 // Size: 0x08

	// Functions

	// Object Name: Function Addons.PterosaurAnimInstance.ResetStartFlying
	// Flags: [Final|Native|Public]
	void ResetStartFlying(); // Offset: 0x103edf5e4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.PterosaurAnimInstance.OnStartFlying
	// Flags: [Final|Native|Public]
	void OnStartFlying(); // Offset: 0x103edf5d0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Addons.PterosaurCatchedPassengerAnimInstance
// Size: 0x580 // Inherited bytes: 0x560
struct UPterosaurCatchedPassengerAnimInstance : UBioVehicleRiderAnimInstanceBase {
	// Fields
	struct UAssetPlayerSyncNode* BlendSpaceSyncNode; // Offset: 0x558 // Size: 0x08
	float TotalSpeed; // Offset: 0x560 // Size: 0x04
	float HorizontalSpeed; // Offset: 0x564 // Size: 0x04
	float VerticalSpeed; // Offset: 0x568 // Size: 0x04
	float Direction; // Offset: 0x56c // Size: 0x04
	struct UBlendSpace* MovementAnim; // Offset: 0x570 // Size: 0x08
};

// Object Name: Class Addons.PterosaurDriverAnimInstance
// Size: 0x610 // Inherited bytes: 0x560
struct UPterosaurDriverAnimInstance : UBioVehicleRiderAnimInstanceBase {
	// Fields
	struct UAssetPlayerSyncNode* BlendSpaceSyncNode; // Offset: 0x558 // Size: 0x08
	int LandingIndex; // Offset: 0x560 // Size: 0x04
	bool bIsInAir; // Offset: 0x564 // Size: 0x01
	bool bStartFlying; // Offset: 0x565 // Size: 0x01
	bool bIsTryingToLand; // Offset: 0x566 // Size: 0x01
	bool bHasCatchedPassenger; // Offset: 0x567 // Size: 0x01
	float TotalSpeed; // Offset: 0x568 // Size: 0x04
	float HorizontalSpeed; // Offset: 0x56c // Size: 0x04
	float VerticalSpeed; // Offset: 0x570 // Size: 0x04
	float ThrottleInput; // Offset: 0x574 // Size: 0x04
	float SteeringInput; // Offset: 0x578 // Size: 0x04
	float RisingInput; // Offset: 0x57c // Size: 0x04
	float Direction; // Offset: 0x580 // Size: 0x04
	float BodyLeanAngleRoll; // Offset: 0x584 // Size: 0x04
	float BodyLeanAnglePitch; // Offset: 0x588 // Size: 0x04
	enum class EPterosaurMoveMode MoveState; // Offset: 0x58c // Size: 0x01
	struct UAnimSequence* GroundIdleAnim; // Offset: 0x590 // Size: 0x08
	struct UBlendSpace* MovementAnim; // Offset: 0x598 // Size: 0x08
	struct UBlendSpace* CatchPassengerMovementAnim; // Offset: 0x5a0 // Size: 0x08
	struct UAnimSequence* StartFlyingAnim; // Offset: 0x5a8 // Size: 0x08
	struct UAnimSequence* StartLandingAnim1; // Offset: 0x5b0 // Size: 0x08
	struct UAnimSequence* StartLandingAnim2; // Offset: 0x5b8 // Size: 0x08
	struct UAnimSequence* LandingAnim1; // Offset: 0x5c0 // Size: 0x08
	struct UAnimSequence* LandingAnim2; // Offset: 0x5c8 // Size: 0x08
	struct UAnimSequence* LandingAnim3; // Offset: 0x5d0 // Size: 0x08
	struct UAnimSequence* TakingOffAnim; // Offset: 0x5d8 // Size: 0x08
	struct UAnimSequence* RiseUpAnim; // Offset: 0x5e0 // Size: 0x08
	struct UAnimSequence* RiseDownAnim; // Offset: 0x5e8 // Size: 0x08
	struct UAnimSequence* DivingStartAnim; // Offset: 0x5f0 // Size: 0x08
	struct UAnimSequence* DivingAnim; // Offset: 0x5f8 // Size: 0x08
	struct UAnimSequence* DivingEndAnim; // Offset: 0x600 // Size: 0x08
	struct TWeakObjectPtr<struct UPterosaurAnimInstance> OwnedPterosuarAnimInstance; // Offset: 0x608 // Size: 0x08
};

// Object Name: Class Addons.PterosaurMovementComponent
// Size: 0xd50 // Inherited bytes: 0xaf0
struct UPterosaurMovementComponent : UBioVehicleMovementComponent {
	// Fields
	char pad_0xAF0[0x4]; // Offset: 0xaf0 // Size: 0x04
	enum class EPterosaurMoveMode NetMoveState; // Offset: 0xaf4 // Size: 0x01
	char pad_0xAF5[0xf]; // Offset: 0xaf5 // Size: 0x0f
	float MaxFlyAcceleration; // Offset: 0xb04 // Size: 0x04
	float FlySteeringRotationSpeed; // Offset: 0xb08 // Size: 0x04
	char pad_0xB0C[0x10]; // Offset: 0xb0c // Size: 0x10
	float MaxUpSpeed; // Offset: 0xb1c // Size: 0x04
	float MaxDownSpeed; // Offset: 0xb20 // Size: 0x04
	char pad_0xB24[0x4]; // Offset: 0xb24 // Size: 0x04
	struct FScriptMulticastDelegate OnPterosaurSwoopDownStageChanged; // Offset: 0xb28 // Size: 0x10
	struct TArray<struct FPterosaurUpdateDistanceToLandConfig> UpdateGroundDistanceConfigs; // Offset: 0xb38 // Size: 0x10
	bool bIgnoreHeightLimit; // Offset: 0xb48 // Size: 0x01
	char pad_0xB49[0x3]; // Offset: 0xb49 // Size: 0x03
	float MaxFlyingZ; // Offset: 0xb4c // Size: 0x04
	bool bCheckLandingGround; // Offset: 0xb50 // Size: 0x01
	char pad_0xB51[0x3]; // Offset: 0xb51 // Size: 0x03
	float DistanceToLand; // Offset: 0xb54 // Size: 0x04
	float LastCheckGroundInterval; // Offset: 0xb58 // Size: 0x04
	char pad_0xB5C[0xc]; // Offset: 0xb5c // Size: 0x0c
	bool bTopBlocked; // Offset: 0xb68 // Size: 0x01
	char pad_0xB69[0x3]; // Offset: 0xb69 // Size: 0x03
	float MaxTraceDownHeight; // Offset: 0xb6c // Size: 0x04
	float MaxFlyingHeight; // Offset: 0xb70 // Size: 0x04
	float MinFlyingHeight; // Offset: 0xb74 // Size: 0x04
	float FlyingHeightThres; // Offset: 0xb78 // Size: 0x04
	struct FVector SwoopClimbOffset; // Offset: 0xb7c // Size: 0x0c
	char bSwoopUsePathRotation : 1; // Offset: 0xb88 // Size: 0x01
	char pad_0xB88_1 : 7; // Offset: 0xb88 // Size: 0x01
	char pad_0xB89[0x3]; // Offset: 0xb89 // Size: 0x03
	float SyncRotationSpeed; // Offset: 0xb8c // Size: 0x04
	float SyncRotationMoveSpeed; // Offset: 0xb90 // Size: 0x04
	float SyncRotationAcceptableAngle; // Offset: 0xb94 // Size: 0x04
	struct AActor* SplineActorClass; // Offset: 0xb98 // Size: 0x08
	float MaxSwoopDownSpeed; // Offset: 0xba0 // Size: 0x04
	float SplineCurveTangentLength; // Offset: 0xba4 // Size: 0x04
	float PreCatchEnterDistance; // Offset: 0xba8 // Size: 0x04
	char pad_0xBAC[0x4]; // Offset: 0xbac // Size: 0x04
	struct TArray<float> ModifyEnterSplinePointDistanceArr; // Offset: 0xbb0 // Size: 0x10
	struct UCurveFloat* SwoopSpeedCurve; // Offset: 0xbc0 // Size: 0x08
	struct FVector2D SwoopSpeedSafeRange; // Offset: 0xbc8 // Size: 0x08
	struct TMap<struct FVector2D, struct FVector2D> DirectionCorrectMoveSpeedMap; // Offset: 0xbd0 // Size: 0x50
	float DistThresholdWhenInputAllowed; // Offset: 0xc20 // Size: 0x04
	float MaxSwoopMoveDuration; // Offset: 0xc24 // Size: 0x04
	float SwoopMoveBlockedDurationThreshold; // Offset: 0xc28 // Size: 0x04
	char pad_0xC2C[0x14]; // Offset: 0xc2c // Size: 0x14
	struct FVector DiveStartDirection; // Offset: 0xc40 // Size: 0x0c
	struct FVector DiveDirection; // Offset: 0xc4c // Size: 0x0c
	float MaxDiveSpeed; // Offset: 0xc58 // Size: 0x04
	float MaxDiveTime; // Offset: 0xc5c // Size: 0x04
	float DiveTurnTime; // Offset: 0xc60 // Size: 0x04
	float DivingCoolDown; // Offset: 0xc64 // Size: 0x04
	bool bDivingResetCamera; // Offset: 0xc68 // Size: 0x01
	char pad_0xC69[0x37]; // Offset: 0xc69 // Size: 0x37
	struct UCurveVector* SpeedCurve; // Offset: 0xca0 // Size: 0x08
	struct UCurveVector* PositionCurve; // Offset: 0xca8 // Size: 0x08
	char pad_0xCB0[0x30]; // Offset: 0xcb0 // Size: 0x30
	struct UCurveVector* LandingCurve; // Offset: 0xce0 // Size: 0x08
	float MaxTakeOffTime; // Offset: 0xce8 // Size: 0x04
	char pad_0xCEC[0x4]; // Offset: 0xcec // Size: 0x04
	struct UCurveVector* TakeOffCurve; // Offset: 0xcf0 // Size: 0x08
	struct UCurveFloat* DivingCurve; // Offset: 0xcf8 // Size: 0x08
	struct FVector SwoopingDownVelocity; // Offset: 0xd00 // Size: 0x0c
	bool bSwoopTurnLeft; // Offset: 0xd0c // Size: 0x01
	char pad_0xD0D[0x3]; // Offset: 0xd0d // Size: 0x03
	int LandingConfigIndex; // Offset: 0xd10 // Size: 0x04
	char pad_0xD14[0x4]; // Offset: 0xd14 // Size: 0x04
	struct TArray<struct FPterosaurLandingConfig> LandingConfigs; // Offset: 0xd18 // Size: 0x10
	struct AActor* CacheSplineActor; // Offset: 0xd28 // Size: 0x08
	char pad_0xD30[0x8]; // Offset: 0xd30 // Size: 0x08
	float MaxAutoLandingTime; // Offset: 0xd38 // Size: 0x04
	float bNoDriverForceNoSimulate; // Offset: 0xd3c // Size: 0x04
	float bNoDriverForceLanding; // Offset: 0xd40 // Size: 0x04
	float bCheckClientFlyingHeight; // Offset: 0xd44 // Size: 0x04
	char pad_0xD48[0x8]; // Offset: 0xd48 // Size: 0x08

	// Functions

	// Object Name: Function Addons.PterosaurMovementComponent.UpdateVerticalHeight
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void UpdateVerticalHeight(float DeltaTime); // Offset: 0x103ee055c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.PterosaurMovementComponent.StartTakingOff
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartTakingOff(); // Offset: 0x103ee0548 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.PterosaurMovementComponent.StartSwoopDown
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void StartSwoopDown(struct FVector TargetLocation); // Offset: 0x103ee04cc // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Addons.PterosaurMovementComponent.StartLanding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartLanding(); // Offset: 0x103ee04b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.PterosaurMovementComponent.StartFlyingDive
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartFlyingDive(); // Offset: 0x103ee04a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.PterosaurMovementComponent.SetServerDiveDirection
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|HasDefaults|BlueprintCallable|NetValidate]
	void SetServerDiveDirection(struct FVector Direction); // Offset: 0x103ee03f4 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Addons.PterosaurMovementComponent.SetMovementMode
	// Flags: [Native|Public|BlueprintCallable]
	void SetMovementMode(enum class EMovementMode NewMovementMode, char NewCustomMode); // Offset: 0x103ee0334 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Addons.PterosaurMovementComponent.SetAutoLanding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoLanding(float Value); // Offset: 0x103ee02b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.PterosaurMovementComponent.IsTakingOff
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsTakingOff(); // Offset: 0x103ee0284 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurMovementComponent.IsSwoopDown
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsSwoopDown(); // Offset: 0x103ee0250 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurMovementComponent.IsSwoopCatching
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsSwoopCatching(); // Offset: 0x103ee021c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurMovementComponent.IsStrugglingToLand
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsStrugglingToLand(); // Offset: 0x103ee01e8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurMovementComponent.IsLocalSwoopingDown
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsLocalSwoopingDown(); // Offset: 0x103ee01b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurMovementComponent.IsLandingWalking
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLandingWalking(); // Offset: 0x103ee0180 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurMovementComponent.IsLanding
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLanding(); // Offset: 0x103ee014c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurMovementComponent.IsDiving
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsDiving(); // Offset: 0x103ee0118 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurMovementComponent.IsCurveMoving
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsCurveMoving(); // Offset: 0x103ee00e4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurMovementComponent.GetMoveState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EPterosaurMoveMode GetMoveState(); // Offset: 0x103ee00b0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurMovementComponent.GetDistanceToLand
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetDistanceToLand(); // Offset: 0x103ee007c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.PterosaurMovementComponent.ExitSwoopDown
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ExitSwoopDown(); // Offset: 0x103ee0068 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.PterosaurMovementComponent.ExitLanding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ExitLanding(); // Offset: 0x103ee0054 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.PterosaurMovementComponent.EndTakingOff
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EndTakingOff(); // Offset: 0x103ee0040 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.PterosaurMovementComponent.EndSwoopDown
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EndSwoopDown(bool bRestVelocity); // Offset: 0x103edffbc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurMovementComponent.EndLanding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EndLanding(); // Offset: 0x103edffa8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.PterosaurMovementComponent.EndFlyingDive
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EndFlyingDive(); // Offset: 0x103edff94 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.PterosaurMovementComponent.DealWithCustomAction
	// Flags: [Native|Public]
	void DealWithCustomAction(float DeltaTime); // Offset: 0x103edff10 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.PterosaurMovementComponent.CheckCanStartFlyingDive
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool CheckCanStartFlyingDive(); // Offset: 0x103edfedc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurMovementComponent.CalculateFlyingVelocity
	// Flags: [Native|Protected|BlueprintCallable]
	void CalculateFlyingVelocity(float DeltaTime); // Offset: 0x103edfe58 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.PterosaurMovementComponent.CalculateFlyingAcceleration
	// Flags: [Native|Protected|BlueprintCallable]
	void CalculateFlyingAcceleration(float DeltaTime); // Offset: 0x103edfdd4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.PterosaurMovementComponent.CalculateDivingVelocity
	// Flags: [Native|Protected|BlueprintCallable]
	void CalculateDivingVelocity(float DeltaTime); // Offset: 0x103edfd50 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Addons.PterosaurVehicle
// Size: 0x1890 // Inherited bytes: 0x17c0
struct APterosaurVehicle : ABioVehicleBase {
	// Fields
	float OpenParachuteHeightInPterosuar; // Offset: 0x17c0 // Size: 0x04
	float CanOpenParachuteHeightInPterosaur; // Offset: 0x17c4 // Size: 0x04
	float ForceOpenParachuteHeightInPterosaur; // Offset: 0x17c8 // Size: 0x04
	float CloseParachuteHeightInPterosaur; // Offset: 0x17cc // Size: 0x04
	float SkipOpenParachuteHeightInPterosuar; // Offset: 0x17d0 // Size: 0x04
	float MaxExecSwoopCatchDistance; // Offset: 0x17d4 // Size: 0x04
	float MinExecSwoopCatchDistance2D; // Offset: 0x17d8 // Size: 0x04
	float MaxCatchableDistance; // Offset: 0x17dc // Size: 0x04
	float SwoopCatchCoolDown; // Offset: 0x17e0 // Size: 0x04
	bool bShouldIgnoreHitPlayerWhenSwoopDown; // Offset: 0x17e4 // Size: 0x01
	char SyncSwoopCatchState; // Offset: 0x17e5 // Size: 0x01
	char pad_0x17E6[0x2]; // Offset: 0x17e6 // Size: 0x02
	struct ASTExtraBaseCharacter* ArrestCharacter; // Offset: 0x17e8 // Size: 0x08
	struct FVector TargetCatchLocation; // Offset: 0x17f0 // Size: 0x0c
	char pad_0x17FC[0x4]; // Offset: 0x17fc // Size: 0x04
	struct UPterosaurMovementComponent* PterosaurMoveComponent; // Offset: 0x1800 // Size: 0x08
	float DiveReadyTime; // Offset: 0x1808 // Size: 0x04
	char pad_0x180C[0x4]; // Offset: 0x180c // Size: 0x04
	struct FScriptMulticastDelegate OnPterosaurVehicleDive; // Offset: 0x1810 // Size: 0x10
	struct FScriptMulticastDelegate OnPterosaurVehicleDiveEnd; // Offset: 0x1820 // Size: 0x10
	struct FScriptMulticastDelegate OnPterosaurVehicleGroundDead; // Offset: 0x1830 // Size: 0x10
	struct FScriptMulticastDelegate OnPterosaurVehicleTopBlocked; // Offset: 0x1840 // Size: 0x10
	char pad_0x1850[0x8]; // Offset: 0x1850 // Size: 0x08
	bool bIsGroundDead; // Offset: 0x1858 // Size: 0x01
	char pad_0x1859[0x7]; // Offset: 0x1859 // Size: 0x07
	struct FScriptMulticastDelegate OnPterosaurVehicleDead; // Offset: 0x1860 // Size: 0x10
	struct UAnimMontage* CatchPassengerAnim; // Offset: 0x1870 // Size: 0x08
	struct UAnimMontage* PrepareCatchPassengerAnim; // Offset: 0x1878 // Size: 0x08
	struct UDynamicOptimizeActorComponents* DynamicOptimizeComponent; // Offset: 0x1880 // Size: 0x08
	char pad_0x1888[0x4]; // Offset: 0x1888 // Size: 0x04
	float FlyingHoverConsumeFuelRate; // Offset: 0x188c // Size: 0x04

	// Functions

	// Object Name: Function Addons.PterosaurVehicle.TryFlyingDive
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TryFlyingDive(bool bTry); // Offset: 0x103ee1c40 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurVehicle.TryCancelSwoopDown
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TryCancelSwoopDown(); // Offset: 0x103ee1c2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.PterosaurVehicle.SetBoosting
	// Flags: [Native|Public]
	void SetBoosting(bool bEnabled); // Offset: 0x103ee1ba0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurVehicle.ServerSwoopDown
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|HasDefaults|BlueprintCallable|NetValidate]
	void ServerSwoopDown(struct FVector TargetLocation, bool IsForceEnd); // Offset: 0x103ee1a9c // Return & Params: Num(2) Size(0xd)

	// Object Name: Function Addons.PterosaurVehicle.ServerReleaseCharacter
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	void ServerReleaseCharacter(struct ASTExtraBaseCharacter* Requester); // Offset: 0x103ee19f0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Addons.PterosaurVehicle.OnRep_SyncSwoopCatchState
	// Flags: [Event|Protected|BlueprintEvent]
	void OnRep_SyncSwoopCatchState(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.PterosaurVehicle.OnPterosaurSwoopStateChanged
	// Flags: [Final|Native|Protected|HasDefaults]
	void OnPterosaurSwoopStateChanged(enum class EPterosaurSwoopStage NewStage, struct FVector TargetLocation); // Offset: 0x103ee1938 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Addons.PterosaurVehicle.OnPterosaurPrepareCatch
	// Flags: [Final|Native|Public]
	void OnPterosaurPrepareCatch(); // Offset: 0x103ee1924 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.PterosaurVehicle.OnClientExitFromPterosaur
	// Flags: [Native|Event|Public|BlueprintEvent]
	void OnClientExitFromPterosaur(struct ASTExtraPlayerCharacter* Character, enum class ESTExtraVehicleSeatType SeatType); // Offset: 0x103ee1864 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Addons.PterosaurVehicle.MultiCast_SwoopDown
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|HasDefaults|BlueprintCallable]
	void MultiCast_SwoopDown(struct FVector TargetLocation); // Offset: 0x103ee17e0 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Addons.PterosaurVehicle.MultiCast_SplineCorrect
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|HasDefaults|BlueprintCallable]
	void MultiCast_SplineCorrect(struct FVector SyncLocation, struct FVector TargetLocation, struct TArray<struct FVector> SplinePoints); // Offset: 0x103ee16c8 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Addons.PterosaurVehicle.IsSwoopDown
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsSwoopDown(); // Offset: 0x103ee1694 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurVehicle.IsSwoopCoolDown
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsSwoopCoolDown(); // Offset: 0x103ee1660 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurVehicle.IsSwoopCatching
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsSwoopCatching(); // Offset: 0x103ee162c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurVehicle.HandleOnSeatDetached
	// Flags: [Native|Public]
	void HandleOnSeatDetached(struct ASTExtraPlayerCharacter* Character, enum class ESTExtraVehicleSeatType SeatType, int SeatIdx); // Offset: 0x103ee1530 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Addons.PterosaurVehicle.HandleOnSeatAttached
	// Flags: [Native|Public]
	void HandleOnSeatAttached(struct ASTExtraPlayerCharacter* Character, enum class ESTExtraVehicleSeatType SeatType, int SeatIdx); // Offset: 0x103ee1434 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Addons.PterosaurVehicle.GetPterosaurMovementComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UPterosaurMovementComponent* GetPterosaurMovementComponent(); // Offset: 0x103ee1400 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Addons.PterosaurVehicle.GetConsumeFuelRate
	// Flags: [Native|Public|Const]
	float GetConsumeFuelRate(); // Offset: 0x103ee13c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.PterosaurVehicle.ForceCatchCharacter
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool ForceCatchCharacter(struct ASTExtraBaseCharacter* Character); // Offset: 0x103ee1338 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Addons.PterosaurVehicle.DoSwoopDown
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	bool DoSwoopDown(struct FVector TargetLocation); // Offset: 0x103ee12ac // Return & Params: Num(2) Size(0xd)

	// Object Name: Function Addons.PterosaurVehicle.CanConsumeFuel
	// Flags: [Native|Public|Const]
	bool CanConsumeFuel(); // Offset: 0x103ee1270 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.PterosaurVehicle.BroadCastOnPterosaurPrepareCatch
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void BroadCastOnPterosaurPrepareCatch(); // Offset: 0x103ee1254 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.PterosaurVehicle.BPOnPterosaurSwoopStateChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BPOnPterosaurSwoopStateChanged(char NewStage); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Addons.RaptorAnimInstance
// Size: 0x7d0 // Inherited bytes: 0x710
struct URaptorAnimInstance : ULandingCreatureAnimInstance {
	// Fields
	float PitchInterpolateSpeed; // Offset: 0x708 // Size: 0x04
	float YawInterpolateSpeed; // Offset: 0x70c // Size: 0x04
	float TiltTraceDeltaTime; // Offset: 0x710 // Size: 0x04
	int HeadTiltBoneNum; // Offset: 0x714 // Size: 0x04
	struct UCurveFloat* HeadTiltCurve; // Offset: 0x718 // Size: 0x08
	float HeadBlockHeightOffset; // Offset: 0x720 // Size: 0x04
	float HeadBlockForwardStartOffset; // Offset: 0x724 // Size: 0x04
	float HeadBlockForwardEndOffset; // Offset: 0x728 // Size: 0x04
	float HeadBlockTraceRadius; // Offset: 0x72c // Size: 0x04
	float HeadTiltRotateSpeed; // Offset: 0x730 // Size: 0x04
	float HeadTiltMaxAngle; // Offset: 0x734 // Size: 0x04
	int TailTiltBoneNum; // Offset: 0x738 // Size: 0x04
	int PitchYawDegreeThreshold; // Offset: 0x73c // Size: 0x04
	struct TArray<struct UCurveFloat*> TailTiltCurves; // Offset: 0x740 // Size: 0x10
	float TailBlockHeightOffset; // Offset: 0x750 // Size: 0x04
	float TailBlockForwardStartOffset; // Offset: 0x754 // Size: 0x04
	float TailBlockForwardEndOffset; // Offset: 0x758 // Size: 0x04
	float TailBlockTraceRadius; // Offset: 0x75c // Size: 0x04
	float TailTiltRotateSpeed; // Offset: 0x760 // Size: 0x04
	float TailTiltMaxAngle; // Offset: 0x764 // Size: 0x04
	struct UAssetPlayerSyncNode* AssetPlayerSyncNode; // Offset: 0x768 // Size: 0x08
	bool bEnableHeadTilt; // Offset: 0x770 // Size: 0x01
	bool bEnableTailTilt; // Offset: 0x771 // Size: 0x01
	bool bHeadBlocked; // Offset: 0x772 // Size: 0x01
	bool bTailBlocked; // Offset: 0x773 // Size: 0x01
	float HeadYawDelta; // Offset: 0x774 // Size: 0x04
	float HeadYawDeltaPerBone; // Offset: 0x778 // Size: 0x04
	struct TArray<float> TailYawDeltaPerBone; // Offset: 0x780 // Size: 0x10
	struct TArray<float> TailPitchDeltaPerBone; // Offset: 0x790 // Size: 0x10
	float ObstacleDegree; // Offset: 0x7a0 // Size: 0x04
	char pad_0x7A8[0x28]; // Offset: 0x7a8 // Size: 0x28
};

// Object Name: Class Addons.RaptorDriverAnimInstance
// Size: 0x640 // Inherited bytes: 0x560
struct URaptorDriverAnimInstance : UBioVehicleRiderAnimInstanceBase {
	// Fields
	struct FName LeftHandSaddleSocketName; // Offset: 0x558 // Size: 0x08
	struct FName RightHandSaddleSocketName; // Offset: 0x560 // Size: 0x08
	float ThrottleInput; // Offset: 0x568 // Size: 0x04
	float SteeringInput; // Offset: 0x56c // Size: 0x04
	bool bEnableNewStateMachine; // Offset: 0x570 // Size: 0x01
	bool bHasAcceleration; // Offset: 0x571 // Size: 0x01
	bool bIsJumping; // Offset: 0x572 // Size: 0x01
	bool bIsStopping; // Offset: 0x573 // Size: 0x01
	bool bIsRunStopping; // Offset: 0x574 // Size: 0x01
	bool bDoRandomIdle; // Offset: 0x575 // Size: 0x01
	int RandomIdleIndex; // Offset: 0x578 // Size: 0x04
	bool bIsInAir; // Offset: 0x57c // Size: 0x01
	struct UAssetPlayerSyncNode* AssetPlayerSyncNode; // Offset: 0x580 // Size: 0x08
	float Speed; // Offset: 0x588 // Size: 0x04
	float Direction; // Offset: 0x58c // Size: 0x04
	float BodyLeanAngle; // Offset: 0x590 // Size: 0x04
	float HeadPitchDelta; // Offset: 0x594 // Size: 0x04
	float HeadYawDelta; // Offset: 0x598 // Size: 0x04
	struct FVector LeftHandEffectorLocation; // Offset: 0x59c // Size: 0x0c
	struct FVector RightHandEffectorLocation; // Offset: 0x5a8 // Size: 0x0c
	float HandIkAlpha; // Offset: 0x5b4 // Size: 0x04
	bool bEnableHandIK; // Offset: 0x5b8 // Size: 0x01
	bool bEnableDistanceMatching; // Offset: 0x5b9 // Size: 0x01
	char pad_0x5BD[0x3]; // Offset: 0x5bd // Size: 0x03
	struct UAnimSequence* IdleAnim; // Offset: 0x5c0 // Size: 0x08
	struct UAnimSequence* RunStopLAnim; // Offset: 0x5c8 // Size: 0x08
	struct UAnimSequence* RunStopRAnim; // Offset: 0x5d0 // Size: 0x08
	struct UAnimSequence* WalkStopLAnim; // Offset: 0x5d8 // Size: 0x08
	struct UAnimSequence* WalkStopRAnim; // Offset: 0x5e0 // Size: 0x08
	struct UAnimSequence* RandomIdleAnim1; // Offset: 0x5e8 // Size: 0x08
	struct UAnimSequence* RandomIdleAnim2; // Offset: 0x5f0 // Size: 0x08
	struct UBlendSpace* MovementAnim; // Offset: 0x5f8 // Size: 0x08
	struct UAnimSequence* JumpStartAnim; // Offset: 0x600 // Size: 0x08
	struct UAnimSequence* FallingAnim; // Offset: 0x608 // Size: 0x08
	struct UAnimSequence* IdleLandingAnim; // Offset: 0x610 // Size: 0x08
	struct UAnimSequence* RunLandingAnim; // Offset: 0x618 // Size: 0x08
	struct UBlendSpace1D* TurnStartAnim; // Offset: 0x620 // Size: 0x08
	struct UBlendSpace1D* TurningAnim; // Offset: 0x628 // Size: 0x08
	struct UBlendSpace1D* TurnEndAnim; // Offset: 0x630 // Size: 0x08
	struct TWeakObjectPtr<struct URaptorAnimInstance> OwnedRaptorAnimInstance; // Offset: 0x638 // Size: 0x08

	// Functions

	// Object Name: Function Addons.RaptorDriverAnimInstance.OnOwnedRaptorJumped
	// Flags: [Final|Native|Public]
	void OnOwnedRaptorJumped(); // Offset: 0x103ee3f10 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Addons.RaptorMovementComponent
// Size: 0xb40 // Inherited bytes: 0xaf0
struct URaptorMovementComponent : UBioVehicleMovementComponent {
	// Fields
	float AngularSpeedInterpSpeed; // Offset: 0xaf0 // Size: 0x04
	struct FVector SpotRotator; // Offset: 0xaf4 // Size: 0x0c
	float SpotTurnStartTime; // Offset: 0xb00 // Size: 0x04
	float SpotTurnEndTime; // Offset: 0xb04 // Size: 0x04
	float targetAngularSpeed; // Offset: 0xb08 // Size: 0x04
	float SpotTurnAngularSpeed; // Offset: 0xb0c // Size: 0x04
	float fBeginTurnInterpSpeed; // Offset: 0xb10 // Size: 0x04
	float fEndTurnInterpSpeed; // Offset: 0xb14 // Size: 0x04
	float AngularSpeedLerpFactor; // Offset: 0xb18 // Size: 0x04
	float RightToLeftSpeedLerpFactor; // Offset: 0xb1c // Size: 0x04
	float LowSpeedRotationThreshold; // Offset: 0xb20 // Size: 0x04
	float PhysicsRotateTolerance; // Offset: 0xb24 // Size: 0x04
	bool bCanAdjustMovementFloor; // Offset: 0xb28 // Size: 0x01
	char pad_0xB29[0x3]; // Offset: 0xb29 // Size: 0x03
	float BreakOutAcclerationRate; // Offset: 0xb2c // Size: 0x04
	float BreakOutVelocityRate; // Offset: 0xb30 // Size: 0x04
	char pad_0xB34[0x4]; // Offset: 0xb34 // Size: 0x04
	struct UCurveFloat* BreakOutAccResistanceCurve; // Offset: 0xb38 // Size: 0x08

	// Functions

	// Object Name: Function Addons.RaptorMovementComponent.GetWalkingAccResistance
	// Flags: [Native|Public|BlueprintCallable]
	float GetWalkingAccResistance(float Speed); // Offset: 0x103ee4124 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Addons.RaptorMovementComponent.GetMaxAcceleration
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMaxAcceleration(); // Offset: 0x103ee40e8 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Addons.RaptorVehicle
// Size: 0x17f0 // Inherited bytes: 0x17c0
struct ARaptorVehicle : ABioVehicleBase {
	// Fields
	struct URaptorMovementComponent* RaptorMovementComponent; // Offset: 0x17c0 // Size: 0x08
	struct FScriptMulticastDelegate OnReachStopPoint; // Offset: 0x17c8 // Size: 0x10
	struct FName LeftFootBoneName; // Offset: 0x17d8 // Size: 0x08
	struct FName RightFootBoneName; // Offset: 0x17e0 // Size: 0x08
	bool bCanRideWhenSwimming; // Offset: 0x17e8 // Size: 0x01
	char pad_0x17E9[0x7]; // Offset: 0x17e9 // Size: 0x07

	// Functions

	// Object Name: Function Addons.RaptorVehicle.SetHandBrake
	// Flags: [Native|Public|BlueprintCallable]
	void SetHandBrake(float Rate); // Offset: 0x103ee47b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.RaptorVehicle.SetBoosting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void SetBoosting(bool bEnabled); // Offset: 0x103ee4724 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.RaptorVehicle.ServerSetHandBrake
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerSetHandBrake(float Rate); // Offset: 0x103ee4678 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.RaptorVehicle.MulticastDoJump
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void MulticastDoJump(); // Offset: 0x103ee465c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.RaptorVehicle.MoveRight
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void MoveRight(float Rate); // Offset: 0x103ee45d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.RaptorVehicle.MoveForward
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void MoveForward(float Rate); // Offset: 0x103ee4554 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Addons.RaptorVehicle.GetRaptorMovementComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct URaptorMovementComponent* GetRaptorMovementComponent(); // Offset: 0x103ee4520 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Addons.RaptorVehicle.DoJump
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DoJump(); // Offset: 0x103ee450c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Addons.TRexVehicleDamageComponent
// Size: 0x5a0 // Inherited bytes: 0x4f0
struct UTRexVehicleDamageComponent : UBioVehicleDamageComponent {
	// Fields
	struct FName DamageComponentTag; // Offset: 0x4e8 // Size: 0x08
	struct FName BlockComponentTag; // Offset: 0x4f0 // Size: 0x08
	bool ImpulseOnCharacter; // Offset: 0x4f8 // Size: 0x01
	struct UCurveFloat* VehicleHitCharcterImpulseCurve; // Offset: 0x500 // Size: 0x08
	float DefaultImpuleScale; // Offset: 0x508 // Size: 0x04
	float ImpulseCharacterZScale; // Offset: 0x50c // Size: 0x04
	float BioDamageVehicleCooldownTime; // Offset: 0x510 // Size: 0x04
	float DefaultHitVehicleDamage; // Offset: 0x514 // Size: 0x04
	bool bUseCollisionLocation; // Offset: 0x518 // Size: 0x01
	char pad_0x51A[0x6]; // Offset: 0x51a // Size: 0x06
	struct ATyrannosaurusRexVehicle* OwnerVehicle; // Offset: 0x520 // Size: 0x08
	struct TMap<struct AActor*, float> BioDamageVehicleTimes; // Offset: 0x528 // Size: 0x50
	struct TArray<struct ASTExtraVehicleBase*> LastOverlapedVehicles; // Offset: 0x578 // Size: 0x10
	struct TArray<struct UActorComponent*> DamageCollisions; // Offset: 0x588 // Size: 0x10
	struct UPrimitiveComponent* BlockCollision; // Offset: 0x598 // Size: 0x08

	// Functions

	// Object Name: Function Addons.TRexVehicleDamageComponent.HandleFootOverlapVehicle
	// Flags: [Final|Native|Public|HasOutParms]
	void HandleFootOverlapVehicle(struct ASTExtraVehicleBase* OverlappedVehicle, struct UShapeComponent* DamageCollision, struct FOverlapResult& OverlapResult); // Offset: 0x103ee4c98 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Addons.TRexVehicleDamageComponent.HandleFootOverlapCharacter
	// Flags: [Final|Native|Public|HasOutParms]
	void HandleFootOverlapCharacter(struct ASTExtraBaseCharacter* OverlappedCharacter, struct UShapeComponent* DamageCollision, struct FOverlapResult& OverlapResult); // Offset: 0x103ee4b68 // Return & Params: Num(3) Size(0x28)
};

// Object Name: Class Addons.TyrannosaurusRexAnimInstance
// Size: 0x740 // Inherited bytes: 0x710
struct UTyrannosaurusRexAnimInstance : ULandingCreatureAnimInstance {
	// Fields
	float WalkSpeed; // Offset: 0x708 // Size: 0x04
	float RunSpeed; // Offset: 0x70c // Size: 0x04
	float SprintSpeed; // Offset: 0x710 // Size: 0x04
	float MinPlayRate; // Offset: 0x714 // Size: 0x04
	float MaxPlayRate; // Offset: 0x718 // Size: 0x04
	struct ATyrannosaurusRexVehicle* TRex; // Offset: 0x720 // Size: 0x08
	bool bStartMoving; // Offset: 0x728 // Size: 0x01
	float WalkPlayRate; // Offset: 0x72c // Size: 0x04
	float RunPlayRate; // Offset: 0x730 // Size: 0x04
	float SprintPlayRate; // Offset: 0x734 // Size: 0x04
	char pad_0x739[0x7]; // Offset: 0x739 // Size: 0x07

	// Functions

	// Object Name: Function Addons.TyrannosaurusRexAnimInstance.ResetStartMoving
	// Flags: [Final|Native|Private]
	void ResetStartMoving(); // Offset: 0x103ee4f78 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Addons.TyrannosaurusRexVehicle
// Size: 0x19b0 // Inherited bytes: 0x17c0
struct ATyrannosaurusRexVehicle : ABioVehicleBase {
	// Fields
	struct UBoxComponent* BrokenShapeComponent; // Offset: 0x17c0 // Size: 0x08
	float NearbyRadius; // Offset: 0x17c8 // Size: 0x04
	char pad_0x17CC[0x4]; // Offset: 0x17cc // Size: 0x04
	struct FName RoarDetectSocket; // Offset: 0x17d0 // Size: 0x08
	float RoarSpeedThreshold; // Offset: 0x17d8 // Size: 0x04
	float RoarCD; // Offset: 0x17dc // Size: 0x04
	float RoarStartAttackTime; // Offset: 0x17e0 // Size: 0x04
	float RoarEndAttackTime; // Offset: 0x17e4 // Size: 0x04
	float RoarAttackDeltaTime; // Offset: 0x17e8 // Size: 0x04
	float RoarDamage; // Offset: 0x17ec // Size: 0x04
	struct UAnimMontage* RoarMontage; // Offset: 0x17f0 // Size: 0x08
	struct UCameraShake* RoarCameraShake; // Offset: 0x17f8 // Size: 0x08
	struct FScriptMulticastDelegate OnTRexApplyRoarAttack; // Offset: 0x1800 // Size: 0x10
	struct FScriptMulticastDelegate OnServerTRexStartRoar; // Offset: 0x1810 // Size: 0x10
	struct FScriptMulticastDelegate OnServerTRexFinishRoar; // Offset: 0x1820 // Size: 0x10
	struct UAkAudioEvent* TRexRoarAudioEvent; // Offset: 0x1830 // Size: 0x08
	struct FName TRexBodyMatSlotName; // Offset: 0x1838 // Size: 0x08
	struct FName ShelfMatSlotName; // Offset: 0x1840 // Size: 0x08
	struct UMaterialInstance* BodyNormalMaterial; // Offset: 0x1848 // Size: 0x08
	struct UMaterialInstance* ShelfNormalMaterial; // Offset: 0x1850 // Size: 0x08
	struct UMaterialInstance* BodyInjuredMaterial; // Offset: 0x1858 // Size: 0x08
	struct UMaterialInstance* ShelfInjuredMaterial; // Offset: 0x1860 // Size: 0x08
	struct UMaterialInstance* BodySeverelyInjuredMaterial; // Offset: 0x1868 // Size: 0x08
	struct UMaterialInstance* ShelfSeverelyInjuredMaterial; // Offset: 0x1870 // Size: 0x08
	struct FScriptMulticastDelegate OnServerTRexBreakOut; // Offset: 0x1878 // Size: 0x10
	float TRexBreakOutCD; // Offset: 0x1888 // Size: 0x04
	float TRexBreakOutInterval; // Offset: 0x188c // Size: 0x04
	struct UMaterialInterface* LightInjuredMat; // Offset: 0x1890 // Size: 0x08
	struct UMaterialInterface* HeavyInjuredMat; // Offset: 0x1898 // Size: 0x08
	float ModifyPhysCD; // Offset: 0x18a0 // Size: 0x04
	enum class ETyranState STCurWalkState; // Offset: 0x18a4 // Size: 0x01
	char pad_0x18A5[0x3]; // Offset: 0x18a5 // Size: 0x03
	struct FName BrokenCapsuleSocket; // Offset: 0x18a8 // Size: 0x08
	float BrokenCapsuleRadius; // Offset: 0x18b0 // Size: 0x04
	float BrokenCapsuleHeight; // Offset: 0x18b4 // Size: 0x04
	float BrokenDelayTime; // Offset: 0x18b8 // Size: 0x04
	float DragOffsetZ; // Offset: 0x18bc // Size: 0x04
	struct TArray<struct FVector> DragOffsets; // Offset: 0x18c0 // Size: 0x10
	float DeadAfterTime; // Offset: 0x18d0 // Size: 0x04
	char pad_0x18D4[0x4]; // Offset: 0x18d4 // Size: 0x04
	struct FScriptMulticastDelegate BioVehicleDestroyDelegate; // Offset: 0x18d8 // Size: 0x10
	bool DeadDirection; // Offset: 0x18e8 // Size: 0x01
	char pad_0x18E9[0x2b]; // Offset: 0x18e9 // Size: 0x2b
	float RoarCurrentCD; // Offset: 0x1914 // Size: 0x04
	bool bIsRoaring; // Offset: 0x1918 // Size: 0x01
	char pad_0x1919[0xf]; // Offset: 0x1919 // Size: 0x0f
	struct TMap<struct AActor*, float> BioModifyVehicleTimes; // Offset: 0x1928 // Size: 0x50
	struct URaptorMovementComponent* TRexMovementComponent; // Offset: 0x1978 // Size: 0x08
	float HurtInterval; // Offset: 0x1980 // Size: 0x04
	char pad_0x1984[0x4]; // Offset: 0x1984 // Size: 0x04
	float HurtDamageAmount; // Offset: 0x1988 // Size: 0x04
	char pad_0x198C[0xc]; // Offset: 0x198c // Size: 0x0c
	struct UAnimMontage* HurtMontage; // Offset: 0x1998 // Size: 0x08
	struct FName LeftFootBoneName; // Offset: 0x19a0 // Size: 0x08
	struct FName RightFootBoneName; // Offset: 0x19a8 // Size: 0x08

	// Functions

	// Object Name: Function Addons.TyrannosaurusRexVehicle.ShowRoarOverSpeedTips
	// Flags: [Native|Event|Public|BlueprintEvent]
	void ShowRoarOverSpeedTips(); // Offset: 0x103ee5ef4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.ShakeNearbyPlayerCamera
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	void ShakeNearbyPlayerCamera(struct UCameraShake* CameraShakeClass, float Radius); // Offset: 0x103ee5e08 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.ServerStopRoar
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	void ServerStopRoar(); // Offset: 0x103ee5dac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.ServerRoar
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	void ServerRoar(); // Offset: 0x103ee5d50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.ServerBreakOut
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|BlueprintCallable|NetValidate]
	void ServerBreakOut(bool bEnable); // Offset: 0x103ee5c90 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.PrepareApplyRoarAttack
	// Flags: [Final|Native|Public]
	void PrepareApplyRoarAttack(); // Offset: 0x103ee5c7c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.OnTRexHPCHanged
	// Flags: [Final|Native|Public]
	void OnTRexHPCHanged(float NewHP, float HPMax); // Offset: 0x103ee5bc8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.OnRoarFinished
	// Flags: [Final|Native|Public]
	void OnRoarFinished(enum class EBioVehicleSkillStopReason Reason); // Offset: 0x103ee5b4c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.OnRep_bIsRoaring
	// Flags: [Final|Native|Public]
	void OnRep_bIsRoaring(); // Offset: 0x103ee5b38 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.GetVehicleMovement
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct URaptorMovementComponent* GetVehicleMovement(); // Offset: 0x103ee5b04 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.GetVehicleBreakOutState
	// Flags: [Native|Public|BlueprintCallable]
	bool GetVehicleBreakOutState(); // Offset: 0x103ee5ac8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.GetNearlyPlayers
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool GetNearlyPlayers(float Radius, struct TArray<struct ASTExtraBaseCharacter*>& Results); // Offset: 0x103ee59d4 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.EndRoarAttack
	// Flags: [Final|Native|Public]
	void EndRoarAttack(); // Offset: 0x103ee59c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.ClientHandleVehicleDead
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void ClientHandleVehicleDead(bool VehicleDeadDirection); // Offset: 0x103ee5934 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.CheckCanApplyDamageTo
	// Flags: [Native|Event|Public|BlueprintEvent]
	bool CheckCanApplyDamageTo(struct ASTExtraBaseCharacter* Target); // Offset: 0x103ee58a0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.CallClientDrawDebugSphere
	// Flags: [Net|Native|Event|NetMulticast|Protected|HasDefaults]
	void CallClientDrawDebugSphere(struct FVector Location, float DeltaTime); // Offset: 0x103ee57e0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.BroadCastStopMontage
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void BroadCastStopMontage(); // Offset: 0x103ee57c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.BroadCastPlayRoarMontage
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void BroadCastPlayRoarMontage(); // Offset: 0x103ee57a8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.BroadCastClientDrawSphere
	// Flags: [Net|Native|Event|NetMulticast|Public|HasDefaults]
	void BroadCastClientDrawSphere(struct FVector Center, float Radius); // Offset: 0x103ee56e8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.BreakOut
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void BreakOut(bool bEnable); // Offset: 0x103ee5664 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.ApplyRoarAttackToSpecifiedCharacter
	// Flags: [Native|Event|Public|BlueprintEvent]
	void ApplyRoarAttackToSpecifiedCharacter(struct ASTExtraBaseCharacter* TargetCharacter); // Offset: 0x103ee55e0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Addons.TyrannosaurusRexVehicle.ApplyRoarAttack
	// Flags: [Final|Native|Public]
	void ApplyRoarAttack(); // Offset: 0x103ee55cc // Return & Params: Num(0) Size(0x0)
};

