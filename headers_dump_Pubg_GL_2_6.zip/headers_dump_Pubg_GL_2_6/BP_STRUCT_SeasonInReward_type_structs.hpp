//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SeasonInReward_type.BP_STRUCT_SeasonInReward_type
// Size: 0xa0 // Inherited bytes: 0x00
struct FBP_STRUCT_SeasonInReward_type {
	// Fields
	int ID_0_964A41E64797BE94B20593BEF1C4EFC2; // Offset: 0x00 // Size: 0x04
	int RewardItemID_1_D3E59ED8407982FF649ADBAAEB8A7B43; // Offset: 0x04 // Size: 0x04
	int Condition2_Param2_2_3F721EFC4FA2C72CCEEB6DB3AD4BFF03; // Offset: 0x08 // Size: 0x04
	int SeasonID_3_9E1BB794465267FD92F169BBF88EBBEF; // Offset: 0x0c // Size: 0x04
	int Condition1_Param_4_C1E36B51450EEDB925CAB6B1B1C0142B; // Offset: 0x10 // Size: 0x04
	int SortID_5_D3BDDF714497FA14F8E3EB973EF35277; // Offset: 0x14 // Size: 0x04
	int Condition2_Param1_6_C87AEB7F4A0307A0373B3895E3896662; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString Condition1_Desc_7_BF6807D04A8068840568AFAF5C5C7329; // Offset: 0x20 // Size: 0x10
	struct FString Condition2_Desc_8_F1D4498C458E4A3FD6EC3A8CEFF45FDD; // Offset: 0x30 // Size: 0x10
	int RewardID_12_3A90C3406D0C461929F8D4710CC99EC4; // Offset: 0x40 // Size: 0x04
	int RelateID_13_0E62A1404E80E51D7E0452B90C39BFC4; // Offset: 0x44 // Size: 0x04
	int RewardNum_14_5ABAEC004206761A606069BA0C99F47D; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct FString ImageUrl_blue_1_15_658E3200389482306FA3921D03587B11; // Offset: 0x50 // Size: 0x10
	struct FString ImageUrl_global_1_16_7FDAE44023DC882543E02C7E0A985301; // Offset: 0x60 // Size: 0x10
	struct FString ImageUrl_JK_1_17_47BCCD401F3CF73F16ECAD9300353CE1; // Offset: 0x70 // Size: 0x10
	struct FString BattleEnd_Desc_18_0FA59B004DFE71006895BCE90C4F9223; // Offset: 0x80 // Size: 0x10
	int JKRewardID_19_0850E8801211D96035C671CC0DCF0844; // Offset: 0x90 // Size: 0x04
	int JKRewardItemID_20_38950C4046652BB30AEB830F09978ED4; // Offset: 0x94 // Size: 0x04
	int JKRewardNum_21_203C71404F2BAB9953875F090CF09C6D; // Offset: 0x98 // Size: 0x04
	int Condition2_Param3_22_604E1DC05C459C710F7752FD05B7C4C3; // Offset: 0x9c // Size: 0x04
};

