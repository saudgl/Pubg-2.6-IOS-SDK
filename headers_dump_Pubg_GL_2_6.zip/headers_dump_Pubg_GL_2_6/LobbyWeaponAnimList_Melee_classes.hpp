//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass LobbyWeaponAnimList_Melee.LobbyWeaponAnimList_Melee_C
// Size: 0x270 // Inherited bytes: 0x270
struct ULobbyWeaponAnimList_Melee_C : UAELobbyCharAnimListComp {
};

