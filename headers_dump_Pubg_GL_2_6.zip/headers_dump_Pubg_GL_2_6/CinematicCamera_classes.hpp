//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class CinematicCamera.CameraRig_Crane
// Size: 0x420 // Inherited bytes: 0x3f0
struct ACameraRig_Crane : AActor {
	// Fields
	float CranePitch; // Offset: 0x3ec // Size: 0x04
	float CraneYaw; // Offset: 0x3f0 // Size: 0x04
	float CraneArmLength; // Offset: 0x3f4 // Size: 0x04
	bool bLockMountPitch; // Offset: 0x3f8 // Size: 0x01
	bool bLockMountYaw; // Offset: 0x3f9 // Size: 0x01
	char pad_0x3FE[0x2]; // Offset: 0x3fe // Size: 0x02
	struct USceneComponent* TransformComponent; // Offset: 0x400 // Size: 0x08
	struct USceneComponent* CraneYawControl; // Offset: 0x408 // Size: 0x08
	struct USceneComponent* CranePitchControl; // Offset: 0x410 // Size: 0x08
	struct USceneComponent* CraneCameraMount; // Offset: 0x418 // Size: 0x08
};

// Object Name: Class CinematicCamera.CameraRig_Rail
// Size: 0x408 // Inherited bytes: 0x3f0
struct ACameraRig_Rail : AActor {
	// Fields
	float CurrentPositionOnRail; // Offset: 0x3ec // Size: 0x04
	struct USceneComponent* TransformComponent; // Offset: 0x3f0 // Size: 0x08
	struct USplineComponent* RailSplineComponent; // Offset: 0x3f8 // Size: 0x08
	struct USceneComponent* RailCameraMount; // Offset: 0x400 // Size: 0x08
};

// Object Name: Class CinematicCamera.CineCameraActor
// Size: 0x9b0 // Inherited bytes: 0x970
struct ACineCameraActor : ACameraActor {
	// Fields
	struct FCameraLookatTrackingSettings LookatTrackingSettings; // Offset: 0x970 // Size: 0x30
	char pad_0x9A0[0x10]; // Offset: 0x9a0 // Size: 0x10

	// Functions

	// Object Name: Function CinematicCamera.CineCameraActor.GetCineCameraComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UCineCameraComponent* GetCineCameraComponent(); // Offset: 0x104c6cca4 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class CinematicCamera.CineCameraComponent
// Size: 0x970 // Inherited bytes: 0x8c0
struct UCineCameraComponent : UCameraComponent {
	// Fields
	struct FCameraFilmbackSettings FilmbackSettings; // Offset: 0x8b4 // Size: 0x0c
	struct FCameraLensSettings LensSettings; // Offset: 0x8c0 // Size: 0x14
	struct FCameraFocusSettings FocusSettings; // Offset: 0x8d8 // Size: 0x38
	float CurrentFocalLength; // Offset: 0x910 // Size: 0x04
	float CurrentAperture; // Offset: 0x914 // Size: 0x04
	float CurrentFocusDistance; // Offset: 0x918 // Size: 0x04
	char pad_0x924[0x4]; // Offset: 0x924 // Size: 0x04
	struct TArray<struct FNamedFilmbackPreset> FilmbackPresets; // Offset: 0x928 // Size: 0x10
	struct TArray<struct FNamedLensPreset> LensPresets; // Offset: 0x938 // Size: 0x10
	struct FString DefaultFilmbackPresetName; // Offset: 0x948 // Size: 0x10
	struct FString DefaultLensPresetName; // Offset: 0x958 // Size: 0x10
	float DefaultLensFocalLength; // Offset: 0x968 // Size: 0x04
	float DefaultLensFStop; // Offset: 0x96c // Size: 0x04

	// Functions

	// Object Name: Function CinematicCamera.CineCameraComponent.SetLensPresetByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLensPresetByName(struct FString InPresetName); // Offset: 0x104c6d518 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function CinematicCamera.CineCameraComponent.SetFilmbackPresetByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilmbackPresetByName(struct FString InPresetName); // Offset: 0x104c6d480 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function CinematicCamera.CineCameraComponent.GetVerticalFieldOfView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetVerticalFieldOfView(); // Offset: 0x104c6d44c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CinematicCamera.CineCameraComponent.GetLensPresetName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetLensPresetName(); // Offset: 0x104c6d3e8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function CinematicCamera.CineCameraComponent.GetHorizontalFieldOfView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetHorizontalFieldOfView(); // Offset: 0x104c6d3b4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CinematicCamera.CineCameraComponent.GetFilmbackPresetName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetFilmbackPresetName(); // Offset: 0x104c6d350 // Return & Params: Num(1) Size(0x10)
};

