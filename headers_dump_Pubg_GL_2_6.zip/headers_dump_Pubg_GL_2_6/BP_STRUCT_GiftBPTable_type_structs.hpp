//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_GiftBPTable_type.BP_STRUCT_GiftBPTable_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_GiftBPTable_type {
	// Fields
	struct FString GiftAniPath_0_116612401D7ECFD72A9F4BCF0B4BFE88; // Offset: 0x00 // Size: 0x10
	int ID_1_121869C02EC2913D7CAEEFD406BAD054; // Offset: 0x10 // Size: 0x04
};

