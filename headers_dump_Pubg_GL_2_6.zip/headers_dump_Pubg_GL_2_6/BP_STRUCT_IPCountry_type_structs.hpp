//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_IPCountry_type.BP_STRUCT_IPCountry_type
// Size: 0x18 // Inherited bytes: 0x00
struct FBP_STRUCT_IPCountry_type {
	// Fields
	int IPRegion_0_68A5480076FE2CFA55C1C9A40B61AD5E; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString regionCountry_1_6A0CC6C04051CAD136B96925003938A9; // Offset: 0x08 // Size: 0x10
};

