//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct ItemRecordData7.ItemRecordData7
// Size: 0x13 // Inherited bytes: 0x00
struct FItemRecordData7 {
	// Fields
	int ItemType_2_CC000069486107946E5ECAAF21EFAF0B; // Offset: 0x00 // Size: 0x04
	int WeightforOrder_4_E72E5D4C4B2B91B238136B89316C7DEF; // Offset: 0x04 // Size: 0x04
	float UnitWeight_f_7_1AEC4D7B4F3AC4894A33FBAAC0165559; // Offset: 0x08 // Size: 0x04
	int MaxCount_10_ADC2EE5A44ABBCF4C00515AB724AD5AA; // Offset: 0x0c // Size: 0x04
	bool AutoEquipandDrop_13_CC1AD656453F2BAB5FCB9586C6793874; // Offset: 0x10 // Size: 0x01
	bool Consumable_15_B2094A1644FCC44D1EBC08B3D9578342; // Offset: 0x11 // Size: 0x01
	bool Equippable_17_D54B5E3C4807D350ED7429BF09AAB7D1; // Offset: 0x12 // Size: 0x01
};

