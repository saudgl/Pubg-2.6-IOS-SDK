//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Rifle_M416_10001.BP_Rifle_M416_10000_C
// Size: 0xbe0 // Inherited bytes: 0xbd8
struct ABP_Rifle_M416_10000_C : ABP_LobbyWeapon_C {
	// Fields
	struct ULobbyWeaponAnimList_Rifle_C* LobbyWeaponAnimList_Rifle; // Offset: 0xbd8 // Size: 0x08

	// Functions

	// Object Name: Function BP_Rifle_M416_10001.BP_Rifle_M416_10000_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)
};

