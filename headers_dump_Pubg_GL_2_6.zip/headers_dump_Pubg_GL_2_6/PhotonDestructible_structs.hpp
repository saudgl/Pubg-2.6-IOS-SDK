//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct PhotonDestructible.FSkeletalMeshNetData
// Size: 0x38 // Inherited bytes: 0x00
struct FFSkeletalMeshNetData {
	// Fields
	struct TArray<float> FragmentsHP; // Offset: 0x00 // Size: 0x10
	int ImpactFragmentIndex; // Offset: 0x10 // Size: 0x04
	struct FVector ImpactWorldPos; // Offset: 0x14 // Size: 0x0c
	struct FVector ImpactWorldDir; // Offset: 0x20 // Size: 0x0c
	float ImpulseForce; // Offset: 0x2c // Size: 0x04
	float ImpactTime; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct PhotonDestructible.FStaticMeshNetData
// Size: 0x18 // Inherited bytes: 0x00
struct FFStaticMeshNetData {
	// Fields
	struct TArray<float> FragmentsHP; // Offset: 0x00 // Size: 0x10
	float LastImpactTime; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct PhotonDestructible.PDSurfaceNetData
// Size: 0x18 // Inherited bytes: 0x00
struct FPDSurfaceNetData {
	// Fields
	struct TArray<struct FPhotonDestructibleSurfaceHitData> SurfaceHitData; // Offset: 0x00 // Size: 0x10
	int HitDataCount; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct PhotonDestructible.PhotonDestructibleSurfaceHitData
// Size: 0x18 // Inherited bytes: 0x00
struct FPhotonDestructibleSurfaceHitData {
	// Fields
	uint16_t InstanceIndex; // Offset: 0x00 // Size: 0x02
	enum class EPhotonDestructibleSurfaceHitType HitType; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x1]; // Offset: 0x03 // Size: 0x01
	int HitParam; // Offset: 0x04 // Size: 0x04
	int HitParam2; // Offset: 0x08 // Size: 0x04
	struct FVector HitPoint; // Offset: 0x0c // Size: 0x0c
};

