//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_GuideFlowCommonDataInfoTb_type.BP_STRUCT_GuideFlowCommonDataInfoTb_type
// Size: 0x40 // Inherited bytes: 0x00
struct FBP_STRUCT_GuideFlowCommonDataInfoTb_type {
	// Fields
	int dataID_0_7D56BA00677CEB1451BE4D8603803C84; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString dataName_1_3CD237004B62867C25B97B9D003D15B5; // Offset: 0x08 // Size: 0x10
	struct FString dataType_2_139E9F40252CB67925B59689003FF3E5; // Offset: 0x18 // Size: 0x10
	int defaultValue_3_004128C04DA72E3515810879001F3245; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString eventID_4_796F3C00299505E03C0740E80E43CDE4; // Offset: 0x30 // Size: 0x10
};

