//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_PakInfoTable_type.BP_STRUCT_PakInfoTable_type
// Size: 0x7c // Inherited bytes: 0x00
struct FBP_STRUCT_PakInfoTable_type {
	// Fields
	struct FString PakDesc_0_6E91B0407A6E420F2F3B970B0B197D03; // Offset: 0x00 // Size: 0x10
	int PakID_1_2787F3C01109F2833D0E5F01019B1904; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString PakName_2_2871B0C036D9F5B52F2039E30B1A97A5; // Offset: 0x18 // Size: 0x10
	struct FString IconPath_5_4AA40F004CDDD4F255A82072004E7098; // Offset: 0x28 // Size: 0x10
	int HaveReward_6_2F7F23C05893D46B3BEC13810794E624; // Offset: 0x38 // Size: 0x04
	int IsShow_7_72DD80C02601BBC33710FE7109DEF477; // Offset: 0x3c // Size: 0x04
	struct FString Videos_9_2559C4007F047F7C51C1B5670919C773; // Offset: 0x40 // Size: 0x10
	struct FString DependActorIDs_13_436BBBC03660390126BA6D9900B13DB3; // Offset: 0x50 // Size: 0x10
	int DownloadFinishTipsID_14_40FF3B0032D4842623ACE2D405B66AB4; // Offset: 0x60 // Size: 0x04
	int DownloadTipsID_15_093302C038491A270A382B4F097A3A24; // Offset: 0x64 // Size: 0x04
	struct FString JumpURL_16_2C804D400C963D8F7B18E6DA0CE28BFC; // Offset: 0x68 // Size: 0x10
	int IsUGC_17_728C70405B32D0CD14F578DA019DEF63; // Offset: 0x78 // Size: 0x04
};

