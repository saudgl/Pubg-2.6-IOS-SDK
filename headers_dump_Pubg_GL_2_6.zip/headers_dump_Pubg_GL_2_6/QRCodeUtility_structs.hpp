//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct QRCodeUtility.ZXingScanResult
// Size: 0x28 // Inherited bytes: 0x00
struct FZXingScanResult {
	// Fields
	enum class EZXingFormat Format; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString Text; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FVector2D> Points; // Offset: 0x18 // Size: 0x10
};

