//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MMKVUnreal.MMKVObject
// Size: 0x30 // Inherited bytes: 0x28
struct UMMKVObject : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function MMKVUnreal.MMKVObject.TotalSize
	// Flags: [Final|Native|Public|Const]
	uint32_t TotalSize(); // Offset: 0x102617adc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MMKVUnreal.MMKVObject.SetString
	// Flags: [Final|Native|Public]
	bool SetString(struct FString Key, struct FString Value); // Offset: 0x1026179e0 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function MMKVUnreal.MMKVObject.SetInt32
	// Flags: [Final|Native|Public]
	bool SetInt32(struct FString Key, int Value); // Offset: 0x1026178f8 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function MMKVUnreal.MMKVObject.SetErrorLogDelegate
	// Flags: [Final|Native|Static|Public]
	void SetErrorLogDelegate(DelegateProperty handler); // Offset: 0x102617870 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function MMKVUnreal.MMKVObject.SetDouble
	// Flags: [Final|Native|Public]
	bool SetDouble(struct FString Key, double Value); // Offset: 0x102617788 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function MMKVUnreal.MMKVObject.SetBuffer
	// Flags: [Final|Native|Public|HasOutParms]
	bool SetBuffer(struct FString Key, struct TArray<char>& Buffer); // Offset: 0x10261767c // Return & Params: Num(3) Size(0x21)

	// Object Name: Function MMKVUnreal.MMKVObject.SetBool
	// Flags: [Final|Native|Public]
	bool SetBool(struct FString Key, bool Value); // Offset: 0x10261758c // Return & Params: Num(3) Size(0x12)

	// Object Name: Function MMKVUnreal.MMKVObject.Remove
	// Flags: [Final|Native|Public]
	void Remove(struct FString Key); // Offset: 0x1026174f4 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction MMKVUnreal.MMKVObject.MMKVLogError__DelegateSignature
	// Flags: [Public|Delegate]
	void MMKVLogError__DelegateSignature(struct FString MapId, int errorType); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function MMKVUnreal.MMKVObject.Init
	// Flags: [Final|Native|Public]
	void Init(struct FString MMapID, struct FString RootPath); // Offset: 0x102617408 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function MMKVUnreal.MMKVObject.GetValueSize
	// Flags: [Final|Native|Public]
	uint32_t GetValueSize(struct FString Key); // Offset: 0x102617360 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function MMKVUnreal.MMKVObject.GetString
	// Flags: [Final|Native|Public|Const]
	struct FString GetString(struct FString Key); // Offset: 0x102617290 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function MMKVUnreal.MMKVObject.GetInt32
	// Flags: [Final|Native|Public|Const]
	int GetInt32(struct FString Key); // Offset: 0x1026171e8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function MMKVUnreal.MMKVObject.GetDouble
	// Flags: [Final|Native|Public|Const]
	double GetDouble(struct FString Key); // Offset: 0x102617140 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MMKVUnreal.MMKVObject.GetBuffer
	// Flags: [Final|Native|Public|Const]
	struct TArray<char> GetBuffer(struct FString Key); // Offset: 0x102617070 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function MMKVUnreal.MMKVObject.GetBool
	// Flags: [Final|Native|Public|Const]
	bool GetBool(struct FString Key); // Offset: 0x102616fc8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function MMKVUnreal.MMKVObject.GetAllKeys
	// Flags: [Final|Native|Public|Const]
	struct TMap<struct FString, bool> GetAllKeys(); // Offset: 0x102616f64 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function MMKVUnreal.MMKVObject.ContainsKey
	// Flags: [Final|Native|Public|Const]
	bool ContainsKey(struct FString Key); // Offset: 0x102616ebc // Return & Params: Num(2) Size(0x11)
};

