//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_RecommendedSystemCfg_type.BP_STRUCT_RecommendedSystemCfg_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_RecommendedSystemCfg_type {
	// Fields
	struct FString ParamName_0_347AA00063E88918284967A80F00B0C5; // Offset: 0x00 // Size: 0x10
	int Value_1_73BFE2C02701064D331815720EE21525; // Offset: 0x10 // Size: 0x04
};

