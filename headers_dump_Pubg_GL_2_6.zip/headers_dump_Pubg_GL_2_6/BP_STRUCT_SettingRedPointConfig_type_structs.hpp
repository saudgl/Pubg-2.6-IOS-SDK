//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SettingRedPointConfig_type.BP_STRUCT_SettingRedPointConfig_type
// Size: 0x2c // Inherited bytes: 0x00
struct FBP_STRUCT_SettingRedPointConfig_type {
	// Fields
	int ID_0_06917F004C4564346198F4370B9E4FE4; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Key_1_1C0D860066C4AE720A1C3C1809E50279; // Offset: 0x08 // Size: 0x10
	struct FString Name_2_3127FC0061DAD35C6C1B6F630E507DA5; // Offset: 0x18 // Size: 0x10
	int Tab_4_0AC1C1806018E11E0A1DE7D209E4E9C2; // Offset: 0x28 // Size: 0x04
};

