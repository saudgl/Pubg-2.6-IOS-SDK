//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_FeaturesItems_type.BP_STRUCT_FeaturesItems_type
// Size: 0x18 // Inherited bytes: 0x00
struct FBP_STRUCT_FeaturesItems_type {
	// Fields
	int ID_4_70B6D9000F7C4138010820A90EFCE7B4; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Features_6_6384C58014BE35983FAD42C605772F63; // Offset: 0x08 // Size: 0x10
};

