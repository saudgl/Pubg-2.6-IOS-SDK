//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum PixUI.EPXKeyboardTypes
enum class EPXKeyboardTypes : uint8 {
	em_px_key_board_default = 0,
	em_px_key_board_number = 1,
	em_px_key_board_password = 2,
	em_px_key_board_count = 3,
	em_px_key_board_MAX = 4
};

// Object Name: Enum PixUI.EPXViewEvent
enum class EPXViewEvent : uint8 {
	em_px_event_moveby = 0,
	em_px_event_moveto = 1,
	em_px_event_resizeby = 2,
	em_px_event_resizeto = 3,
	em_px_event_scrollby = 4,
	em_px_event_scrollto = 5,
	em_px_event_count = 6,
	em_px_event_MAX = 7
};

// Object Name: Enum PixUI.EPXLogLevels
enum class EPXLogLevels : uint8 {
	em_px_log_level_log = 0,
	em_px_log_level_warning = 1,
	em_px_log_level_error = 2,
	em_px_log_level_count = 3,
	em_px_log_level_MAX = 4
};

// Object Name: Enum PixUI.EPXLogTypes
enum class EPXLogTypes : uint8 {
	em_px_log_type_core = 0,
	em_px_log_type_plugin = 1,
	em_px_log_type_trace = 2,
	em_px_log_type_script = 3,
	em_px_log_type_count = 4,
	em_px_log_type_MAX = 5
};

