//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum WebCameraFeed.EVideoPixelFormat
enum class EVideoPixelFormat : uint8 {
	GrayScale = 0,
	Rgb = 1,
	Rgba = 2,
	EVideoPixelFormat_MAX = 3
};

