//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass WeaponAvatarComp_BP.WeaponAvatarComp_BP_C
// Size: 0x8b0 // Inherited bytes: 0x8b0
struct UWeaponAvatarComp_BP_C : UWeaponAvatarComponent {
};

