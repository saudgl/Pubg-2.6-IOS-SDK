//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MobilePatchingUtils.MobileInstalledContent
// Size: 0x48 // Inherited bytes: 0x28
struct UMobileInstalledContent : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 // Size: 0x20

	// Functions

	// Object Name: Function MobilePatchingUtils.MobileInstalledContent.Mount
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Mount(int PakOrder, struct FString MountPoint); // Offset: 0x101f5b508 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function MobilePatchingUtils.MobileInstalledContent.GetInstalledContentSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetInstalledContentSize(); // Offset: 0x101f5b4d4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MobilePatchingUtils.MobileInstalledContent.GetDiskFreeSpace
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetDiskFreeSpace(); // Offset: 0x101f5b4a0 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class MobilePatchingUtils.MobilePendingContent
// Size: 0x88 // Inherited bytes: 0x48
struct UMobilePendingContent : UMobileInstalledContent {
	// Fields
	char pad_0x48[0x40]; // Offset: 0x48 // Size: 0x40

	// Functions

	// Object Name: Function MobilePatchingUtils.MobilePendingContent.StartInstall
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartInstall(DelegateProperty OnSucceeded, DelegateProperty OnFailed); // Offset: 0x101f5b930 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function MobilePatchingUtils.MobilePendingContent.GetTotalDownloadedSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetTotalDownloadedSize(); // Offset: 0x101f5b8fc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MobilePatchingUtils.MobilePendingContent.GetRequiredDiskSpace
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetRequiredDiskSpace(); // Offset: 0x101f5b8c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MobilePatchingUtils.MobilePendingContent.GetInstallProgress
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetInstallProgress(); // Offset: 0x101f5b894 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MobilePatchingUtils.MobilePendingContent.GetDownloadStatusText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct FText GetDownloadStatusText(); // Offset: 0x101f5b830 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function MobilePatchingUtils.MobilePendingContent.GetDownloadSpeed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetDownloadSpeed(); // Offset: 0x101f5b7fc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MobilePatchingUtils.MobilePendingContent.GetDownloadSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetDownloadSize(); // Offset: 0x101f5b7c8 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class MobilePatchingUtils.MobilePatchingLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UMobilePatchingLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function MobilePatchingUtils.MobilePatchingLibrary.RequestContent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RequestContent(struct FString RemoteManifestURL, struct FString CloudURL, struct FString InstallDirectory, DelegateProperty OnSucceeded, DelegateProperty OnFailed); // Offset: 0x101f5beb8 // Return & Params: Num(5) Size(0x50)

	// Object Name: Function MobilePatchingUtils.MobilePatchingLibrary.HasActiveWiFiConnection
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool HasActiveWiFiConnection(); // Offset: 0x101f5be84 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MobilePatchingUtils.MobilePatchingLibrary.GetSupportedPlatformNames
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct TArray<struct FString> GetSupportedPlatformNames(); // Offset: 0x101f5be20 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function MobilePatchingUtils.MobilePatchingLibrary.GetInstalledContent
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UMobileInstalledContent* GetInstalledContent(struct FString InstallDirectory); // Offset: 0x101f5bd88 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MobilePatchingUtils.MobilePatchingLibrary.GetActiveDeviceProfileName
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString GetActiveDeviceProfileName(); // Offset: 0x101f5bd24 // Return & Params: Num(1) Size(0x10)
};

