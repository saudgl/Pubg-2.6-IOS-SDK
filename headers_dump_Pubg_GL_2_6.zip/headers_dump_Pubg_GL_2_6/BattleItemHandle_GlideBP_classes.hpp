//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BattleItemHandle_GlideBP.BattleItemHandle_GlideBP_C
// Size: 0xb48 // Inherited bytes: 0xb32
struct UBattleItemHandle_GlideBP_C : UBattleItemHandle_AvatarBP_C {
	// Fields
	char pad_0xB32[0x6]; // Offset: 0xb32 // Size: 0x06
	struct UAnimMontage* startAimn; // Offset: 0xb38 // Size: 0x08
	struct UAnimSequenceBase* IdleAnim; // Offset: 0xb40 // Size: 0x08

	// Functions

	// Object Name: Function BattleItemHandle_GlideBP.BattleItemHandle_GlideBP_C.NewFunction_1
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void NewFunction_1(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)
};

