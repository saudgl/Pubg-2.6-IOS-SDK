//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SuitDyePartParam_type.BP_STRUCT_SuitDyePartParam_type
// Size: 0x50 // Inherited bytes: 0x00
struct FBP_STRUCT_SuitDyePartParam_type {
	// Fields
	int AvatarSlotID_0_74ADBCC01F8D9CB30A170F2A0DC2F3E4; // Offset: 0x00 // Size: 0x04
	int ID_1_71EEDC8072B10144186DBCF30F11BA74; // Offset: 0x04 // Size: 0x04
	int MatSlotID_2_6699CD804E6B52180A143195089AD1A4; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString ParamName_3_6AA0B5C04D4DED6D71357326097BFC45; // Offset: 0x10 // Size: 0x10
	struct FString HighLightParamName_4_5426B3C0254C6ED15DAE8BB90DFF2025; // Offset: 0x20 // Size: 0x10
	struct FString SwitchParamName_5_2CDB3240626C80ED717FBED809D42285; // Offset: 0x30 // Size: 0x10
	struct FString CloseMaskParamName_6_458D164037754B29126E371201CA3A85; // Offset: 0x40 // Size: 0x10
};

