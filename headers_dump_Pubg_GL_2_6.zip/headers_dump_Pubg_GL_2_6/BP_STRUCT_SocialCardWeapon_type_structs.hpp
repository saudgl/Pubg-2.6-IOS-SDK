//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SocialCardWeapon_type.BP_STRUCT_SocialCardWeapon_type
// Size: 0x1c // Inherited bytes: 0x00
struct FBP_STRUCT_SocialCardWeapon_type {
	// Fields
	int ID_0_6777388006B78AD058944FA80D0F28C4; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Weapon_1_0C9C2FC05459B0CB4FBE7CE909C68A7E; // Offset: 0x08 // Size: 0x10
	int Type_2_2AB09DC045017F3B3B5902840F29BD65; // Offset: 0x18 // Size: 0x04
};

