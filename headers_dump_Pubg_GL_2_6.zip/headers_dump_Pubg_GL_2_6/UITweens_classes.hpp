//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class UITweens.TweenManager
// Size: 0x50 // Inherited bytes: 0x28
struct UTweenManager : UObject {
	// Fields
	char pad_0x28[0x28]; // Offset: 0x28 // Size: 0x28

	// Functions

	// Object Name: Function UITweens.TweenManager.TweenSize
	// Flags: [Final|Native|Public|HasDefaults]
	void TweenSize(struct UWidget* Widget, struct FVector2D from, struct FVector2D to, float Timespan, int Type); // Offset: 0x1026d008c // Return & Params: Num(5) Size(0x20)

	// Object Name: Function UITweens.TweenManager.TweenPosition
	// Flags: [Final|Native|Public|HasDefaults]
	void TweenPosition(struct UWidget* Widget, struct FVector2D from, struct FVector2D to, float Timespan, int Type); // Offset: 0x1026cff28 // Return & Params: Num(5) Size(0x20)

	// Object Name: Function UITweens.TweenManager.TweenAlpha
	// Flags: [Final|Native|Public]
	void TweenAlpha(struct UImage* Widget, float from, float to, float Timespan, int Type); // Offset: 0x1026cfdc0 // Return & Params: Num(5) Size(0x18)

	// Object Name: Function UITweens.TweenManager.Tick
	// Flags: [Final|Native|Public]
	void Tick(float DeltaTime); // Offset: 0x1026cfd3c // Return & Params: Num(1) Size(0x4)
};

