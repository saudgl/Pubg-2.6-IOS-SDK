//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Login_GameplayName_UIBP.Login_GameplayName_UIBP_C
// Size: 0x298 // Inherited bytes: 0x260
struct ULogin_GameplayName_UIBP_C : UUserWidget {
	// Fields
	struct UImage* Image_2; // Offset: 0x260 // Size: 0x08
	struct UImage* Image_bg; // Offset: 0x268 // Size: 0x08
	struct UTextBlock* TextBlock_Map; // Offset: 0x270 // Size: 0x08
	struct UUGC_Trans_Item_UIBP_C* UGC_Trans_Item_UIBP; // Offset: 0x278 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_2; // Offset: 0x280 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_3; // Offset: 0x288 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_NumberPeople; // Offset: 0x290 // Size: 0x08
};

