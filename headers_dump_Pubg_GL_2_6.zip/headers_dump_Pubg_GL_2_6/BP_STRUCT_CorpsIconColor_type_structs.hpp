//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_CorpsIconColor_type.BP_STRUCT_CorpsIconColor_type
// Size: 0x20 // Inherited bytes: 0x00
struct FBP_STRUCT_CorpsIconColor_type {
	// Fields
	int ID_0_52760C80425177D07DAE1F650BD163E4; // Offset: 0x00 // Size: 0x04
	int GNum_1_373F670000ACE8EC1AE46FEE01639E6D; // Offset: 0x04 // Size: 0x04
	int RNum_2_6CDA49C06AA821FF1ACB3BEC01626E6D; // Offset: 0x08 // Size: 0x04
	int BNum_3_591045C044DDA06F1AEA692201636E6D; // Offset: 0x0c // Size: 0x04
	struct FString Color_4_02A7A9005D76F20C79AF79E8063C0072; // Offset: 0x10 // Size: 0x10
};

