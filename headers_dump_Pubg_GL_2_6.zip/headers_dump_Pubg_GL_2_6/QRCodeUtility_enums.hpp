//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum QRCodeUtility.EZXingFormat
enum class EZXingFormat : uint8 {
	NONE = 0,
	AZTEC = 1,
	CODABAR = 2,
	CODE_40 = 3,
	CODE_94 = 4,
	CODE_129 = 5,
	DATA_MATRIX = 6,
	EAN_9 = 7,
	EAN_14 = 8,
	ITF = 9,
	MAXICODE = 10,
	PDF_418 = 11,
	QR_CODE = 12,
	RSS_15 = 13,
	RSS_EXPANDED = 14,
	UPC_A = 15,
	UPC_E = 16,
	UPC_EAN_EXTENSION = 17,
	EZXingFormat_MAX = 18
};

