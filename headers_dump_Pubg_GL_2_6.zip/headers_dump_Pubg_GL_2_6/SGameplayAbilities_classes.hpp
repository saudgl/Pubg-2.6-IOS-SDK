//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class SGameplayAbilities.AbilityTask_Tick_WaitAbilityActivate
// Size: 0x130 // Inherited bytes: 0x130
struct UAbilityTask_Tick_WaitAbilityActivate : UAbilityTask_WaitAbilityActivate {
	// Functions

	// Object Name: Function SGameplayAbilities.AbilityTask_Tick_WaitAbilityActivate.WaitForAbilityActivateWithTagRequirementsInTick
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_Tick_WaitAbilityActivate* WaitForAbilityActivateWithTagRequirementsInTick(struct UGameplayAbility* OwningAbility, struct FGameplayTagRequirements TagRequirements, bool IncludeTriggeredAbilities, bool TriggerOnce); // Offset: 0x1021bf314 // Return & Params: Num(5) Size(0x58)

	// Object Name: Function SGameplayAbilities.AbilityTask_Tick_WaitAbilityActivate.WaitForAbilityActivateInTick_Query
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_Tick_WaitAbilityActivate* WaitForAbilityActivateInTick_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTagQuery Query, bool IncludeTriggeredAbilities, bool TriggerOnce); // Offset: 0x1021bf17c // Return & Params: Num(5) Size(0x60)

	// Object Name: Function SGameplayAbilities.AbilityTask_Tick_WaitAbilityActivate.WaitForAbilityActivateInTick
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_Tick_WaitAbilityActivate* WaitForAbilityActivateInTick(struct UGameplayAbility* OwningAbility, struct FGameplayTag WithTag, struct FGameplayTag WithoutTag, bool IncludeTriggeredAbilities, bool TriggerOnce); // Offset: 0x1021beffc // Return & Params: Num(6) Size(0x28)
};

// Object Name: Class SGameplayAbilities.SAbilitySystemBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct USAbilitySystemBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function SGameplayAbilities.SAbilitySystemBlueprintLibrary.RequestGameplayTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGameplayTag RequestGameplayTag(struct FString InTagName, bool ErrorIfNotFound); // Offset: 0x1021bf7e4 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function SGameplayAbilities.SAbilitySystemBlueprintLibrary.CreateGameplayTagContainer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FGameplayTagContainer CreateGameplayTagContainer(struct TArray<struct FGameplayTag>& SourceTags); // Offset: 0x1021bf714 // Return & Params: Num(2) Size(0x30)
};

// Object Name: Class SGameplayAbilities.SAbilitySystemComponent
// Size: 0x11b8 // Inherited bytes: 0x10d8
struct USAbilitySystemComponent : UAbilitySystemComponent {
	// Fields
	char pad_0x10D8[0x60]; // Offset: 0x10d8 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x1138 // Size: 0x10
	struct TArray<struct UGameplayAbility*> PreloadedAbilities; // Offset: 0x1148 // Size: 0x10
	struct TArray<struct FGameplayAbilitySpecHandle> PreloadedAbilityHandles; // Offset: 0x1158 // Size: 0x10
	struct FLuaNetSerialization LuaNetSerialization; // Offset: 0x1168 // Size: 0x50

	// Functions

	// Object Name: Function SGameplayAbilities.SAbilitySystemComponent.TryActivateAbilitiesByTagString
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool TryActivateAbilitiesByTagString(struct FString AbilityTag, bool bAllowRemoteActivation); // Offset: 0x1021bfbc0 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function SGameplayAbilities.SAbilitySystemComponent.ReloadAbilities
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReloadAbilities(); // Offset: 0x1021bfbac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SGameplayAbilities.SAbilitySystemComponent.GiveAbilityByClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FGameplayAbilitySpecHandle GiveAbilityByClass(struct UGameplayAbility* AbilityClass); // Offset: 0x1021bfb20 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function SGameplayAbilities.SAbilitySystemComponent.CancelAbilitiesByTagString
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelAbilitiesByTagString(struct FString AbilityTag); // Offset: 0x1021bfa64 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class SGameplayAbilities.SGameplayAbility
// Size: 0x4b0 // Inherited bytes: 0x440
struct USGameplayAbility : UGameplayAbility {
	// Fields
	char pad_0x440[0x60]; // Offset: 0x440 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x4a0 // Size: 0x10

	// Functions

	// Object Name: Function SGameplayAbilities.SGameplayAbility.K2_OnGiveAbility
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void K2_OnGiveAbility(struct FGameplayAbilityActorInfo& ActorInfo, struct FGameplayAbilitySpec& Spec); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0xb8)

	// Object Name: Function SGameplayAbilities.SGameplayAbility.AddTargetRequiredTag
	// Flags: [Final|Native|Public]
	void AddTargetRequiredTag(struct FString TagName); // Offset: 0x1021c06cc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SGameplayAbilities.SGameplayAbility.AddTargetBlockedTag
	// Flags: [Final|Native|Public]
	void AddTargetBlockedTag(struct FString TagName); // Offset: 0x1021c0610 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SGameplayAbilities.SGameplayAbility.AddSourceRequiredTag
	// Flags: [Final|Native|Public]
	void AddSourceRequiredTag(struct FString TagName); // Offset: 0x1021c0554 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SGameplayAbilities.SGameplayAbility.AddSourceBlockedTag
	// Flags: [Final|Native|Public]
	void AddSourceBlockedTag(struct FString TagName); // Offset: 0x1021c0498 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SGameplayAbilities.SGameplayAbility.AddCancelAbilityTag
	// Flags: [Final|Native|Public]
	void AddCancelAbilityTag(struct FString TagName); // Offset: 0x1021c03dc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SGameplayAbilities.SGameplayAbility.AddBlockAbilityTag
	// Flags: [Final|Native|Public]
	void AddBlockAbilityTag(struct FString TagName); // Offset: 0x1021c0320 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SGameplayAbilities.SGameplayAbility.AddActivationRequiredTag
	// Flags: [Final|Native|Public]
	void AddActivationRequiredTag(struct FString TagName); // Offset: 0x1021c0264 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SGameplayAbilities.SGameplayAbility.AddActivationOwnedTag
	// Flags: [Final|Native|Public]
	void AddActivationOwnedTag(struct FString TagName); // Offset: 0x1021c01a8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SGameplayAbilities.SGameplayAbility.AddActivationBlockedTag
	// Flags: [Final|Native|Public]
	void AddActivationBlockedTag(struct FString TagName); // Offset: 0x1021c00ec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SGameplayAbilities.SGameplayAbility.AddAbilityTag
	// Flags: [Final|Native|Public]
	void AddAbilityTag(struct FString TagName); // Offset: 0x1021c0030 // Return & Params: Num(1) Size(0x10)
};

