//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UAnimationBudgetBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters
	// Flags: [Final|Native|Static|Private|HasOutParms|BlueprintCallable]
	void SetAnimationBudgetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters& InParameters); // Offset: 0x102108034 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget
	// Flags: [Final|Native|Static|Private|BlueprintCallable]
	void EnableAnimationBudget(struct UObject* WorldContextObject, bool bEnabled); // Offset: 0x102107f7c // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted
// Size: 0xe80 // Inherited bytes: 0xe60
struct USkeletalMeshComponentBudgeted : USkeletalMeshComponent {
	// Fields
	char pad_0xE60[0x18]; // Offset: 0xe60 // Size: 0x18
	char bAutoRegisterWithBudgetAllocator : 1; // Offset: 0xe78 // Size: 0x01
	char bAutoCalculateSignificance : 1; // Offset: 0xe78 // Size: 0x01
	char bShouldUseActorRenderedFlag : 1; // Offset: 0xe78 // Size: 0x01
	char pad_0xE78_3 : 5; // Offset: 0xe78 // Size: 0x01
	char pad_0xE79[0x7]; // Offset: 0xe79 // Size: 0x07

	// Functions

	// Object Name: Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator); // Offset: 0x102108308 // Return & Params: Num(1) Size(0x1)
};

