//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_ParamConfig_type.BP_STRUCT_ParamConfig_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_ParamConfig_type {
	// Fields
	struct FString ParamName_0_3E5093C0622417BF51FDE5CD07CE52A5; // Offset: 0x00 // Size: 0x10
	int ParamValue_1_11E112C00B831E5D3BCE331C0CED2AC5; // Offset: 0x10 // Size: 0x04
};

