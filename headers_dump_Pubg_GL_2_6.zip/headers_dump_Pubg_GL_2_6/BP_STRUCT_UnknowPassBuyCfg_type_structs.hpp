//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_UnknowPassBuyCfg_type.BP_STRUCT_UnknowPassBuyCfg_type
// Size: 0x60 // Inherited bytes: 0x00
struct FBP_STRUCT_UnknowPassBuyCfg_type {
	// Fields
	struct FString Desc2_0_67184800080A6DB06A7EAC820F5D4182; // Offset: 0x00 // Size: 0x10
	struct FString Desc1_1_671747C0080A6DAF6A7EAC810F5D4181; // Offset: 0x10 // Size: 0x10
	int ID_2_67757F0013C6DC1C495D34BC088EF5A4; // Offset: 0x20 // Size: 0x04
	int BuyItemId_3_40A836C02092165B4D6E49EC06E5FFB4; // Offset: 0x24 // Size: 0x04
	int buyType_4_7787F84001767BCD222963590E466F15; // Offset: 0x28 // Size: 0x04
	int ShowItem2_5_5880B4407E043CB101B132840E6FE672; // Offset: 0x2c // Size: 0x04
	int ShowItem1_6_587FB4007E043CB001B132850E6FE671; // Offset: 0x30 // Size: 0x04
	int BuyItem2Id_7_552003403C2CB6630C4AA70F0E5FE294; // Offset: 0x34 // Size: 0x04
	int PassType_8_506C2A007989DA460C18BC5E00265475; // Offset: 0x38 // Size: 0x04
	int IsExtra_9_29876BC02D0F514F4413ED8007F414E1; // Offset: 0x3c // Size: 0x04
	int isExperience_12_7AD2F4C072621CFB259ADF0804F10505; // Offset: 0x40 // Size: 0x04
	int AwardItemCount3_13_6B26AA402A77007373288FDD020EF083; // Offset: 0x44 // Size: 0x04
	int AwardItemID3_14_7843AB4051561B497DA13145055F1BF3; // Offset: 0x48 // Size: 0x04
	int Price1_15_176AC4C017D15E557CA2F04604007771; // Offset: 0x4c // Size: 0x04
	int Price2_16_176BC50017D15E567CA2F04704007772; // Offset: 0x50 // Size: 0x04
	int PriceDiscount1_17_73ED37005219DF7607D191A409F1EA71; // Offset: 0x54 // Size: 0x04
	int PriceDiscount2_18_73EE37405219DF7707D191A709F1EA72; // Offset: 0x58 // Size: 0x04
	int TicketType_20_742A3D40629064850F5055470F3D7745; // Offset: 0x5c // Size: 0x04
};

