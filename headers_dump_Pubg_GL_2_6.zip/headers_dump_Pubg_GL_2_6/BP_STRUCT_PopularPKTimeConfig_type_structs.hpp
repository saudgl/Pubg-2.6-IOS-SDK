//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_PopularPKTimeConfig_type.BP_STRUCT_PopularPKTimeConfig_type
// Size: 0xb4 // Inherited bytes: 0x00
struct FBP_STRUCT_PopularPKTimeConfig_type {
	// Fields
	struct FString AppIDs_0_45B1A680058DC392719EC4CD0720C3B3; // Offset: 0x00 // Size: 0x10
	struct FString LvReward_1_6863280005972A7064A311C90C02D014; // Offset: 0x10 // Size: 0x10
	struct FString PKEndTime_2_42D66E8036B812E23F84C7DF04A9C2B5; // Offset: 0x20 // Size: 0x10
	struct FString PKStartTime_3_0E70AC406A3BF51D46CBC51408F6DE75; // Offset: 0x30 // Size: 0x10
	struct FString RankReward_4_445C5A806D1BE0C27DE58A840E8AF954; // Offset: 0x40 // Size: 0x10
	int SeasonID_5_14F93BC049CDB0393D1153900C0864E4; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct FString SignEndTime_6_0B42EC00630B52C247E8A3570C2A2AF5; // Offset: 0x58 // Size: 0x10
	struct FString SignStartTime_7_4B6FA9C02E67671D79E5D1720B1F76F5; // Offset: 0x68 // Size: 0x10
	struct FString Version_8_63F537C00443458D4B166CD306B1803E; // Offset: 0x78 // Size: 0x10
	struct FString ActEndTime_9_19786DC032EEF1750D323A97064E7335; // Offset: 0x88 // Size: 0x10
	struct FString ActStartTime_10_11CB6B804E6ED3AE172815ED0F44BC95; // Offset: 0x98 // Size: 0x10
	int FirstRoundID_12_388FE5804493D92C67E73B12001D5C74; // Offset: 0xa8 // Size: 0x04
	int LastRoundID_13_0DDA888027C410900059E20D09E4BAA4; // Offset: 0xac // Size: 0x04
	int LocalPushID_14_3BDB6440530290D524271B2A01F5BD74; // Offset: 0xb0 // Size: 0x04
};

