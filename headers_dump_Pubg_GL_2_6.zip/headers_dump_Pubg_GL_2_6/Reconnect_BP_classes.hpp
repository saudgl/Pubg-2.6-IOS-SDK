//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Reconnect_BP.Reconnect_BP_C
// Size: 0x453 // Inherited bytes: 0x418
struct UReconnect_BP_C : UUAEUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x418 // Size: 0x08
	struct UReconnect_UIBP_C* Reconnect_UIBP; // Offset: 0x420 // Size: 0x08
	struct UTextBlock* TextNumber; // Offset: 0x428 // Size: 0x08
	struct UTextBlock* TextInfo; // Offset: 0x430 // Size: 0x08
	struct UHorizontalBox* BoxText; // Offset: 0x438 // Size: 0x08
	bool isShowText; // Offset: 0x440 // Size: 0x01
	char pad_0x441[0x3]; // Offset: 0x441 // Size: 0x03
	int StartTime; // Offset: 0x444 // Size: 0x04
	float lastTickTime; // Offset: 0x448 // Size: 0x04
	float curTickTIme; // Offset: 0x44c // Size: 0x04
	bool canCrtlFromLua; // Offset: 0x450 // Size: 0x01
	bool BIsShowAnim; // Offset: 0x451 // Size: 0x01
	bool bImmediatelyShow; // Offset: 0x452 // Size: 0x01

	// Functions

	// Object Name: Function Reconnect_BP.Reconnect_BP_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Reconnect_BP.Reconnect_BP_C.ExecuteUbergraph_Reconnect_BP
	// Flags: [None]
	void ExecuteUbergraph_Reconnect_BP(int EntryPoint); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)
};

