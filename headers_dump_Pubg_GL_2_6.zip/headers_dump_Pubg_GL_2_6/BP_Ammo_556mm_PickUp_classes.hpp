//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Ammo_556mm_PickUp.BP_Ammo_556mm_Pickup_C
// Size: 0x858 // Inherited bytes: 0x850
struct ABP_Ammo_556mm_Pickup_C : APickUpWrapperActor {
	// Fields
	struct UStaticMeshComponent* SM_Ammo_556mm; // Offset: 0x850 // Size: 0x08

	// Functions

	// Object Name: Function BP_Ammo_556mm_PickUp.BP_Ammo_556mm_Pickup_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)
};

