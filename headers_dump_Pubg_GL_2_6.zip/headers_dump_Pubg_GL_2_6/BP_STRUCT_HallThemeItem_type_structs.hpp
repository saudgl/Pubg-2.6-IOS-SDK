//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_HallThemeItem_type.BP_STRUCT_HallThemeItem_type
// Size: 0x218 // Inherited bytes: 0x00
struct FBP_STRUCT_HallThemeItem_type {
	// Fields
	int itemId_0_05AB9D40399D42531091E2D207055864; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString skinLevelName_1_559291C07BED8CD91D86A5EC06628D85; // Offset: 0x08 // Size: 0x10
	struct FString skinId_2_21CE1EC00F0DEDC7628895A907AE1B64; // Offset: 0x18 // Size: 0x10
	struct FString vehicleScale_3_18B1B84057E5C0996932DCA5056D8235; // Offset: 0x28 // Size: 0x10
	struct FString vehicleRotation_4_531D72400EAEDF437EA1408A07C9FA8E; // Offset: 0x38 // Size: 0x10
	struct FString vehiclePosition_5_4614D38008FDCBAA5E3100C90801FA6E; // Offset: 0x48 // Size: 0x10
	struct FString footScale_24_4BAD2E4043BD55FB478A4D300900FB95; // Offset: 0x58 // Size: 0x10
	struct FString footPosition_25_1A7F498024C4CB9079DDF298005B3F5E; // Offset: 0x68 // Size: 0x10
	struct FString wheel3Rotation_26_2FB2AC40356A0C6333D8BB1707EAC13E; // Offset: 0x78 // Size: 0x10
	struct FString wheel2Rotation_27_65D2AC006A4A710226C2155D07EAD03E; // Offset: 0x88 // Size: 0x10
	struct FString footRotation_28_2787E8403E2686FF58BC4E170073407E; // Offset: 0x98 // Size: 0x10
	struct FString boatScale_29_31B9A9C03C7F6B3564CF8B540700FF85; // Offset: 0xa8 // Size: 0x10
	struct FString motoBoatRotation_30_04D46B80758344F43D3EF9A70C8A70AE; // Offset: 0xb8 // Size: 0x10
	struct FString motoBoatPosition_31_77CBCCC07F3D3A251A0D88AC0CC2704E; // Offset: 0xc8 // Size: 0x10
	struct FString snowMotoPosition_32_387BF50062B2919E27D1FD3B0531B75E; // Offset: 0xd8 // Size: 0x10
	struct FString motoBoatScale_33_138291803415844629D6B7050C0F3605; // Offset: 0xe8 // Size: 0x10
	struct FString snowMotoRotation_34_458493C058F89C6D2ABB9C2F0519B87E; // Offset: 0xf8 // Size: 0x10
	struct FString boatRotation_35_71A323C047E1D14566F9E3840032E07E; // Offset: 0x108 // Size: 0x10
	struct FString snowMotoScale_36_5AC319C01C0294ED38E9CF4C0180AD35; // Offset: 0x118 // Size: 0x10
	struct FString wheel2Position_37_58CA0D4014EB11633925055507E2D09E; // Offset: 0x128 // Size: 0x10
	struct FString wheel3Position_38_22AA0D80600AACC45AD80A9507E2C19E; // Offset: 0x138 // Size: 0x10
	struct FString boatPosition_39_649A85002E8015D67CB18E9E001ADF5E; // Offset: 0x148 // Size: 0x10
	struct FString wheel3Scale_40_4D3DF24024C2CE271C4B56EF06F48405; // Offset: 0x158 // Size: 0x10
	struct FString wheel2Scale_41_598992005DA8E7D86273D45906048405; // Offset: 0x168 // Size: 0x10
	struct FString WingmanPosition_42_414A2FC06C5C4E2B488CA8390DDA92DE; // Offset: 0x178 // Size: 0x10
	struct FString WingmanRotation_43_4E52CE80720D61C4362DADC40DF292FE; // Offset: 0x188 // Size: 0x10
	struct FString WingmanScale_44_6E85748036070D9208224AC603E82385; // Offset: 0x198 // Size: 0x10
	struct FString Path_45_5E37C9804E67E12859DF6CDD09956758; // Offset: 0x1a8 // Size: 0x10
	struct FString TankPosition_46_2FBD9F006D30F70E2613FE950349665E; // Offset: 0x1b8 // Size: 0x10
	struct FString TankRotation_47_3CC63DC00692B27D2E8180200301677E; // Offset: 0x1c8 // Size: 0x10
	struct FString TankScale_48_1FA3C3C079A7AFFD7F9DACF20C90CEB5; // Offset: 0x1d8 // Size: 0x10
	struct FString ByciclePosition_49_4B11CA4049F810B536A4B1570101CD2E; // Offset: 0x1e8 // Size: 0x10
	struct FString BycicleRotation_50_581A69004FA9244E526FC4D000C9CDCE; // Offset: 0x1f8 // Size: 0x10
	struct FString BycicleScale_51_2D7CCF0038DB2CCC1E1BA6860639F235; // Offset: 0x208 // Size: 0x10
};

