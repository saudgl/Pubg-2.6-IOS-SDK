//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Creative.CreativeAbilitySystemComponent
// Size: 0x1260 // Inherited bytes: 0x11b8
struct UCreativeAbilitySystemComponent : USAbilitySystemComponent {
	// Fields
	char pad_0x11B8[0x38]; // Offset: 0x11b8 // Size: 0x38
	float BuildDistance; // Offset: 0x11f0 // Size: 0x04
	float LandOnOffsetZ; // Offset: 0x11f4 // Size: 0x04
	struct TArray<struct AActor*> GetLocationActorsToIgnore; // Offset: 0x11f8 // Size: 0x10
	float LandHitPointZ; // Offset: 0x1208 // Size: 0x04
	float WaterHeight; // Offset: 0x120c // Size: 0x04
	char pad_0x1210[0xc]; // Offset: 0x1210 // Size: 0x0c
	bool bOpenLandPosCheckDebug; // Offset: 0x121c // Size: 0x01
	bool bSnapTransValid; // Offset: 0x121d // Size: 0x01
	bool bSnapGridEnable; // Offset: 0x121e // Size: 0x01
	bool bForceLandOnGround; // Offset: 0x121f // Size: 0x01
	struct FRotator BuildingRotation; // Offset: 0x1220 // Size: 0x0c
	struct FRotator RelativeRotation; // Offset: 0x122c // Size: 0x0c
	struct FVector RelativeLocation; // Offset: 0x1238 // Size: 0x0c
	struct FVector BuildingScale; // Offset: 0x1244 // Size: 0x0c
	struct FVector RelativeScale; // Offset: 0x1250 // Size: 0x0c
	char pad_0x125C[0x4]; // Offset: 0x125c // Size: 0x04

	// Functions

	// Object Name: Function Creative.CreativeAbilitySystemComponent.UpdateGhostBuildingTransform
	// Flags: [Final|Native|Private]
	void UpdateGhostBuildingTransform(); // Offset: 0x10228de30 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.SetSnapTargetTransform
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	void SetSnapTargetTransform(struct FTransform& SnapTargetTransform); // Offset: 0x10228dd8c // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.SetLuaGhostBuildingTransformScale
	// Flags: [Event|Public|BlueprintEvent]
	void SetLuaGhostBuildingTransformScale(float X, float Y, float Z); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.SetLuaGhostBuildingTransformRotation
	// Flags: [Event|Public|BlueprintEvent]
	void SetLuaGhostBuildingTransformRotation(float Roll, float Yaw, float Pitch); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.SetLuaGhostBuildingTransformLocation
	// Flags: [Event|Public|BlueprintEvent]
	void SetLuaGhostBuildingTransformLocation(float X, float Y, float Z); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.ReceiveGetSnapTargetTransform
	// Flags: [Event|Public|BlueprintEvent]
	bool ReceiveGetSnapTargetTransform(); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.GetSnappedLocAxis
	// Flags: [Event|Public|BlueprintEvent]
	float GetSnappedLocAxis(float Value); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.GetSetupBuildingID
	// Flags: [Event|Public|BlueprintEvent]
	int GetSetupBuildingID(); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.GetGhostBuildingTransform
	// Flags: [Final|Native|Public|HasDefaults]
	struct FTransform GetGhostBuildingTransform(); // Offset: 0x10228dd44 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.GetBuildingInstanceID
	// Flags: [Event|Public|BlueprintEvent]
	struct FString GetBuildingInstanceID(); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.GetBuildDistance
	// Flags: [Event|Public|BlueprintEvent]
	float GetBuildDistance(); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Creative.CreativeModeActorInteractionComponent
// Size: 0x228 // Inherited bytes: 0x1d8
struct UCreativeModeActorInteractionComponent : ULuaActorComponent {
	// Fields
	bool bCrossHairCheckEnabled; // Offset: 0x1d1 // Size: 0x01
	float CrossHairCheckCD; // Offset: 0x1d4 // Size: 0x04
	bool bSectorCheckEnabled; // Offset: 0x1d8 // Size: 0x01
	float SectorCheckCD; // Offset: 0x1dc // Size: 0x04
	bool bTransformCrossHairCheckEnabled; // Offset: 0x1e0 // Size: 0x01
	char pad_0x1E3[0x1]; // Offset: 0x1e3 // Size: 0x01
	float TransformCrossHairCheckCD; // Offset: 0x1e4 // Size: 0x04
	char pad_0x1E8[0x40]; // Offset: 0x1e8 // Size: 0x40

	// Functions

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.SortCanEditParamsObjs
	// Flags: [Event|Protected|BlueprintEvent]
	void SortCanEditParamsObjs(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.SetCrossHairTransformObjInstanceID
	// Flags: [Event|Protected|BlueprintEvent]
	void SetCrossHairTransformObjInstanceID(struct FString InstanceID); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.SetCrossHairSelectedObjInstanceID
	// Flags: [Event|Protected|BlueprintEvent]
	void SetCrossHairSelectedObjInstanceID(struct FString InstanceID); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.GetSectorCheckIntervalCfg
	// Flags: [Event|Protected|BlueprintEvent]
	float GetSectorCheckIntervalCfg(); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.GetSectorCheckDistance
	// Flags: [Event|Protected|BlueprintEvent]
	float GetSectorCheckDistance(); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.GetSectorCheckAngle
	// Flags: [Event|Protected|BlueprintEvent]
	float GetSectorCheckAngle(); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.GetPlayerHalfHeight
	// Flags: [Event|Protected|BlueprintEvent]
	float GetPlayerHalfHeight(); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.GetCrossHairCheckIntervalCfg
	// Flags: [Event|Protected|BlueprintEvent]
	float GetCrossHairCheckIntervalCfg(); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.GetCrossHairCheckDistanceCfg
	// Flags: [Event|Protected|BlueprintEvent]
	float GetCrossHairCheckDistanceCfg(); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.ClearCanEditParamsObjs
	// Flags: [Event|Protected|BlueprintEvent]
	void ClearCanEditParamsObjs(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.AddCanEditObject
	// Flags: [Event|Protected|BlueprintEvent]
	void AddCanEditObject(struct UObject* uCanEditObject, float Angle, float Distance); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x10)
};

// Object Name: Class Creative.CreativeModeManagerBase
// Size: 0x110 // Inherited bytes: 0x110
struct UCreativeModeManagerBase : USTExtraManagerBase {
};

// Object Name: Class Creative.CreativeModeAssetManager
// Size: 0x168 // Inherited bytes: 0x110
struct UCreativeModeAssetManager : UCreativeModeManagerBase {
	// Fields
	char pad_0x110[0x58]; // Offset: 0x110 // Size: 0x58

	// Functions

	// Object Name: Function Creative.CreativeModeAssetManager.ReceiveOnGameStateBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnGameStateBeginPlay(struct AGameStateBase* GameState); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeAssetManager.ReceiveInitAssetInfo
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveInitAssetInfo(int AssetId); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeAssetManager.OnGameStateBeginPlay
	// Flags: [Final|Native|Public]
	void OnGameStateBeginPlay(struct AGameStateBase* GameState); // Offset: 0x10228ef9c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeAssetManager.GetObbyMeshPath
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	struct FString GetObbyMeshPath(int AssetId); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativeModeAssetManager.GetMaterialPath
	// Flags: [Event|Public|BlueprintEvent|Const]
	struct FString GetMaterialPath(int MaterialID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativeModeAssetManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeAssetManager* Get(struct UObject* WorldContext); // Offset: 0x10228ef20 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeAssetManager.AddAssetInfo
	// Flags: [Final|Native|Public|HasOutParms]
	void AddAssetInfo(int AssetId, struct FCreativeAssetInfo& AssetInfo); // Offset: 0x10228ee14 // Return & Params: Num(2) Size(0x60)
};

// Object Name: Class Creative.CreativeModeBackpackUtils
// Size: 0x28 // Inherited bytes: 0x28
struct UCreativeModeBackpackUtils : UBackpackUtils {
	// Functions

	// Object Name: Function Creative.CreativeModeBackpackUtils.ResCanAddToBackpackNum
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int ResCanAddToBackpackNum(struct UBackpackComponent* BackpackComponent, int resID, int AddNum); // Offset: 0x10228f2f4 // Return & Params: Num(4) Size(0x14)
};

// Object Name: Class Creative.CreativeModeBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UCreativeModeBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.TransformMultiplyBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void TransformMultiplyBy(struct FTransform& Source, struct FTransform& M); // Offset: 0x102291ba8 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.TransformBounds
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void TransformBounds(struct FBoxSphereBounds& Bounds, struct FTransform& M); // Offset: 0x102291ac4 // Return & Params: Num(2) Size(0x50)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.SetStaticMeshMobility
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetStaticMeshMobility(struct UStaticMeshComponent* StaticMeshComponent, enum class EComponentMobility NewMobility); // Offset: 0x102291a14 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.SetSpeedOverLimit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetSpeedOverLimit(struct AActor* Actor); // Offset: 0x1022919a0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.SetInstanceValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetInstanceValue(struct UObject* WorldContextObject, struct FString InstanceID, struct FString Key, struct FString Value); // Offset: 0x1022917bc // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.SetEditorActorTransform
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	bool SetEditorActorTransform(struct UObject* WorldContextObject, struct FString InstanceID, struct FTransform NewTransform); // Offset: 0x102291658 // Return & Params: Num(4) Size(0x51)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.SetCollisionMobility
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetCollisionMobility(struct UShapeComponent* Component, enum class EComponentMobility NewMobility); // Offset: 0x1022915a8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.SaveAssetStringToFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SaveAssetStringToFile(struct FString String, struct FString Filename); // Offset: 0x1022914c4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.RenameObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RenameObject(struct UObject* Object, struct FString NewName); // Offset: 0x1022913c8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.QuatCross
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct FQuat QuatCross(struct FQuat& Quat1, struct FQuat& Quat2); // Offset: 0x1022912e8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.ProjectSavedDir
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString ProjectSavedDir(); // Offset: 0x102291284 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.MinAreaRectangle
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void MinAreaRectangle(struct UObject* WorldContextObject, struct TArray<struct FVector>& InPoints, struct FVector& SampleSurfaceNormal, struct FVector& OutRectCenter, struct FRotator& OutRectRotation, float& OutRectLengthX, float& OutRectLengthY, bool bDebugDraw, struct TArray<int>& PolyVertIndices); // Offset: 0x102290f44 // Return & Params: Num(9) Size(0x58)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.MD5HashByteArray
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FString MD5HashByteArray(struct TArray<char>& inArray); // Offset: 0x102290e74 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.MD5HashAnsiString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString MD5HashAnsiString(struct FString str); // Offset: 0x102290db4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.LoadAssetFileToString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString LoadAssetFileToString(struct FString Filename); // Offset: 0x102290cf4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.IsCreativeMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsCreativeMode(struct UWorld* World); // Offset: 0x102290c78 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.IgnoreClientMovementErrorChecksAndCorrection
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void IgnoreClientMovementErrorChecksAndCorrection(struct ACharacter* Charcter, bool bIsIgnore); // Offset: 0x102290bc0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.GetReplicateAddDataArrayVaildNum
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	int GetReplicateAddDataArrayVaildNum(struct UObject* WorldContextObject, struct FReplicateAddDataArray& ReplicateAddDataArray, int StartIndex); // Offset: 0x102290a90 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.GetObjectScreenPos
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GetObjectScreenPos(struct UObject* WorldContextObject, struct FString InstanceID, struct FVector2D& pos); // Offset: 0x102290978 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.GetObjectMap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TMap<struct FString, struct UObject*> GetObjectMap(struct UObject* WorldContextObject); // Offset: 0x1022908d4 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.GetGameTypeAsString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetGameTypeAsString(enum class ECreativeModeGameType GameType); // Offset: 0x102290830 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.GetActorMeshBoundsByTag
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GetActorMeshBoundsByTag(struct AActor* Actor, struct FVector& Origin, struct FVector& BoxExtent, struct FString IgnoreTag, struct FString IncludeTag); // Offset: 0x102290670 // Return & Params: Num(5) Size(0x40)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.GenerateGuid
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GenerateGuid(); // Offset: 0x10229060c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.DrawLine
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawLine(struct FPaintContext& InContext, struct FVector2D& Start, struct FVector2D& End, struct FLinearColor& LineColor, int LayerOffset, float LineThickness, bool bAntiAlias); // Offset: 0x1022903e0 // Return & Params: Num(7) Size(0x59)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.DrawGrids
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawGrids(struct FPaintContext& InContext, float CellSize, int CellCountX, int CellCountY, float PosOffsetX, float PosOffsetY, struct FLinearColor& LineColor, float LineThickness, bool bAntiAlias, int LayerOffset); // Offset: 0x102290128 // Return & Params: Num(10) Size(0x60)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.DrawGridCell
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawGridCell(struct FPaintContext& InContext, float CellSize, int CellIndexX, int CellIndexY, float PosOffsetX, float PosOffsetY, struct FLinearColor& LineColor, int LayerOffset); // Offset: 0x10228fef0 // Return & Params: Num(8) Size(0x58)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.DestroyInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString DestroyInstance(struct UObject* WorldContextObject, struct FString InstanceID); // Offset: 0x10228fdcc // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.ClearGrassByMaskTexture
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void ClearGrassByMaskTexture(struct UObject* WorldContextObject, struct UTexture2D* MaskTexture, struct FVector2D WorldStart, struct FVector2D WorldEnd); // Offset: 0x10228fca8 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.BoxOverlapComponents
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	bool BoxOverlapComponents(struct UObject* WorldContextObject, struct FVector BoxPos, struct FVector BoxExtent, struct TArray<int>& ObjectTypes, struct UObject* CompClassFilter, struct TArray<struct AActor*>& ActorsToIgnore, struct TArray<struct UPrimitiveComponent*>& OutComps); // Offset: 0x10228fa34 // Return & Params: Num(8) Size(0x59)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.BoxOverlapActors
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	bool BoxOverlapActors(struct UObject* WorldContextObject, struct FVector BoxPos, struct FVector BoxExtent, struct TArray<int>& ObjectTypes, struct UObject* ActorClassFilter, struct TArray<struct AActor*>& ActorsToIgnore, struct TArray<struct AActor*>& OutActors); // Offset: 0x10228f7c0 // Return & Params: Num(8) Size(0x59)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.BeginDeferredActorSpawnWithName
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct AActor* BeginDeferredActorSpawnWithName(struct UObject* WorldContextObject, struct AActor* ActorClass, struct FTransform& SpawnTransform, struct FName Name, enum class ESpawnActorCollisionHandlingMethod CollisionHandlingOverride, struct AActor* Owner); // Offset: 0x10228f5ec // Return & Params: Num(7) Size(0x60)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.AddOnScreenDebugMessage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AddOnScreenDebugMessage(struct FString Msg); // Offset: 0x10228f538 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Creative.CreativeModeCheatManager
// Size: 0x130 // Inherited bytes: 0x130
struct UCreativeModeCheatManager : UGMCheatManager {
	// Functions

	// Object Name: Function Creative.CreativeModeCheatManager.SetInstanceValue
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	void SetInstanceValue(struct FString InstanceID, struct FString Key, struct FString Value); // Offset: 0x102292754 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Creative.CreativeModeCheatManager.SetCurrentGameType
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	void SetCurrentGameType(enum class ECreativeModeGameType NewGameType); // Offset: 0x1022926d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeCheatManager.DestroyInstance
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	void DestroyInstance(struct FString InstanceID); // Offset: 0x10229261c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Creative.CreativeModeLiteComponent
// Size: 0x160 // Inherited bytes: 0x40
struct UCreativeModeLiteComponent : ULiteComponent {
	// Fields
	char pad_0x40[0x70]; // Offset: 0x40 // Size: 0x70
	struct FLuaNetSerialization LuaNetSerialization; // Offset: 0xb0 // Size: 0x50
	struct FString LuaFilePath; // Offset: 0x100 // Size: 0x10
	struct TMap<struct UObject*, struct FCreativePoolObjectRecordInfo> PoolObjectRecordMap; // Offset: 0x110 // Size: 0x50

	// Functions

	// Object Name: Function Creative.CreativeModeLiteComponent.OnReturnToPool
	// Flags: [Native|Public]
	void OnReturnToPool(struct UObject* NewOuter, uint32_t RecycledSeq); // Offset: 0x1022a4aa8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Creative.CreativeModeLiteComponent.GetObjectFromPool
	// Flags: [Final|Native|Public|HasOutParms]
	struct UObject* GetObjectFromPool(int PoolID, struct UObject* NewOuter, struct FString& InName); // Offset: 0x1022a4978 // Return & Params: Num(4) Size(0x28)
};

// Object Name: Class Creative.CreativeModeGameModeBaseComponent
// Size: 0x170 // Inherited bytes: 0x160
struct UCreativeModeGameModeBaseComponent : UCreativeModeLiteComponent {
	// Fields
	enum class ECreativeModeGameType GameType; // Offset: 0x160 // Size: 0x01
	char pad_0x161[0x7]; // Offset: 0x161 // Size: 0x07
	struct UCreativeModeGameStateBaseComponent* GameStateComponent; // Offset: 0x168 // Size: 0x08

	// Functions

	// Object Name: Function Creative.CreativeModeGameModeBaseComponent.SetGameStateComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGameStateComponent(struct UCreativeModeGameStateBaseComponent* NewGameStateComponent); // Offset: 0x10229482c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameModeBaseComponent.ReceivePostInitializeComponents
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivePostInitializeComponents(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameModeBaseComponent.GetGameType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ECreativeModeGameType GetGameType(); // Offset: 0x102294810 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameModeBaseComponent.GetGameMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ACreativeModeGameMode* GetGameMode(); // Offset: 0x1022947dc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameModeBaseComponent.FindPlayerStartOverride
	// Flags: [Event|Public|BlueprintEvent]
	struct AActor* FindPlayerStartOverride(struct AController* Player, struct FString IncomingName, bool bIsRevive); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x28)
};

// Object Name: Class Creative.CreativeModeEditorModeComponent
// Size: 0x170 // Inherited bytes: 0x170
struct UCreativeModeEditorModeComponent : UCreativeModeGameModeBaseComponent {
};

// Object Name: Class Creative.CreativeModeEditorObject
// Size: 0x5a0 // Inherited bytes: 0x4b8
struct ACreativeModeEditorObject : ALuaActor {
	// Fields
	char pad_0x4B8[0x18]; // Offset: 0x4b8 // Size: 0x18
	enum class ECreativeModeActorState ActorState; // Offset: 0x4d0 // Size: 0x01
	char pad_0x4D1[0x7]; // Offset: 0x4d1 // Size: 0x07
	struct TArray<struct FCreativeEditorObjectEffectMesheInfo> CachedEffectMesheInfos; // Offset: 0x4d8 // Size: 0x10
	struct TMap<struct UObject*, struct FCreativePoolObjectRecordInfo> PoolObjectRecordMap; // Offset: 0x4e8 // Size: 0x50
	struct FEditorObjectLiteComponentTickFunction LiteComponentActorTick; // Offset: 0x538 // Size: 0x58
	struct TArray<struct ULiteComponent*> LiteComponents; // Offset: 0x590 // Size: 0x10

	// Functions

	// Object Name: Function Creative.CreativeModeEditorObject.UnregisterLiteComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnregisterLiteComponent(struct ULiteComponent* Component, bool Destroy); // Offset: 0x102293568 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Creative.CreativeModeEditorObject.ShowSelectedEffect
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void ShowSelectedEffect(bool ShowEff, struct FLinearColor OutlineColor, float OutlineThickness); // Offset: 0x102293464 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Creative.CreativeModeEditorObject.ShowOutlineEffect
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ShowOutlineEffect(bool ShowEff, struct UMaterialInstance* Material, struct FString IgnoreTag); // Offset: 0x102293344 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Creative.CreativeModeEditorObject.SetLiteComponentTickEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLiteComponentTickEnable(bool bEnabled); // Offset: 0x1022932c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeEditorObject.SetActorState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetActorState(enum class ECreativeModeActorState NewState); // Offset: 0x102293244 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeEditorObject.RegisterLiteComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterLiteComponent(struct ULiteComponent* Component); // Offset: 0x1022931c8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeEditorObject.ReceivePostBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivePostBeginPlay(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeEditorObject.ReceiveIsDedicatedServer
	// Flags: [Final|Native|Public|Const]
	bool ReceiveIsDedicatedServer(); // Offset: 0x102293194 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeEditorObject.ReceiveInitializeLiteComponent
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveInitializeLiteComponent(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeEditorObject.ReceiveHasAuthority
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool ReceiveHasAuthority(); // Offset: 0x102293160 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeEditorObject.OnRepActorStateOverride
	// Flags: [Event|Protected|BlueprintEvent]
	void OnRepActorStateOverride(enum class ECreativeModeActorState NewState); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeEditorObject.OnRep_ActorState
	// Flags: [Final|Native|Public]
	void OnRep_ActorState(enum class ECreativeModeActorState LastState); // Offset: 0x1022930e4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeEditorObject.GetObjectFromPool
	// Flags: [Native|Public|HasOutParms]
	struct UObject* GetObjectFromPool(int PoolID, struct UObject* NewOuter, struct FString& InName); // Offset: 0x102292fac // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Creative.CreativeModeEditorObject.GetActorState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ECreativeModeActorState GetActorState(); // Offset: 0x102292f78 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeEditorObject.FindLiteComponentByClass
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULiteComponent* FindLiteComponentByClass(struct ULiteComponent* ComponentClass); // Offset: 0x102292eec // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeEditorObject.CanEditParameters
	// Flags: [Event|Public|BlueprintEvent]
	bool CanEditParameters(); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Creative.CreativeModeGameStateBaseComponent
// Size: 0x168 // Inherited bytes: 0x160
struct UCreativeModeGameStateBaseComponent : UCreativeModeLiteComponent {
	// Fields
	enum class ECreativeModeGameType GameType; // Offset: 0x160 // Size: 0x01
	char pad_0x161[0x7]; // Offset: 0x161 // Size: 0x07

	// Functions

	// Object Name: Function Creative.CreativeModeGameStateBaseComponent.ReceivePostInitializeComponents
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivePostInitializeComponents(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameStateBaseComponent.GetPlayState
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	enum class ECreativeModePlayState GetPlayState(); // Offset: 0x10229a19c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameStateBaseComponent.GetGameType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ECreativeModeGameType GetGameType(); // Offset: 0x10229a180 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameStateBaseComponent.GetGameState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ACreativeModeGameState* GetGameState(); // Offset: 0x10229a14c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Creative.CreativeModeEditorStateComponent
// Size: 0x168 // Inherited bytes: 0x168
struct UCreativeModeEditorStateComponent : UCreativeModeGameStateBaseComponent {
};

// Object Name: Class Creative.CreativeModeGameMode
// Size: 0x25b0 // Inherited bytes: 0x2480
struct ACreativeModeGameMode : ABattleRoyaleGameModeTeam {
	// Fields
	struct UCreativeModeGameModeBaseComponent* CurrentModeComponent; // Offset: 0x2480 // Size: 0x08
	struct TArray<struct UCreativeModeGameModeBaseComponent*> GameModeComponentClassArray; // Offset: 0x2488 // Size: 0x10
	struct UCreativeModeGameModeComponent* GameModeComponentClass; // Offset: 0x2498 // Size: 0x08
	struct TMap<struct FString, struct FGameModeParam> MapPlaneRouteConfigs; // Offset: 0x24a0 // Size: 0x50
	struct TMap<struct FString, struct FString> MapVehicleClassPathConfigs; // Offset: 0x24f0 // Size: 0x50
	enum class ECreativeModeGameType EditorStartupGameType; // Offset: 0x2540 // Size: 0x01
	char pad_0x2541[0x7]; // Offset: 0x2541 // Size: 0x07
	struct FGameModeLiteComponentTickFunction LiteComponentActorTick; // Offset: 0x2548 // Size: 0x58
	struct TArray<struct ULiteComponent*> LiteComponents; // Offset: 0x25a0 // Size: 0x10

	// Functions

	// Object Name: Function Creative.CreativeModeGameMode.UnregisterLiteComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnregisterLiteComponent(struct ULiteComponent* Component); // Offset: 0x102294230 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameMode.SetLiteComponentTickEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLiteComponentTickEnable(bool bEnabled); // Offset: 0x1022941ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameMode.SetItemGenerate
	// Flags: [Native|Event|Public|BlueprintEvent]
	void SetItemGenerate(bool bIsOpen); // Offset: 0x102294120 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameMode.SetCurrentGameType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCurrentGameType(enum class ECreativeModeGameType NewGameType); // Offset: 0x1022940a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameMode.RegisterLiteComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterLiteComponent(struct ULiteComponent* Component); // Offset: 0x102294028 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameMode.ReceiveInitializeLiteComponent
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveInitializeLiteComponent(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameMode.IsRestartPlayerUsePawnRotation
	// Flags: [Native|Public]
	bool IsRestartPlayerUsePawnRotation(); // Offset: 0x102293fec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameMode.GetCurrentModeComponent
	// Flags: [Final|Native|Public]
	struct UCreativeModeGameModeBaseComponent* GetCurrentModeComponent(); // Offset: 0x102293fd0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameMode.GetCreativeModeRealTeamNum
	// Flags: [Final|Native|Public]
	int GetCreativeModeRealTeamNum(); // Offset: 0x102293f9c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeGameMode.GetCreativeModeRealTeamIDs
	// Flags: [Final|Native|Public]
	struct TArray<int> GetCreativeModeRealTeamIDs(); // Offset: 0x102293f38 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeGameMode.FindLiteComponentByClass
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULiteComponent* FindLiteComponentByClass(struct ULiteComponent* ComponentClass); // Offset: 0x102293eac // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeGameMode.CreativeModeFindPlayerStart
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure]
	struct AActor* CreativeModeFindPlayerStart(struct AController* Player, struct FString IncomingName, bool bIsRevive); // Offset: 0x102293d80 // Return & Params: Num(4) Size(0x28)
};

// Object Name: Class Creative.CreativeModeGameModeComponent
// Size: 0x1a0 // Inherited bytes: 0x170
struct UCreativeModeGameModeComponent : UCreativeModeGameModeBaseComponent {
	// Fields
	struct UCreativeModeRaceCheckPointLiteComponent* RaceCheckPointComponentClass; // Offset: 0x170 // Size: 0x08
	struct UCreativeModeRaceCheckPointLiteComponent* RaceCheckPointComponent; // Offset: 0x178 // Size: 0x08
	struct UCreativeOccupationAreaLiteComponent* OccupationAreaComponentClass; // Offset: 0x180 // Size: 0x08
	struct UCreativeOccupationAreaLiteComponent* OccupationAreaComponent; // Offset: 0x188 // Size: 0x08
	struct UCreativeModeLiteComponent* TeleporterComponentClass; // Offset: 0x190 // Size: 0x08
	struct UCreativeModeLiteComponent* TeleporterComponent; // Offset: 0x198 // Size: 0x08

	// Functions

	// Object Name: Function Creative.CreativeModeGameModeComponent.ReceiveCallPlayStateFunction
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveCallPlayStateFunction(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Creative.CreativeModeGameObject
// Size: 0x118 // Inherited bytes: 0x28
struct UCreativeModeGameObject : UObject {
	// Fields
	char pad_0x28[0x78]; // Offset: 0x28 // Size: 0x78
	struct FString LuaFilePath; // Offset: 0xa0 // Size: 0x10
	char pad_0xB0[0x8]; // Offset: 0xb0 // Size: 0x08
	struct TMap<struct UObject*, struct FCreativePoolObjectRecordInfo> PoolObjectRecordMap; // Offset: 0xb8 // Size: 0x50
	struct TArray<struct ULiteComponent*> LiteComponents; // Offset: 0x108 // Size: 0x10

	// Functions

	// Object Name: Function Creative.CreativeModeGameObject.UnregisterLiteComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnregisterLiteComponent(struct ULiteComponent* Component, bool Destroy); // Offset: 0x102294ed0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Creative.CreativeModeGameObject.RegisterLiteComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterLiteComponent(struct ULiteComponent* Component); // Offset: 0x102294e54 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameObject.ReceivePostBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceivePostBeginPlay(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameObject.ReceiveIsDedicatedServer
	// Flags: [Final|Native|Public|Const]
	bool ReceiveIsDedicatedServer(); // Offset: 0x102294e20 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameObject.ReceiveHasAuthority
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool ReceiveHasAuthority(); // Offset: 0x102294dec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameObject.ReceiveEndPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveEndPlay(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameObject.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameObject.GetObjectFromPool
	// Flags: [Native|Public|HasOutParms]
	struct UObject* GetObjectFromPool(int PoolID, struct UObject* NewOuter, struct FString& InName); // Offset: 0x102294cb4 // Return & Params: Num(4) Size(0x28)
};

// Object Name: Class Creative.CreativeModeGameParameterManager
// Size: 0x1e0 // Inherited bytes: 0x110
struct UCreativeModeGameParameterManager : UCreativeModeManagerBase {
	// Fields
	struct FCreativeModeGameParameterContainer GameParameterContainer; // Offset: 0x110 // Size: 0xc8
	char pad_0x1D8[0x4]; // Offset: 0x1d8 // Size: 0x04
	int SingleSerializeNum; // Offset: 0x1dc // Size: 0x04

	// Functions

	// Object Name: Function Creative.CreativeModeGameParameterManager.RemoveGameParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveGameParameter(struct FString ParameterKey, struct FString TemplateID); // Offset: 0x102298fa8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeGameParameterManager.ReceiveOnGameStateBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveOnGameStateBeginPlay(struct AGameStateBase* GameState); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameParameterManager.OnReceivePreGameParameterRemove
	// Flags: [Event|Public|BlueprintEvent]
	void OnReceivePreGameParameterRemove(struct FString ParameterKey, struct FString TemplateID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeGameParameterManager.OnReceivePostGameParameterChange
	// Flags: [Event|Public|BlueprintEvent]
	void OnReceivePostGameParameterChange(struct FString ParameterKey, struct FString TemplateID, struct FString Desc); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Creative.CreativeModeGameParameterManager.OnReceivePostGameParameterAdd
	// Flags: [Event|Public|BlueprintEvent]
	void OnReceivePostGameParameterAdd(struct FString ParameterKey, struct FString TemplateID, struct FString Desc); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Creative.CreativeModeGameParameterManager.OnGameStateBeginPlay
	// Flags: [Final|Native|Protected]
	void OnGameStateBeginPlay(struct AGameStateBase* GameState); // Offset: 0x102298f2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameParameterManager.GetGameParameterDesc
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetGameParameterDesc(struct FString ParameterKey, struct FString TemplateID); // Offset: 0x102298de4 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Creative.CreativeModeGameParameterManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeGameParameterManager* Get(struct UObject* WorldContext); // Offset: 0x102298d68 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeGameParameterManager.ChangeGameParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChangeGameParameter(struct FString ParameterKey, struct FString TemplateID, struct FString Desc); // Offset: 0x102298c04 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Creative.CreativeModeGameParameterManager.AddGameParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddGameParameter(struct FString ParameterKey, struct FString TemplateID, struct FString Desc); // Offset: 0x102298aa0 // Return & Params: Num(3) Size(0x30)
};

// Object Name: Class Creative.CreativeModeGameState
// Size: 0x1430 // Inherited bytes: 0x1398
struct ACreativeModeGameState : ASTExtraGameStateBase {
	// Fields
	char bIsCreativeMode : 1; // Offset: 0x1398 // Size: 0x01
	char pad_0x1398_1 : 7; // Offset: 0x1398 // Size: 0x01
	enum class ECreativeModeGameType CurrentGameType; // Offset: 0x1399 // Size: 0x01
	enum class ECreativeModeGameType InitializeGameType; // Offset: 0x139a // Size: 0x01
	char pad_0x139B[0x5]; // Offset: 0x139b // Size: 0x05
	struct UCreativeModeGameStateBaseComponent* CurrentStateComponent; // Offset: 0x13a0 // Size: 0x08
	struct UCreativeModeGameStateBaseComponent* LastStateComponent; // Offset: 0x13a8 // Size: 0x08
	struct TArray<struct UCreativeModeGameStateBaseComponent*> GameStateComponentClassArray; // Offset: 0x13b0 // Size: 0x10
	struct UCreativeModeGameStateComponent* GameStateComponentClass; // Offset: 0x13c0 // Size: 0x08
	struct FGameStateLiteComponentTickFunction LiteComponentActorTick; // Offset: 0x13c8 // Size: 0x58
	struct TArray<struct ULiteComponent*> LiteComponents; // Offset: 0x1420 // Size: 0x10

	// Functions

	// Object Name: Function Creative.CreativeModeGameState.UnregisterLiteComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnregisterLiteComponent(struct ULiteComponent* Component); // Offset: 0x1022999d4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameState.SetLiteComponentTickEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLiteComponentTickEnable(bool bEnabled); // Offset: 0x102299950 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameState.SetCurrentGameType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCurrentGameType(enum class ECreativeModeGameType NewGameType); // Offset: 0x1022998d4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameState.RegisterLiteComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterLiteComponent(struct ULiteComponent* Component); // Offset: 0x102299858 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameState.ReceiveInitializeLiteComponent
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveInitializeLiteComponent(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameState.OnRep_InitializeGameType
	// Flags: [Final|Native|Protected]
	void OnRep_InitializeGameType(enum class ECreativeModeGameType LastInitializeGameType); // Offset: 0x1022997dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameState.OnRep_CurrentStateComponent
	// Flags: [Final|Native|Protected]
	void OnRep_CurrentStateComponent(struct UCreativeModeGameStateBaseComponent* LastComponent); // Offset: 0x102299760 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameState.IsCreativeEditor
	// Flags: [Native|Public]
	bool IsCreativeEditor(); // Offset: 0x102299724 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameState.GetPlayState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	enum class ECreativeModePlayState GetPlayState(); // Offset: 0x1022996f0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameState.GetIsOfficialGame
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsOfficialGame(); // Offset: 0x1022996c8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameState.GetIsEditorMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsEditorMode(); // Offset: 0x1022996a0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameState.GetIsDemoGame
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsDemoGame(); // Offset: 0x10229965c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameState.GetIsCreative
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	bool GetIsCreative(); // Offset: 0x102299620 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameState.GetInitializeGameType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ECreativeModeGameType GetInitializeGameType(); // Offset: 0x102299600 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameState.GetCurrentStateComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UCreativeModeGameStateBaseComponent* GetCurrentStateComponent(); // Offset: 0x1022995e4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameState.GetCurrentGameType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ECreativeModeGameType GetCurrentGameType(); // Offset: 0x1022995c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameState.FindLiteComponentByClass
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULiteComponent* FindLiteComponentByClass(struct ULiteComponent* ComponentClass); // Offset: 0x102299538 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeGameState.ClearInstance
	// Flags: [Final|Native|Public]
	void ClearInstance(); // Offset: 0x102299524 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameState.ClearAndReImportInstance
	// Flags: [Final|Native|Protected]
	void ClearAndReImportInstance(); // Offset: 0x102299510 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Creative.CreativeModeGameStateComponent
// Size: 0x190 // Inherited bytes: 0x168
struct UCreativeModeGameStateComponent : UCreativeModeGameStateBaseComponent {
	// Fields
	struct UCreativeModeIntegralMechanismLiteComponent* IntegralMechanismComponentClass; // Offset: 0x168 // Size: 0x08
	struct UCreativeModeIntegralMechanismLiteComponent* IntegralMechanismComponent; // Offset: 0x170 // Size: 0x08
	struct ACreativeRuntimePlayerBattleDataObject* RuntimePlayerBattleDataObjectClass; // Offset: 0x178 // Size: 0x08
	struct ACreativeRuntimePlayerBattleDataObject* RuntimePlayerBattleDataObject; // Offset: 0x180 // Size: 0x08
	enum class ECreativeModePlayState CurPlayState; // Offset: 0x188 // Size: 0x01
	char pad_0x189[0x7]; // Offset: 0x189 // Size: 0x07

	// Functions

	// Object Name: Function Creative.CreativeModeGameStateComponent.SetPlayState
	// Flags: [Final|Native|Protected]
	void SetPlayState(enum class ECreativeModePlayState newPlayState); // Offset: 0x10229a464 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameStateComponent.OnRep_RuntimePlayerBattleDataObject
	// Flags: [Final|Native|Protected]
	void OnRep_RuntimePlayerBattleDataObject(); // Offset: 0x10229a450 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameStateComponent.OnRep_IntegralMechanismComponent
	// Flags: [Final|Native|Protected]
	void OnRep_IntegralMechanismComponent(); // Offset: 0x10229a43c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameStateComponent.OnRep_CurPlayState
	// Flags: [Final|Native|Protected]
	void OnRep_CurPlayState(); // Offset: 0x10229a428 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameStateComponent.GetPlayState
	// Flags: [Native|Protected|BlueprintCallable|BlueprintPure]
	enum class ECreativeModePlayState GetPlayState(); // Offset: 0x10229a3ec // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Creative.CreativeModeGridLevelsManager
// Size: 0x550 // Inherited bytes: 0x110
struct UCreativeModeGridLevelsManager : UCreativeModeManagerBase {
	// Fields
	char pad_0x110[0x40]; // Offset: 0x110 // Size: 0x40
	struct TArray<struct FString> GridLevelList; // Offset: 0x150 // Size: 0x10
	struct TMap<struct FString, struct FCreativeModeGridLevelConfig> GridLevelConfigs; // Offset: 0x160 // Size: 0x50
	struct TMap<struct FString, struct FCreativeModeGridLevelInfo> GridLevelsMap; // Offset: 0x1b0 // Size: 0x50
	struct TMap<struct FString, struct FIntVector> ObjectCellIndexMap; // Offset: 0x200 // Size: 0x50
	struct TArray<struct FString> AlwaysLoadLevel; // Offset: 0x250 // Size: 0x10
	char pad_0x260[0x10]; // Offset: 0x260 // Size: 0x10
	bool bStaticMeshObjectBatchSwitch; // Offset: 0x270 // Size: 0x01
	bool bAroundRelieveBatchSwitch; // Offset: 0x271 // Size: 0x01
	char pad_0x272[0x2]; // Offset: 0x272 // Size: 0x02
	float EditorModeUpdateTime; // Offset: 0x274 // Size: 0x04
	float DelayUpdateBatchTime; // Offset: 0x278 // Size: 0x04
	float TickUpdateBatchInterval; // Offset: 0x27c // Size: 0x04
	float ReBatchDistance; // Offset: 0x280 // Size: 0x04
	float RelieveBatchDistance; // Offset: 0x284 // Size: 0x04
	int UpdateIsmNumPerFrame; // Offset: 0x288 // Size: 0x04
	char pad_0x28C[0x2c4]; // Offset: 0x28c // Size: 0x2c4

	// Functions

	// Object Name: Function Creative.CreativeModeGridLevelsManager.UpdateBatchActorInstances
	// Flags: [Final|Native|Public]
	void UpdateBatchActorInstances(struct FString GridName, int AssetId, int MaterialID, bool ReplaceAll); // Offset: 0x10229c854 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.UnLoadGridLevelsBatchActor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void UnLoadGridLevelsBatchActor(struct FString GridName, struct FIntVector& CellIndex); // Offset: 0x10229c770 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.StaticMeshObjectRelieveBatch
	// Flags: [Final|Native|Public|HasOutParms]
	void StaticMeshObjectRelieveBatch(struct FString& InstanceID); // Offset: 0x10229c6c8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.StaticMeshObjectReBatch
	// Flags: [Final|Native|Public|HasOutParms]
	void StaticMeshObjectReBatch(struct FString& InstanceID); // Offset: 0x10229c620 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.RemoveObject
	// Flags: [Final|Native|Public]
	bool RemoveObject(struct FString InstanceID); // Offset: 0x10229c578 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.ReceiveRegistInstanceValueListener
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveRegistInstanceValueListener(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.ReceiveDelayUpdateBatchActorInstances
	// Flags: [Final|Native|Public]
	void ReceiveDelayUpdateBatchActorInstances(struct FString GridName, int AssetId, int MaterialID, bool ReplaceAll); // Offset: 0x10229c41c // Return & Params: Num(4) Size(0x19)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.ReceiveClearAllData
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveClearAllData(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.ReceiveCheckObjectCanBatch
	// Flags: [Event|Public|BlueprintEvent]
	bool ReceiveCheckObjectCanBatch(struct FString InstanceID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.ObjectAddToGridCellMap
	// Flags: [Final|Native|Public|HasDefaults]
	void ObjectAddToGridCellMap(struct FString GridName, struct FIntVector Index, struct FString InstanceID); // Offset: 0x10229c2bc // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.LoadGridLevelsBatchActor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void LoadGridLevelsBatchActor(struct FString GridName, struct FIntVector& CellIndex); // Offset: 0x10229c1d8 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.IsCreativeEidtMode
	// Flags: [Final|Native|Private]
	bool IsCreativeEidtMode(); // Offset: 0x10229c1a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GridCellMapRemoveObject
	// Flags: [Final|Native|Public|HasDefaults]
	void GridCellMapRemoveObject(struct FString GridName, struct FIntVector Index, struct FString InstanceID); // Offset: 0x10229c044 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetStaticMeshBatchActorPath
	// Flags: [Event|Public|BlueprintEvent]
	struct FString GetStaticMeshBatchActorPath(); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetRelieveBatchDistance
	// Flags: [Final|Native|Public]
	float GetRelieveBatchDistance(); // Offset: 0x10229c010 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetReBatchDistance
	// Flags: [Final|Native|Public]
	float GetReBatchDistance(); // Offset: 0x10229bfdc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetOnCellIndex
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	struct FIntVector GetOnCellIndex(struct FString GridName, struct FVector& Location); // Offset: 0x10229bedc // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetObjectTransform
	// Flags: [Final|Native|Private|HasDefaults]
	struct FTransform GetObjectTransform(struct FString ID); // Offset: 0x10229be20 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetObjectStreamingType
	// Flags: [Final|Native|Private]
	enum class ECreativeModeActorStreamingType GetObjectStreamingType(struct FString ID); // Offset: 0x10229bd78 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetObjectRuntimeGrid
	// Flags: [Final|Native|Public]
	struct FString GetObjectRuntimeGrid(struct FString ID); // Offset: 0x10229bca8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetObjectIsPrefab
	// Flags: [Final|Native|Private]
	bool GetObjectIsPrefab(struct FString ID); // Offset: 0x10229bc00 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetObjectAssetID
	// Flags: [Final|Native|Private]
	int GetObjectAssetID(struct FString ID); // Offset: 0x10229bb58 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetGridLoadingRange
	// Flags: [Final|Native|Public]
	float GetGridLoadingRange(struct FString GridName); // Offset: 0x10229bab0 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetGridList
	// Flags: [Final|Native|Public]
	struct TArray<struct FString> GetGridList(); // Offset: 0x10229ba4c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetDefaultGridName
	// Flags: [Event|Public|BlueprintEvent]
	struct FString GetDefaultGridName(); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetCellWidthHeight
	// Flags: [Final|Native|Public|HasDefaults]
	struct FVector2D GetCellWidthHeight(struct FString GridName); // Offset: 0x10229b9a0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetCellCenterLocation
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	struct FVector GetCellCenterLocation(struct FString GridName, struct FIntVector& CellIndex); // Offset: 0x10229b8a4 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetAxisIndex
	// Flags: [Final|Native|Public|Const]
	int GetAxisIndex(float pos, float BlockLenght); // Offset: 0x10229b7e0 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeGridLevelsManager* Get(struct UObject* WorldContext); // Offset: 0x10229b764 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.CheckObjectBeRelieveBatch
	// Flags: [Final|Native|Private]
	bool CheckObjectBeRelieveBatch(struct FString ID); // Offset: 0x10229b6bc // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.CheckObjectBeBatch
	// Flags: [Final|Native|Public]
	bool CheckObjectBeBatch(struct FString ID); // Offset: 0x10229b614 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.CheckAndRemoveObjectForBatchData
	// Flags: [Final|Native|Public]
	bool CheckAndRemoveObjectForBatchData(struct FString ID); // Offset: 0x10229b56c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.CheckAndAddObjectToBatchData
	// Flags: [Final|Native|Public]
	bool CheckAndAddObjectToBatchData(struct FString ID); // Offset: 0x10229b4c4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.ChangeObjectTransform
	// Flags: [Final|Native|Public]
	bool ChangeObjectTransform(struct FString InstanceID); // Offset: 0x10229b41c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.ChangeObjectStreamingType
	// Flags: [Final|Native|Public]
	bool ChangeObjectStreamingType(struct FString InstanceID, enum class ECreativeModeActorStreamingType NewStremaingType); // Offset: 0x10229b334 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.ChangeObjectMaterialId
	// Flags: [Final|Native|Public]
	bool ChangeObjectMaterialId(struct FString InstanceID, int MaterialID); // Offset: 0x10229b24c // Return & Params: Num(3) Size(0x15)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.ChangeObjectIsPrefab
	// Flags: [Final|Native|Public]
	bool ChangeObjectIsPrefab(struct FString InstanceID, bool bIsPrefab); // Offset: 0x10229b15c // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.AddObjectToGridLevels
	// Flags: [Final|Native|Public]
	bool AddObjectToGridLevels(struct FString InstanceID); // Offset: 0x10229b0b4 // Return & Params: Num(2) Size(0x11)
};

// Object Name: Class Creative.CreativeModeInGameManagerCenter
// Size: 0x438 // Inherited bytes: 0x3f0
struct ACreativeModeInGameManagerCenter : AActor {
	// Fields
	char pad_0x3F0[0x10]; // Offset: 0x3f0 // Size: 0x10
	struct TArray<struct USTExtraManagerBase*> ManagerArray; // Offset: 0x400 // Size: 0x10
	struct TArray<struct USTExtraManagerBase*> ManagerClassArray; // Offset: 0x410 // Size: 0x10
	char pad_0x420[0x18]; // Offset: 0x420 // Size: 0x18
};

// Object Name: Class Creative.CreativeModeInstanceManager
// Size: 0x3e0 // Inherited bytes: 0x110
struct UCreativeModeInstanceManager : UCreativeModeManagerBase {
	// Fields
	char pad_0x110[0x40]; // Offset: 0x110 // Size: 0x40
	struct TMap<struct FString, struct FCreativeInstanceDataNode> InstanceTreeData; // Offset: 0x150 // Size: 0x50
	struct TMap<uint16_t, struct FCreativeBatchPullDataNode> DataRequestMap; // Offset: 0x1a0 // Size: 0x50
	struct TArray<struct FCreativePullDataNode> DataWaitingRquestQueue; // Offset: 0x1f0 // Size: 0x10
	char pad_0x200[0x10]; // Offset: 0x200 // Size: 0x10
	struct FCreativeModeNodeContainer InstanceContainer; // Offset: 0x210 // Size: 0xc8
	char pad_0x2D8[0x50]; // Offset: 0x2d8 // Size: 0x50
	int ModBinInstanceCount; // Offset: 0x328 // Size: 0x04
	char pad_0x32C[0x4]; // Offset: 0x32c // Size: 0x04
	int SingleSerializeNum; // Offset: 0x330 // Size: 0x04
	int SinglePullDataNodeNum; // Offset: 0x334 // Size: 0x04
	float DataNodePullInterval; // Offset: 0x338 // Size: 0x04
	float DataPullTimeroutInterval; // Offset: 0x33c // Size: 0x04
	float WaitInstanceReplicatTreeTimeout; // Offset: 0x340 // Size: 0x04
	float BuildingResTime; // Offset: 0x344 // Size: 0x04
	float BuildingTimeoutCheckInterval; // Offset: 0x348 // Size: 0x04
	char pad_0x34C[0x4]; // Offset: 0x34c // Size: 0x04
	struct TMap<struct FString, struct FCreativeInstancceNode> CppInstanceTree; // Offset: 0x350 // Size: 0x50
	char pad_0x3A0[0x40]; // Offset: 0x3a0 // Size: 0x40

	// Functions

	// Object Name: Function Creative.CreativeModeInstanceManager.UpdateModBinInstanceCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateModBinInstanceCount(); // Offset: 0x10229eb34 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeInstanceManager.SetModBinInstanceCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetModBinInstanceCount(int Count); // Offset: 0x10229eabc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeInstanceManager.SetInstanceValue
	// Flags: [Event|Public|BlueprintEvent]
	bool SetInstanceValue(struct FString InstanceID, struct FString Key, struct FString Value); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x31)

	// Object Name: Function Creative.CreativeModeInstanceManager.SetInstanceTransform
	// Flags: [Event|Public|HasDefaults|BlueprintEvent]
	void SetInstanceTransform(struct FString InstanceID, struct FTransform Transform); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Creative.CreativeModeInstanceManager.SendModBinaryDataToReplay
	// Flags: [Final|Native|Private|HasOutParms]
	void SendModBinaryDataToReplay(struct TArray<char>& InBinaryData); // Offset: 0x10229ea14 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeInstanceManager.RemoveInstance
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveInstance(struct FString ID); // Offset: 0x10229e97c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeInstanceManager.RemoveCppInstanceNode
	// Flags: [Final|Native|Public]
	bool RemoveCppInstanceNode(struct FString ID); // Offset: 0x10229e8d4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeInstanceManager.ReceiveOnGameStateBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnGameStateBeginPlay(struct AGameStateBase* GameState); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeInstanceManager.OnRep_ModBinInstanceCount
	// Flags: [Final|Native|Public]
	void OnRep_ModBinInstanceCount(); // Offset: 0x10229e8c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeInstanceManager.OnReceivePreInstanceRemove
	// Flags: [Event|Public|BlueprintEvent]
	void OnReceivePreInstanceRemove(struct FString ID); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeInstanceManager.OnReceivePostInstanceChange
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void OnReceivePostInstanceChange(struct FString ID, struct TArray<char>& Content); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeInstanceManager.OnReceivePostInstanceAdd
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void OnReceivePostInstanceAdd(struct FString ID, struct TArray<char>& Content); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeInstanceManager.OnReadyToAddInstance
	// Flags: [Final|Native|Public]
	void OnReadyToAddInstance(); // Offset: 0x10229e8ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeInstanceManager.OnGameTypeChanged
	// Flags: [Final|Native|Public]
	void OnGameTypeChanged(char LastGameType, char CurrentGameType); // Offset: 0x10229e7f4 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Creative.CreativeModeInstanceManager.OnGameStateBeginPlay
	// Flags: [Final|Native|Public]
	void OnGameStateBeginPlay(struct AGameStateBase* GameState); // Offset: 0x10229e778 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeInstanceManager.IsInstanceReplicatTreeReplicateComplete
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsInstanceReplicatTreeReplicateComplete(); // Offset: 0x10229e744 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeInstanceManager.IsInstanceDataTreeReplicateComplete
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsInstanceDataTreeReplicateComplete(); // Offset: 0x10229e710 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeInstanceManager.HasReadyToAddInstance
	// Flags: [Final|Native|Public|Const]
	bool HasReadyToAddInstance(); // Offset: 0x10229e6f0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeInstanceManager.HasAuthorityOrReplay
	// Flags: [Final|Native|Private|Const]
	bool HasAuthorityOrReplay(); // Offset: 0x10229e6bc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeInstanceManager.GetModBinInstanceCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	int GetModBinInstanceCount(); // Offset: 0x10229e6a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeInstanceManager.GetModBinaryDataFromReplay
	// Flags: [Final|Native|Private|HasOutParms]
	bool GetModBinaryDataFromReplay(struct TArray<char>& InBinaryData); // Offset: 0x10229e5e8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeInstanceManager.GetInstanceContainerCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	int GetInstanceContainerCount(); // Offset: 0x10229e5cc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeInstanceManager.GetCppInstanceNode
	// Flags: [Final|Native|Public]
	struct FCreativeInstancceNode GetCppInstanceNode(struct FString ID); // Offset: 0x10229e51c // Return & Params: Num(2) Size(0x70)

	// Object Name: Function Creative.CreativeModeInstanceManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeInstanceManager* Get(struct UObject* WorldContext); // Offset: 0x10229e4a0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeInstanceManager.DestroyInstance
	// Flags: [Event|Public|BlueprintEvent]
	struct FString DestroyInstance(struct FString InstanceID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeInstanceManager.ChangeInstance
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void ChangeInstance(struct FString ID, struct TArray<char>& Content); // Offset: 0x10229e3a4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeInstanceManager.ChangeCppInstanceNode
	// Flags: [Final|Native|Public|HasOutParms]
	void ChangeCppInstanceNode(struct FString ID, struct FString Key, struct FCreativeInstancceNode& Node); // Offset: 0x10229e214 // Return & Params: Num(3) Size(0x80)

	// Object Name: Function Creative.CreativeModeInstanceManager.AddInstance
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void AddInstance(struct FString ID, struct TArray<char>& Content); // Offset: 0x10229e118 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeInstanceManager.AddCppInstanceNode
	// Flags: [Final|Native|Public|HasOutParms]
	void AddCppInstanceNode(struct FString ID, struct FCreativeInstancceNode& Node); // Offset: 0x10229dfdc // Return & Params: Num(2) Size(0x70)

	// Object Name: Function Creative.CreativeModeInstanceManager.AddBuildingFlag
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddBuildingFlag(struct FString ID); // Offset: 0x10229df44 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Creative.CreativeModeIntegralMechanismComponent
// Size: 0x1e8 // Inherited bytes: 0x1d8
struct UCreativeModeIntegralMechanismComponent : ULuaActorComponent {
	// Fields
	struct TArray<struct FPlayerIntegralInfo> PlayerIntegrals; // Offset: 0x1d8 // Size: 0x10

	// Functions

	// Object Name: Function Creative.CreativeModeIntegralMechanismComponent.SetPlayerIntegral
	// Flags: [Final|Native|Protected]
	bool SetPlayerIntegral(struct FString UId, int TeamID, int curIntegral, int curStageIntegral, int integralAddSeq); // Offset: 0x1022a3c28 // Return & Params: Num(6) Size(0x21)

	// Object Name: Function Creative.CreativeModeIntegralMechanismComponent.OnRepPlayerIntegralsOverride
	// Flags: [Event|Protected|BlueprintEvent]
	void OnRepPlayerIntegralsOverride(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeIntegralMechanismComponent.OnRep_PlayerIntegrals
	// Flags: [Final|Native|Protected]
	void OnRep_PlayerIntegrals(); // Offset: 0x1022a3c14 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeIntegralMechanismComponent.ClearPlayerIntegrals
	// Flags: [Final|Native|Protected]
	void ClearPlayerIntegrals(); // Offset: 0x1022a3c00 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Creative.CreativeModeIntegralMechanismLiteComponent
// Size: 0x178 // Inherited bytes: 0x160
struct UCreativeModeIntegralMechanismLiteComponent : UCreativeModeLiteComponent {
	// Fields
	struct TArray<struct FPlayerIntegralInfo> PlayerIntegrals; // Offset: 0x160 // Size: 0x10
	int TestIndex; // Offset: 0x170 // Size: 0x04
	char pad_0x174[0x4]; // Offset: 0x174 // Size: 0x04

	// Functions

	// Object Name: Function Creative.CreativeModeIntegralMechanismLiteComponent.SetPlayerIntegral
	// Flags: [Final|Native|Protected]
	bool SetPlayerIntegral(struct FString UId, int TeamID, int curIntegral, int curStageIntegral, int integralAddSeq); // Offset: 0x1022a41b8 // Return & Params: Num(6) Size(0x21)

	// Object Name: Function Creative.CreativeModeIntegralMechanismLiteComponent.PlayerIntegralContains
	// Flags: [Final|Native|Protected]
	bool PlayerIntegralContains(struct FString UId); // Offset: 0x1022a40ec // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeIntegralMechanismLiteComponent.OnRepPlayerIntegralsOverride
	// Flags: [Event|Protected|BlueprintEvent]
	void OnRepPlayerIntegralsOverride(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeIntegralMechanismLiteComponent.OnRep_TestIndex
	// Flags: [Final|Native|Protected]
	void OnRep_TestIndex(int LastIndex); // Offset: 0x1022a4070 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeIntegralMechanismLiteComponent.OnRep_PlayerIntegrals
	// Flags: [Final|Native|Protected]
	void OnRep_PlayerIntegrals(); // Offset: 0x1022a405c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeIntegralMechanismLiteComponent.ClearPlayerIntegrals
	// Flags: [Final|Native|Protected]
	void ClearPlayerIntegrals(); // Offset: 0x1022a4048 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Creative.CreativeItemGeneratorComponent
// Size: 0xa28 // Inherited bytes: 0x9d0
struct UCreativeItemGeneratorComponent : UItemGeneratorComponent {
	// Fields
	char pad_0x9D0[0x58]; // Offset: 0x9d0 // Size: 0x58

	// Functions

	// Object Name: Function Creative.CreativeItemGeneratorComponent.SetWeightMul
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetWeightMul(struct TMap<struct FString, int>& Weight); // Offset: 0x1022a46fc // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Creative.CreativeItemGeneratorComponent.SetAddSpotPercentMul
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAddSpotPercentMul(float percent); // Offset: 0x1022a4680 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeItemGeneratorComponent.ClearWeightMul
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearWeightMul(); // Offset: 0x1022a466c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Creative.CreativeModeModDataCheckManager
// Size: 0x110 // Inherited bytes: 0x110
struct UCreativeModeModDataCheckManager : UCreativeModeManagerBase {
	// Functions

	// Object Name: Function Creative.CreativeModeModDataCheckManager.ReceiveOnPreAddInstance
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnPreAddInstance(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeModDataCheckManager.ReceiveOnPostAddInstance
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnPostAddInstance(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeModDataCheckManager.OnPreAddInstance
	// Flags: [Final|Native|Public]
	void OnPreAddInstance(); // Offset: 0x1022a4f04 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeModDataCheckManager.OnPostAddInstance
	// Flags: [Final|Native|Public]
	void OnPostAddInstance(); // Offset: 0x1022a4ef0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeModDataCheckManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeModDataCheckManager* Get(struct UObject* WorldContext); // Offset: 0x1022a4e74 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Creative.CreativeModeLuaSpectatorPawn
// Size: 0x548 // Inherited bytes: 0x478
struct ACreativeModeLuaSpectatorPawn : ASpectatorPawn {
	// Fields
	char pad_0x478[0x60]; // Offset: 0x478 // Size: 0x60
	struct FLuaNetSerialization LuaNetSerialization; // Offset: 0x4d8 // Size: 0x50
	bool IsTopView; // Offset: 0x528 // Size: 0x01
	char pad_0x529[0x3]; // Offset: 0x529 // Size: 0x03
	int TopViewRotateAngle; // Offset: 0x52c // Size: 0x04
	struct FString LuaFilePath; // Offset: 0x530 // Size: 0x10
	char pad_0x540[0x8]; // Offset: 0x540 // Size: 0x08

	// Functions

	// Object Name: Function Creative.CreativeModeLuaSpectatorPawn.UnRegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnRegistLuaTick(); // Offset: 0x1022a5348 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeLuaSpectatorPawn.SetAbilitySystemComponentAvatar
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAbilitySystemComponentAvatar(); // Offset: 0x1022a5334 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeLuaSpectatorPawn.RegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegistLuaTick(float TickInterval); // Offset: 0x1022a52b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeLuaSpectatorPawn.MoveRight
	// Flags: [Native|Public|BlueprintCallable]
	void MoveRight(float Val); // Offset: 0x1022a5234 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeLuaSpectatorPawn.MoveForward
	// Flags: [Native|Public|BlueprintCallable]
	void MoveForward(float Val); // Offset: 0x1022a51b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeLuaSpectatorPawn.GetActiveSpringArm
	// Flags: [Native|Event|Public|BlueprintEvent]
	struct USpringArmComponent* GetActiveSpringArm(); // Offset: 0x1022a5174 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Creative.CreativeModeStaticMeshBatchActor
// Size: 0x560 // Inherited bytes: 0x4b8
struct ACreativeModeStaticMeshBatchActor : ALuaActor {
	// Fields
	char pad_0x4B8[0x48]; // Offset: 0x4b8 // Size: 0x48
	struct FCreativeBatchInstancedStaticMesh InstancedStaticMeshInfo; // Offset: 0x500 // Size: 0x58
	char pad_0x558[0x8]; // Offset: 0x558 // Size: 0x08

	// Functions

	// Object Name: Function Creative.CreativeModeStaticMeshBatchActor.SetISMStaticMeshAndMaterials
	// Flags: [Event|Public|BlueprintEvent]
	void SetISMStaticMeshAndMaterials(struct UInstancedStaticMeshComponent* InstancedStaticMeshComponent, int AssetId, int StaticMeshIndex, int MaterialID); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x14)

	// Object Name: Function Creative.CreativeModeStaticMeshBatchActor.GetBatchStaticMeshInfo
	// Flags: [Final|Native|Public]
	struct FCreativeBatchStaticMeshInfo GetBatchStaticMeshInfo(struct UInstancedStaticMeshComponent* InstancedStaticMeshComponent); // Offset: 0x1022a5950 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Creative.CreativeModeNavigationManager
// Size: 0x160 // Inherited bytes: 0x110
struct UCreativeModeNavigationManager : UCreativeModeManagerBase {
	// Fields
	struct TSet<struct AActor*> CachedActors; // Offset: 0x110 // Size: 0x50

	// Functions

	// Object Name: Function Creative.CreativeModeNavigationManager.SetDynamicModeEnable
	// Flags: [Final|Native|Public]
	void SetDynamicModeEnable(bool bEnable); // Offset: 0x1022a646c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeNavigationManager.ReceiveOnUnInit
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnUnInit(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeNavigationManager.ReceiveOnInit
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnInit(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeNavigationManager.RebuildDynamicTiles
	// Flags: [Final|Native|Public|HasOutParms]
	void RebuildDynamicTiles(struct TArray<struct AActor*>& Actors); // Offset: 0x1022a63c4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeNavigationManager.GetDynamicTilesCount
	// Flags: [Final|Native|Public]
	int GetDynamicTilesCount(); // Offset: 0x1022a6390 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeNavigationManager.GetDynamicTileMemCost
	// Flags: [Final|Native|Public|HasOutParms]
	bool GetDynamicTileMemCost(int& Total, int& OctTree, int& TileCache, int& DynamicTile, int& DynamicTileCount); // Offset: 0x1022a61b4 // Return & Params: Num(6) Size(0x15)

	// Object Name: Function Creative.CreativeModeNavigationManager.GetAllAssociateActors
	// Flags: [Final|Native|Public|Const]
	struct TArray<struct AActor*> GetAllAssociateActors(); // Offset: 0x1022a6150 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeNavigationManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeNavigationManager* Get(struct UObject* WorldContext); // Offset: 0x1022a60d4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeNavigationManager.ExportDynamicTile
	// Flags: [Final|Native|Public|HasOutParms]
	void ExportDynamicTile(struct FString& Path); // Offset: 0x1022a602c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeNavigationManager.ClearNavCollision
	// Flags: [Final|Native|Public]
	void ClearNavCollision(); // Offset: 0x1022a6018 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeNavigationManager.ClearDynamicOctreeData
	// Flags: [Final|Native|Public]
	void ClearDynamicOctreeData(); // Offset: 0x1022a6004 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeNavigationManager.ClearDynamicNavMesh
	// Flags: [Final|Native|Public]
	void ClearDynamicNavMesh(); // Offset: 0x1022a5ff0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeNavigationManager.ClearAssociateActors
	// Flags: [Final|Native|Public]
	void ClearAssociateActors(); // Offset: 0x1022a5fdc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeNavigationManager.CalSamplePointsInBox
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	struct TArray<struct FVector> CalSamplePointsInBox(struct FVector& BoxMin, struct FVector& BoxMax, float StepSize, int MaxPoints); // Offset: 0x1022a5e4c // Return & Params: Num(5) Size(0x30)

	// Object Name: Function Creative.CreativeModeNavigationManager.CalSamplePoints
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	struct TArray<struct FVector> CalSamplePoints(struct FVector& StartPos, float StepSize, int MaxPoints); // Offset: 0x1022a5d10 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Creative.CreativeModeNavigationManager.AddNavAffectedObjects
	// Flags: [Final|Native|Public|HasOutParms]
	void AddNavAffectedObjects(struct TArray<struct AActor*>& Actors); // Offset: 0x1022a5c68 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeNavigationManager.AddNavAffectedObject
	// Flags: [Final|Native|Public]
	void AddNavAffectedObject(struct AActor* Actor); // Offset: 0x1022a5bec // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Creative.CreativeModeObjectFuncComponent
// Size: 0x160 // Inherited bytes: 0x160
struct UCreativeModeObjectFuncComponent : UCreativeModeLiteComponent {
};

// Object Name: Class Creative.CreativeModeObjectInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UCreativeModeObjectInterface : UInterface {
	// Functions

	// Object Name: Function Creative.CreativeModeObjectInterface.ReceiveOnPostSetInstanceId
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnPostSetInstanceId(struct FString InstanceID); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Creative.CreativeModeObjectManager
// Size: 0x200 // Inherited bytes: 0x110
struct UCreativeModeObjectManager : UCreativeModeManagerBase {
	// Fields
	struct TMap<struct FString, struct UObject*> ObjectMap; // Offset: 0x110 // Size: 0x50
	struct TMap<struct FString, bool> ObjectActiveMap; // Offset: 0x160 // Size: 0x50
	bool bContainsSpawnCompleteCallback; // Offset: 0x1b0 // Size: 0x01
	bool bReordering; // Offset: 0x1b1 // Size: 0x01
	char pad_0x1B2[0x2]; // Offset: 0x1b2 // Size: 0x02
	int Client_FrameSpawnNum; // Offset: 0x1b4 // Size: 0x04
	int Ds_FrameSpawnNum; // Offset: 0x1b8 // Size: 0x04
	char pad_0x1BC[0x44]; // Offset: 0x1bc // Size: 0x44

	// Functions

	// Object Name: Function Creative.CreativeModeObjectManager.SpawnObjectForStreaming
	// Flags: [Final|Native|Public]
	void SpawnObjectForStreaming(struct FString InstanceID); // Offset: 0x1022a8188 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeObjectManager.SpawnObjectForBatchManager
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void SpawnObjectForBatchManager(struct FString& InstanceID, struct FTransform& SpawnTransform); // Offset: 0x1022a806c // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Creative.CreativeModeObjectManager.SpawnObject
	// Flags: [Final|Native|Private|HasDefaults]
	struct UObject* SpawnObject(struct FString InstanceID, struct FString Path, struct FTransform SpawnTransform); // Offset: 0x1022a7ec0 // Return & Params: Num(4) Size(0x58)

	// Object Name: Function Creative.CreativeModeObjectManager.SetObjectTempStreamingType
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetObjectTempStreamingType(struct FString InstanceID, enum class ECreativeModeActorStreamingType TempStreamingType); // Offset: 0x1022a7dd8 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Creative.CreativeModeObjectManager.ResetObjectStreamingType
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool ResetObjectStreamingType(struct FString InstanceID); // Offset: 0x1022a7d30 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeObjectManager.RemoveSpawnObjectInfoFormQueue
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool RemoveSpawnObjectInfoFormQueue(struct FString& InstanceID); // Offset: 0x1022a7c78 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeObjectManager.RemovePhysicsObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemovePhysicsObject(struct FString InstanceID); // Offset: 0x1022a7bbc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeObjectManager.RemoveObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool RemoveObject(struct FString InstanceID); // Offset: 0x1022a7af0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeObjectManager.ReceiveUnregisterObject
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveUnregisterObject(struct FString InstanceID, struct UObject* NewObject); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativeModeObjectManager.ReceiveRegisterObject
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveRegisterObject(struct FString InstanceID, struct UObject* NewObject); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativeModeObjectManager.ReceiveClearAllObjects
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveClearAllObjects(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeObjectManager.OnObjectSpawnComplete
	// Flags: [Event|Public|BlueprintEvent]
	void OnObjectSpawnComplete(struct FString ID); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeObjectManager.GetObjectTransform
	// Flags: [Final|Native|Public|HasDefaults]
	struct FTransform GetObjectTransform(struct FString ID); // Offset: 0x1022a7a34 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Creative.CreativeModeObjectManager.GetObjectNum
	// Flags: [Final|Native|Public|Const]
	uint32_t GetObjectNum(); // Offset: 0x1022a7a00 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeObjectManager.GetObjectAssetPath
	// Flags: [Final|Native|Public]
	struct FString GetObjectAssetPath(struct FString ID); // Offset: 0x1022a7930 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeObjectManager.GetObjectAssetID
	// Flags: [Final|Native|Public]
	int GetObjectAssetID(struct FString ID); // Offset: 0x1022a7888 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Creative.CreativeModeObjectManager.GetObject
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UObject* GetObject(struct FString InstanceID); // Offset: 0x1022a77bc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativeModeObjectManager.GetActiveObjectNum
	// Flags: [Final|Native|Public|Const]
	uint32_t GetActiveObjectNum(); // Offset: 0x1022a7788 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeObjectManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeObjectManager* Get(struct UObject* WorldContext); // Offset: 0x1022a770c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeObjectManager.DestroyObjectForStreaming
	// Flags: [Final|Native|Public]
	void DestroyObjectForStreaming(struct FString InstanceID); // Offset: 0x1022a7650 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeObjectManager.DestroyObjectForBatchManager
	// Flags: [Final|Native|Public|HasOutParms]
	void DestroyObjectForBatchManager(struct FString& InstanceID); // Offset: 0x1022a75a8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeObjectManager.DestroyObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool DestroyObject(struct FString InstanceID); // Offset: 0x1022a74dc // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeObjectManager.CheckObjectBeBatch
	// Flags: [Final|Native|Public]
	bool CheckObjectBeBatch(struct FString ID); // Offset: 0x1022a7434 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeObjectManager.ChangeObjectTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	bool ChangeObjectTransform(struct FString InstanceID, struct FTransform Transform); // Offset: 0x1022a7300 // Return & Params: Num(3) Size(0x41)

	// Object Name: Function Creative.CreativeModeObjectManager.AddSpawnObjectToQueue
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void AddSpawnObjectToQueue(struct FString InstanceID, struct FString Path, struct FTransform SpawnTransform); // Offset: 0x1022a7164 // Return & Params: Num(3) Size(0x50)

	// Object Name: Function Creative.CreativeModeObjectManager.AddPhysicsObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddPhysicsObject(struct FString InstanceID); // Offset: 0x1022a70a8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeObjectManager.AddObject
	// Flags: [Final|Native|Public]
	bool AddObject(struct FString InstanceID, struct FCreativeModeStreamingParameters StreamingParameters); // Offset: 0x1022a6f98 // Return & Params: Num(3) Size(0x13)
};

// Object Name: Class Creative.CreativeOccupationAreaLiteComponent
// Size: 0x160 // Inherited bytes: 0x160
struct UCreativeOccupationAreaLiteComponent : UCreativeModeLiteComponent {
};

// Object Name: Class Creative.CreativePhysicsBatchActor
// Size: 0x580 // Inherited bytes: 0x4b8
struct ACreativePhysicsBatchActor : ALuaActor {
	// Fields
	struct TMap<struct FString, struct UCreativePhysicsComponent*> InstancePhysicsComponentMap; // Offset: 0x4b8 // Size: 0x50
	char pad_0x508[0x68]; // Offset: 0x508 // Size: 0x68
	int RegisterMaxNum; // Offset: 0x570 // Size: 0x04
	int ReplicateLimit; // Offset: 0x574 // Size: 0x04
	char pad_0x578[0x8]; // Offset: 0x578 // Size: 0x08

	// Functions

	// Object Name: Function Creative.CreativePhysicsBatchActor.UpdatePhysicsComponentMaterial
	// Flags: [Final|Native|Public|HasOutParms]
	void UpdatePhysicsComponentMaterial(struct FString& ComponentID, struct FString& MaterialPath); // Offset: 0x1022a8df8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativePhysicsBatchActor.UpdatePhysicsComponent
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void UpdatePhysicsComponent(struct FString& ComponentID, struct FTransform Transform, enum class ECollisionEnabled CollisionEnabled); // Offset: 0x1022a8c9c // Return & Params: Num(3) Size(0x41)

	// Object Name: Function Creative.CreativePhysicsBatchActor.SetPhysicsComponentEnabled
	// Flags: [Final|Native|Public|HasOutParms]
	void SetPhysicsComponentEnabled(struct FString& ComponentID, enum class ECollisionEnabled CollisionEnabled); // Offset: 0x1022a8ba8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativePhysicsBatchActor.ClearAllPhysicsComponent
	// Flags: [Final|Native|Public]
	void ClearAllPhysicsComponent(); // Offset: 0x1022a8b94 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Creative.CreativePhysicsComponent
// Size: 0x7e0 // Inherited bytes: 0x790
struct UCreativePhysicsComponent : UMeshComponent {
	// Fields
	struct UBodySetup* BodySetup; // Offset: 0x790 // Size: 0x08
	struct FString InstanceID; // Offset: 0x798 // Size: 0x10
	struct FName CollisionProfileName; // Offset: 0x7a8 // Size: 0x08
	char pad_0x7B0[0x30]; // Offset: 0x7b0 // Size: 0x30

	// Functions

	// Object Name: Function Creative.CreativePhysicsComponent.SetIsReplicatedOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsReplicatedOnly(bool ShouldReplicate); // Offset: 0x1022a912c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Creative.CreativePhysicsManager
// Size: 0x268 // Inherited bytes: 0x110
struct UCreativePhysicsManager : UCreativeModeManagerBase {
	// Fields
	char pad_0x110[0x10]; // Offset: 0x110 // Size: 0x10
	struct TMap<struct FString, struct UBodySetup*> BodySetupMap; // Offset: 0x120 // Size: 0x50
	struct TMap<struct FString, struct UMaterialInterface*> MaterialInterfaceMap; // Offset: 0x170 // Size: 0x50
	struct TMap<int, struct ACreativePhysicsBatchActor*> PhysicsBatchActorMap; // Offset: 0x1c0 // Size: 0x50
	bool StreamingEnable; // Offset: 0x210 // Size: 0x01
	bool IsGrid; // Offset: 0x211 // Size: 0x01
	char pad_0x212[0x6]; // Offset: 0x212 // Size: 0x06
	struct TMap<int, bool> VisiblePhysicsBatchActors; // Offset: 0x218 // Size: 0x50

	// Functions

	// Object Name: Function Creative.CreativePhysicsManager.SetStreamingEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStreamingEnable(bool Enable); // Offset: 0x1022a9838 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativePhysicsManager.SetPhysicsActorVisible
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPhysicsActorVisible(int Index, bool Visible); // Offset: 0x1022a977c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Creative.CreativePhysicsManager.RemovePhysicsObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemovePhysicsObject(struct FString InstanceID); // Offset: 0x1022a96c0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativePhysicsManager.IsPhysicsActorVisible
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsPhysicsActorVisible(int Index); // Offset: 0x1022a9634 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Creative.CreativePhysicsManager.GetPhysicsBatchActorByInstanceID
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct ACreativePhysicsBatchActor* GetPhysicsBatchActorByInstanceID(struct FString InstanceID); // Offset: 0x1022a9568 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativePhysicsManager.GetPhysicsBatchActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct ACreativePhysicsBatchActor* GetPhysicsBatchActor(int Index); // Offset: 0x1022a94dc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativePhysicsManager.GetLandscapeIndex
	// Flags: [Event|Public|BlueprintEvent]
	int GetLandscapeIndex(struct FString InstanceID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Creative.CreativePhysicsManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativePhysicsManager* Get(struct UObject* WorldContext); // Offset: 0x1022a9460 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativePhysicsManager.ClearAllPhysicsBatchActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearAllPhysicsBatchActor(); // Offset: 0x1022a944c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativePhysicsManager.AddPhysicsObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddPhysicsObject(struct FString InstanceID); // Offset: 0x1022a9390 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Creative.CreativeModePlayerState
// Size: 0x19e8 // Inherited bytes: 0x19e0
struct ACreativeModePlayerState : ASTExtraPlayerState {
	// Fields
	bool bEnableAutoPickUp; // Offset: 0x19e0 // Size: 0x01
	char pad_0x19E1[0x7]; // Offset: 0x19e1 // Size: 0x07

	// Functions

	// Object Name: Function Creative.CreativeModePlayerState.ServerSetInstanceTransfrom
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|HasDefaults|NetValidate]
	void ServerSetInstanceTransfrom(struct FString InstanceID, struct FTransform InstanceTransform); // Offset: 0x1022aa2c0 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Creative.CreativeModePlayerState.ServerRPC_RequestPullData
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerRPC_RequestPullData(uint32_t Seq, struct TArray<uint32_t> InstanceIds); // Offset: 0x1022aa1b8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativeModePlayerState.ServerLoadBinaryData
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerLoadBinaryData(struct TArray<char> PbBuffer); // Offset: 0x1022aa0f0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModePlayerState.ServerAddInstance
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerAddInstance(struct FString InstanceID, struct TArray<char> Content); // Offset: 0x1022a9fd0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModePlayerState.GM_LoadBinaryData
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void GM_LoadBinaryData(struct TArray<char>& PbBuffer); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModePlayerState.ClientRPC_RespondPullData
	// Flags: [Final|Net|NetReliableNative|Event|Private|NetClient|NetValidate]
	void ClientRPC_RespondPullData(uint32_t Seq, struct TArray<struct FCreativeInstanceDataContent> InstanceDatas); // Offset: 0x1022a9ec8 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Creative.CreativePoolInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UCreativePoolInterface : UInterface {
	// Functions

	// Object Name: Function Creative.CreativePoolInterface.SetRecycleTime
	// Flags: [Native|Public]
	void SetRecycleTime(float RecycleTime); // Offset: 0x1022aa948 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativePoolInterface.SetIsRecycled
	// Flags: [Native|Public]
	void SetIsRecycled(bool IsRecycled); // Offset: 0x1022aa8bc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativePoolInterface.ReceiveOnReturnToPool
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveOnReturnToPool(struct UObject* NewOuter, int RecycledSeq); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Creative.CreativePoolInterface.ReceiveOnPickFromPool
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveOnPickFromPool(struct UObject* NewOuter, struct FString InName); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativePoolInterface.OnReturnToPool
	// Flags: [Native|Public]
	void OnReturnToPool(struct UObject* NewOuter, uint32_t RecycledSeq); // Offset: 0x1022aa7fc // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Creative.CreativePoolInterface.OnPickFromPool
	// Flags: [Native|Public]
	void OnPickFromPool(struct UObject* NewOuter, struct FString InName); // Offset: 0x1022aa720 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativePoolInterface.GetRecycleTime
	// Flags: [Native|Public]
	float GetRecycleTime(); // Offset: 0x1022aa6e4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativePoolInterface.CheckIsRecycled
	// Flags: [Native|Public]
	bool CheckIsRecycled(); // Offset: 0x1022aa6a8 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Creative.CreativePoolManager
// Size: 0x170 // Inherited bytes: 0x110
struct UCreativePoolManager : UCreativeModeManagerBase {
	// Fields
	bool bPoolManagerEnable; // Offset: 0x110 // Size: 0x01
	char pad_0x111[0xf]; // Offset: 0x111 // Size: 0x0f
	struct TMap<int, struct FCreativeObjectPool> CreativePools; // Offset: 0x120 // Size: 0x50

	// Functions

	// Object Name: Function Creative.CreativePoolManager.SetPoolManagerEnable
	// Flags: [Final|Native|Public]
	void SetPoolManagerEnable(bool bPoolManagerEnable); // Offset: 0x1022ab488 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativePoolManager.ReturnObject
	// Flags: [Final|Native|Public]
	void ReturnObject(int PoolID, struct UObject* Obj); // Offset: 0x1022ab3d0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativePoolManager.OnReceiveDestroyHandle
	// Flags: [Event|Public|BlueprintEvent]
	bool OnReceiveDestroyHandle(int ID, struct UObject* InObj); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Creative.CreativePoolManager.OnReceiveCreateHandle
	// Flags: [Event|Public|BlueprintEvent]
	struct UObject* OnReceiveCreateHandle(int ID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativePoolManager.InitPool
	// Flags: [Final|Native|Protected|HasOutParms]
	bool InitPool(int PoolID, struct FCreativeObjectPoolClassConfig& PoolConfig, bool bPoolEnable); // Offset: 0x1022ab284 // Return & Params: Num(4) Size(0x2a)

	// Object Name: Function Creative.CreativePoolManager.GetObject
	// Flags: [Final|Native|Public|HasOutParms]
	struct UObject* GetObject(int PoolID, struct UObject* NewOuter, struct FString& InName); // Offset: 0x1022ab154 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Creative.CreativePoolManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativePoolManager* Get(struct UObject* WorldContext); // Offset: 0x1022ab0d8 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Creative.CreativeModeRaceCheckPointComponent
// Size: 0x1d8 // Inherited bytes: 0x1d8
struct UCreativeModeRaceCheckPointComponent : ULuaActorComponent {
};

// Object Name: Class Creative.CreativeModeRaceCheckPointLiteComponent
// Size: 0x160 // Inherited bytes: 0x160
struct UCreativeModeRaceCheckPointLiteComponent : UCreativeModeLiteComponent {
};

// Object Name: Class Creative.CreativeRuntimePlayerBattleDataObject
// Size: 0x7a8 // Inherited bytes: 0x4b8
struct ACreativeRuntimePlayerBattleDataObject : ALuaActor {
	// Fields
	struct FRuntimePlayerBattleDataInfo DefaultPlayerBattleDataInfo; // Offset: 0x4b8 // Size: 0x60
	struct FRuntimeTeamGameOutcomeConditionInfo DefaultTeamGameOutcomeCondition; // Offset: 0x518 // Size: 0x18
	struct FRuntimeCacheRoundBattleDataInfoContainer RuntimeOldCacheRoundBattleDataContainer; // Offset: 0x530 // Size: 0xc8
	struct FRuntimeBattleDataInfoContainer RuntimeCurRoundBattleDataInfoContainer; // Offset: 0x5f8 // Size: 0xc8
	struct FRuntimeTeamGameOutcomeConditionContainer RuntimeTeamGameOutcomeConditionContainer; // Offset: 0x6c0 // Size: 0xc8
	struct FRuntimeCacheRoundBattleDataInfo DefaultCacheRoundBattleDataInfo; // Offset: 0x788 // Size: 0x20

	// Functions

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.SetTeamGameOutcomeCondition
	// Flags: [Final|Native|Protected|HasOutParms]
	bool SetTeamGameOutcomeCondition(int TeamID, struct FRuntimeTeamGameOutcomeConditionInfo& TeamGameOutcomeCondition, bool bPropagateToChildren); // Offset: 0x1022b04d4 // Return & Params: Num(4) Size(0x1e)

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.SetPlayerBattleData
	// Flags: [Final|Native|Protected|HasOutParms]
	bool SetPlayerBattleData(uint64 UId, uint32_t PlayerKey, struct FRuntimePlayerBattleDataInfo& PlayerBattleData, bool bPropagateToChildren); // Offset: 0x1022b0354 // Return & Params: Num(5) Size(0x72)

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.OnRepTeamGameOutcomeConditionInfo
	// Flags: [Final|Native|Public]
	void OnRepTeamGameOutcomeConditionInfo(int TeamID); // Offset: 0x1022b02d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.OnRepCurRoundPlayerBattleDataInfo
	// Flags: [Final|Native|Public]
	void OnRepCurRoundPlayerBattleDataInfo(uint64 PlayerUID, uint64 PlayerKey, int ChangeTeamID); // Offset: 0x1022b01e8 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.GetTeamGameOutcomeCondition
	// Flags: [Final|Native|Protected]
	struct FRuntimeTeamGameOutcomeConditionInfo GetTeamGameOutcomeCondition(int TeamID); // Offset: 0x1022b0138 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.GetCurRoundPlayerBattleData
	// Flags: [Final|Native|Protected]
	struct FRuntimePlayerBattleDataInfo GetCurRoundPlayerBattleData(uint64 PlayerUID, uint32_t PlayerKey); // Offset: 0x1022b0048 // Return & Params: Num(3) Size(0x70)

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.GetCurRoundAllPlayerBattleData
	// Flags: [Final|Native|Protected]
	struct TArray<struct FRuntimePlayerBattleDataInfo> GetCurRoundAllPlayerBattleData(); // Offset: 0x1022affe4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.GetCacheRoundPlayerBattleData
	// Flags: [Final|Native|Protected]
	struct FRuntimePlayerBattleDataInfo GetCacheRoundPlayerBattleData(int RoundIndex, uint64 PlayerUID, uint32_t PlayerKey); // Offset: 0x1022afeb8 // Return & Params: Num(4) Size(0x78)

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.GetCacheRoundBattleData
	// Flags: [Final|Native|Protected]
	struct FRuntimeCacheRoundBattleDataInfo GetCacheRoundBattleData(int RoundIndex); // Offset: 0x1022afe24 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.GetAllRoundPlayerBattleData
	// Flags: [Final|Native|Protected]
	struct FRuntimePlayerBattleDataInfo GetAllRoundPlayerBattleData(uint64 PlayerUID, uint32_t PlayerKey); // Offset: 0x1022afd30 // Return & Params: Num(3) Size(0x70)

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.CacheCurRoundBattleData
	// Flags: [Final|Native|Protected]
	void CacheCurRoundBattleData(int RoundIndex); // Offset: 0x1022afcb4 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Creative.CreativeSceneQueryManager
// Size: 0x228 // Inherited bytes: 0x110
struct UCreativeSceneQueryManager : UCreativeModeManagerBase {
	// Fields
	struct FCreativeReplicatedDataContainer ReplicatedDataContainer; // Offset: 0x110 // Size: 0xc8
	struct TMap<struct FString, struct FCreativeReplicatedObjectsInfo> MapReplicatedObjects; // Offset: 0x1d8 // Size: 0x50

	// Functions

	// Object Name: Function Creative.CreativeSceneQueryManager.RemoveReplicateObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveReplicateObject(struct FString InstanceID, struct UObject* Object); // Offset: 0x1022b15cc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativeSceneQueryManager.RemoveReplicateData
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveReplicateData(struct FString InstanceID); // Offset: 0x1022b1510 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeSceneQueryManager.OnReceivePreReplicateDataRemove
	// Flags: [Event|Public|BlueprintEvent]
	void OnReceivePreReplicateDataRemove(struct FString ID); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeSceneQueryManager.OnReceivePostReplicateDataChange
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void OnReceivePostReplicateDataChange(struct FString ID, struct TArray<struct UObject*>& Objects); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeSceneQueryManager.OnReceivePostReplicateDataAdd
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void OnReceivePostReplicateDataAdd(struct FString ID, struct TArray<struct UObject*>& Objects); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeSceneQueryManager.GetReplicatedObjects
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct UObject*> GetReplicatedObjects(struct FString InstanceID); // Offset: 0x1022b141c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeSceneQueryManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeSceneQueryManager* Get(struct UObject* WorldContext); // Offset: 0x1022b13a0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeSceneQueryManager.AddReplicateObjectPostDeferred
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void AddReplicateObjectPostDeferred(struct FString InstanceID, struct FTransform SpawnTransform, struct UObject* ReplicatedObject); // Offset: 0x1022b123c // Return & Params: Num(3) Size(0x48)

	// Object Name: Function Creative.CreativeSceneQueryManager.AddReplicateObjectDeferred
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	struct UObject* AddReplicateObjectDeferred(struct FString InstanceID, struct UObject* ObjectClass, struct FString Name, struct FTransform SpawnTransform, enum class ESpawnActorCollisionHandlingMethod CollisionHandlingOverride); // Offset: 0x1022b100c // Return & Params: Num(6) Size(0x70)

	// Object Name: Function Creative.CreativeSceneQueryManager.AddReplicateObject
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	struct UObject* AddReplicateObject(struct FString InstanceID, struct UObject* ObjectClass, struct FString Name, struct FTransform SpawnTransform, enum class ESpawnActorCollisionHandlingMethod CollisionHandlingOverride); // Offset: 0x1022b0ddc // Return & Params: Num(6) Size(0x70)
};

// Object Name: Class Creative.CreativeModeSoftComponentManager
// Size: 0x160 // Inherited bytes: 0x110
struct UCreativeModeSoftComponentManager : UCreativeModeManagerBase {
	// Fields
	char pad_0x110[0x50]; // Offset: 0x110 // Size: 0x50

	// Functions

	// Object Name: Function Creative.CreativeModeSoftComponentManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeSoftComponentManager* Get(struct UObject* WorldContext); // Offset: 0x1022b1a64 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Creative.CreativeStaticMeshComponent
// Size: 0x910 // Inherited bytes: 0x900
struct UCreativeStaticMeshComponent : UStaticMeshComponent {
	// Fields
	char pad_0x900[0x10]; // Offset: 0x900 // Size: 0x10

	// Functions

	// Object Name: Function Creative.CreativeStaticMeshComponent.OnReturnToPool
	// Flags: [Native|Public]
	void OnReturnToPool(struct UObject* NewOuter, uint32_t RecycledSeq); // Offset: 0x1022b1d18 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Creative.CreativeStaticMeshComponent.OnPickFromPool
	// Flags: [Native|Public]
	void OnPickFromPool(struct UObject* NewOuter, struct FString InName); // Offset: 0x1022b1c3c // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Creative.CreativeModeStreamingManager
// Size: 0x340 // Inherited bytes: 0x110
struct UCreativeModeStreamingManager : UCreativeModeManagerBase {
	// Fields
	bool bStreamingManagerEnable; // Offset: 0x110 // Size: 0x01
	bool bStreamingStateCheckStartup; // Offset: 0x111 // Size: 0x01
	bool bUseChildThreads; // Offset: 0x112 // Size: 0x01
	char pad_0x113[0x1]; // Offset: 0x113 // Size: 0x01
	float StreamingTickFrequency; // Offset: 0x114 // Size: 0x04
	float DestroyExtendDistance; // Offset: 0x118 // Size: 0x04
	float DelayDestroyTime; // Offset: 0x11c // Size: 0x04
	float NeedTickStreamingDistanceScale; // Offset: 0x120 // Size: 0x04
	bool ChildThreadsReduceTickFrequency; // Offset: 0x124 // Size: 0x01
	char pad_0x125[0x43]; // Offset: 0x125 // Size: 0x43
	struct TMap<struct FString, struct FCreativeModeStreamingParameters> ObjectStreamingStateMap; // Offset: 0x168 // Size: 0x50
	struct TArray<struct FString> ObjectStreamingStateKeyList; // Offset: 0x1b8 // Size: 0x10
	struct TMap<struct FString, bool> ObjectSpawnStateChangeMaps; // Offset: 0x1c8 // Size: 0x50
	char pad_0x218[0x50]; // Offset: 0x218 // Size: 0x50
	struct TArray<struct AActor*> OuterStreamingSources; // Offset: 0x268 // Size: 0x10
	char pad_0x278[0xc8]; // Offset: 0x278 // Size: 0xc8

	// Functions

	// Object Name: Function Creative.CreativeModeStreamingManager.StreamingManagerEnable
	// Flags: [Final|Native|Public]
	bool StreamingManagerEnable(); // Offset: 0x1022b27a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeStreamingManager.RemoveStreamingObject
	// Flags: [Final|Native|Public]
	bool RemoveStreamingObject(struct FString InstanceID); // Offset: 0x1022b26d8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeStreamingManager.GetOnGridCellIndex
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	struct FIntVector GetOnGridCellIndex(struct FString GridName, struct FVector& Location); // Offset: 0x1022b25d8 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Creative.CreativeModeStreamingManager.GetGridLoadingRange
	// Flags: [Final|Native|Public]
	float GetGridLoadingRange(struct FString GridName); // Offset: 0x1022b2530 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Creative.CreativeModeStreamingManager.GetGridList
	// Flags: [Final|Native|Public]
	struct TArray<struct FString> GetGridList(); // Offset: 0x1022b24cc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeStreamingManager.GetGridCellWidthHeight
	// Flags: [Final|Native|Public|HasDefaults]
	struct FVector2D GetGridCellWidthHeight(struct FString GridName); // Offset: 0x1022b2420 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativeModeStreamingManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeStreamingManager* Get(struct UObject* WorldContext); // Offset: 0x1022b23a4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeStreamingManager.ChangeStreamingObjectStreamingType
	// Flags: [Final|Native|Public]
	enum class ECreativeModeActorStreamingType ChangeStreamingObjectStreamingType(struct FString InstanceID, enum class ECreativeModeActorStreamingType NewStremaingType); // Offset: 0x1022b2298 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Creative.CreativeModeStreamingManager.AddStreamingObject
	// Flags: [Final|Native|Public]
	bool AddStreamingObject(struct FString InstanceID, struct FCreativeModeStreamingParameters StreamingParameters); // Offset: 0x1022b2188 // Return & Params: Num(3) Size(0x13)
};

// Object Name: Class Creative.CreativeWorldSubSystem
// Size: 0x40 // Inherited bytes: 0x30
struct UCreativeWorldSubSystem : UWorldSubsystem {
	// Fields
	struct AActor* ManagerCenter; // Offset: 0x30 // Size: 0x08
	struct AActor* PhysicsBatchActor; // Offset: 0x38 // Size: 0x08

	// Functions

	// Object Name: Function Creative.CreativeWorldSubSystem.GetPhysicsBatchActor
	// Flags: [Final|Native|Public]
	struct AActor* GetPhysicsBatchActor(); // Offset: 0x1022b2ccc // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Creative.GameModeStateActive_CreativeMode
// Size: 0xc8 // Inherited bytes: 0xc8
struct UGameModeStateActive_CreativeMode : UGameModeStateActive {
};

// Object Name: Class Creative.GameModeStateFighting_CreativeMode
// Size: 0xd8 // Inherited bytes: 0xd8
struct UGameModeStateFighting_CreativeMode : UGameModeStateFightingTeam {
};

// Object Name: Class Creative.GameModeStateFinished_CreativeMode
// Size: 0xc0 // Inherited bytes: 0xc0
struct UGameModeStateFinished_CreativeMode : UGameModeStateFinishedTeam {
};

// Object Name: Class Creative.GameModeStateReady_CreativeMode
// Size: 0x110 // Inherited bytes: 0x110
struct UGameModeStateReady_CreativeMode : UGameModeStateReady {
};

// Object Name: Class Creative.SoftStaticMeshComponent
// Size: 0x930 // Inherited bytes: 0x900
struct USoftStaticMeshComponent : UStaticMeshComponent {
	// Fields
	struct UStaticMesh* SoftStaticMesh; // Offset: 0x8f8 // Size: 0x28
	char bAsyncLoad : 1; // Offset: 0x920 // Size: 0x01
	char pad_0x928_1 : 7; // Offset: 0x928 // Size: 0x01
	char pad_0x929[0x7]; // Offset: 0x929 // Size: 0x07

	// Functions

	// Object Name: Function Creative.SoftStaticMeshComponent.SetSoftStaticMeshAsync
	// Flags: [Native|Public|BlueprintCallable]
	bool SetSoftStaticMeshAsync(struct UStaticMesh* NewMesh); // Offset: 0x1022b3558 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Creative.SoftStaticMeshComponent.SetSoftStaticMesh
	// Flags: [Native|Public|BlueprintCallable]
	bool SetSoftStaticMesh(struct UStaticMesh* NewMesh, bool bSetStaticMesh); // Offset: 0x1022b3480 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function Creative.SoftStaticMeshComponent.OnClientAsyncLoaded
	// Flags: [Final|Native|Public|HasDefaults]
	void OnClientAsyncLoaded(struct FSoftObjectPath SoftObjectPath); // Offset: 0x1022b33b4 // Return & Params: Num(1) Size(0x18)
};

