//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SocialCardDate_type.BP_STRUCT_SocialCardDate_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_SocialCardDate_type {
	// Fields
	struct FString Date_0_28B039C03A0BED89791588A502B13BA5; // Offset: 0x00 // Size: 0x10
	int ID_1_72C45D802E3B21C6496F24DD0302B144; // Offset: 0x10 // Size: 0x04
};

