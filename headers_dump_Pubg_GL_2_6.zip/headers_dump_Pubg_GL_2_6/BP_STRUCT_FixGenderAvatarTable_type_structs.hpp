//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_FixGenderAvatarTable_type.BP_STRUCT_FixGenderAvatarTable_type
// Size: 0x08 // Inherited bytes: 0x00
struct FBP_STRUCT_FixGenderAvatarTable_type {
	// Fields
	int Gender_0_02824B8007FFB1E6643123C30A81AC12; // Offset: 0x00 // Size: 0x04
	int ID_1_35A6F98026F142FC587E00F40BE6DA84; // Offset: 0x04 // Size: 0x04
};

