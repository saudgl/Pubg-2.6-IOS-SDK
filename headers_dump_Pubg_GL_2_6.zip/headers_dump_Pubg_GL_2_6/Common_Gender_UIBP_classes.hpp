//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Common_Gender_UIBP.Common_Gender_UIBP_C
// Size: 0x2f0 // Inherited bytes: 0x2d0
struct UCommon_Gender_UIBP_C : ULuaUserWidget {
	// Fields
	struct UCommon_Gender_Female_C* Common_Gender_Female; // Offset: 0x2d0 // Size: 0x08
	struct UCommon_Gender_Male_C* Common_Gender_Male; // Offset: 0x2d8 // Size: 0x08
	struct USizeBox* SizeBox_1; // Offset: 0x2e0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_1; // Offset: 0x2e8 // Size: 0x08
};

