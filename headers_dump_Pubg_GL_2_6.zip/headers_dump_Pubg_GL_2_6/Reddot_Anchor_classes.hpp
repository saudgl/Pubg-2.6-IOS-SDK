//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Reddot_Anchor.Reddot_Anchor_C
// Size: 0x2dc // Inherited bytes: 0x2d0
struct UReddot_Anchor_C : ULuaUserWidget {
	// Fields
	struct UCanvasPanel* CanvasPanel_Anchor; // Offset: 0x2d0 // Size: 0x08
	int PosTemplate; // Offset: 0x2d8 // Size: 0x04
};

