//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct ShaderCore.MapRenderConfig
// Size: 0x98 // Inherited bytes: 0x00
struct FMapRenderConfig {
	// Fields
	struct FName ConfigName; // Offset: 0x00 // Size: 0x08
	struct FName MapName; // Offset: 0x08 // Size: 0x08
	struct TArray<struct FName> LevelNames; // Offset: 0x10 // Size: 0x10
	struct FOverrideRenderConfig OverrideRenderConfig; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FRenderConfig RenderConfig; // Offset: 0x28 // Size: 0x70
};

// Object Name: ScriptStruct ShaderCore.RenderConfig
// Size: 0x70 // Inherited bytes: 0x00
struct FRenderConfig {
	// Fields
	struct FName FormatName; // Offset: 0x00 // Size: 0x08
	struct FName FeatureLevel; // Offset: 0x08 // Size: 0x08
	int QualityType; // Offset: 0x10 // Size: 0x04
	int UserQualitySetting; // Offset: 0x14 // Size: 0x04
	struct FName MaterialQualityLevel; // Offset: 0x18 // Size: 0x08
	int PUBGLDR; // Offset: 0x20 // Size: 0x04
	int MobileHDR; // Offset: 0x24 // Size: 0x04
	int MobileSimplerShader; // Offset: 0x28 // Size: 0x04
	int ShadowQuality; // Offset: 0x2c // Size: 0x04
	int MaxCSMShadowResolution; // Offset: 0x30 // Size: 0x04
	int MobileEnableHardwarePCF; // Offset: 0x34 // Size: 0x04
	int MobileEnableIBL; // Offset: 0x38 // Size: 0x04
	int MobileEarlyZPass; // Offset: 0x3c // Size: 0x04
	int MobileEnableEarlyZDepthBias; // Offset: 0x40 // Size: 0x04
	int MobileUseAlphaToCoverage; // Offset: 0x44 // Size: 0x04
	int MobileBypassTranslucentMaterialPointLight; // Offset: 0x48 // Size: 0x04
	int MobileMSAA; // Offset: 0x4c // Size: 0x04
	int AllowStaticLighting; // Offset: 0x50 // Size: 0x04
	int SupportAllShaderPermutations; // Offset: 0x54 // Size: 0x04
	int SupportLowQualityLightmaps; // Offset: 0x58 // Size: 0x04
	int MobileEnableVertexPointLight; // Offset: 0x5c // Size: 0x04
	int MobileFallbackMSAAToFXAA; // Offset: 0x60 // Size: 0x04
	int IndirectLightingCache; // Offset: 0x64 // Size: 0x04
	int MobileNumDynamicPointLights; // Offset: 0x68 // Size: 0x04
	bool RHISupportsTexLod; // Offset: 0x6c // Size: 0x01
	bool RHISupportsHardwarePCF; // Offset: 0x6d // Size: 0x01
	char pad_0x6E[0x2]; // Offset: 0x6e // Size: 0x02
};

// Object Name: ScriptStruct ShaderCore.OverrideRenderConfig
// Size: 0x04 // Inherited bytes: 0x00
struct FOverrideRenderConfig {
	// Fields
	char bFormatName : 1; // Offset: 0x00 // Size: 0x01
	char bFeatureLevel : 1; // Offset: 0x00 // Size: 0x01
	char bQualityType : 1; // Offset: 0x00 // Size: 0x01
	char bUserQualitySetting : 1; // Offset: 0x00 // Size: 0x01
	char bMaterialQualityLevel : 1; // Offset: 0x00 // Size: 0x01
	char bPUBGLDR : 1; // Offset: 0x00 // Size: 0x01
	char bMobileHDR : 1; // Offset: 0x00 // Size: 0x01
	char bMobileSimplerShader : 1; // Offset: 0x00 // Size: 0x01
	char bShadowQuality : 1; // Offset: 0x01 // Size: 0x01
	char bMaxCSMShadowResolution : 1; // Offset: 0x01 // Size: 0x01
	char bMobileEnableHardwarePCF : 1; // Offset: 0x01 // Size: 0x01
	char bMobileEnableIBL : 1; // Offset: 0x01 // Size: 0x01
	char bMobileEarlyZPass : 1; // Offset: 0x01 // Size: 0x01
	char bMobileEnableEarlyZDepthBias : 1; // Offset: 0x01 // Size: 0x01
	char bMobileUseAlphaToCoverage : 1; // Offset: 0x01 // Size: 0x01
	char bMobileBypassTranslucentMaterialPointLight : 1; // Offset: 0x01 // Size: 0x01
	char bMobileMSAA : 1; // Offset: 0x02 // Size: 0x01
	char bAllowStaticLighting : 1; // Offset: 0x02 // Size: 0x01
	char bSupportAllShaderPermutations : 1; // Offset: 0x02 // Size: 0x01
	char bSupportLowQualityLightmaps : 1; // Offset: 0x02 // Size: 0x01
	char bMobileEnableVertexPointLight : 1; // Offset: 0x02 // Size: 0x01
	char bMobileFallbackMSAAToFXAA : 1; // Offset: 0x02 // Size: 0x01
	char bIndirectLightingCache : 1; // Offset: 0x02 // Size: 0x01
	char bMobileNumDynamicPointLights : 1; // Offset: 0x02 // Size: 0x01
	char bRHISupportsTexLod : 1; // Offset: 0x03 // Size: 0x01
	char bRHISupportsHardwarePCF : 1; // Offset: 0x03 // Size: 0x01
	char pad_0x3_2 : 6; // Offset: 0x03 // Size: 0x01
};

// Object Name: ScriptStruct ShaderCore.DeviceRenderConfig
// Size: 0x78 // Inherited bytes: 0x00
struct FDeviceRenderConfig {
	// Fields
	struct FName ConfigName; // Offset: 0x00 // Size: 0x08
	struct FRenderConfig RenderConfig; // Offset: 0x08 // Size: 0x70
};

// Object Name: ScriptStruct ShaderCore.CollectSwitchs
// Size: 0x0d // Inherited bytes: 0x00
struct FCollectSwitchs {
	// Fields
	bool LevelStaticMeshMobile; // Offset: 0x00 // Size: 0x01
	bool LevelStaticMeshShadowDepth; // Offset: 0x01 // Size: 0x01
	bool LevelStaticMeshDepth; // Offset: 0x02 // Size: 0x01
	bool SkeletalMeshMobile; // Offset: 0x03 // Size: 0x01
	bool SkeletalMeshShadowDepth; // Offset: 0x04 // Size: 0x01
	bool SkeletalMeshDepth; // Offset: 0x05 // Size: 0x01
	bool ParticleSpriteMobile; // Offset: 0x06 // Size: 0x01
	bool MeshParticleMobile; // Offset: 0x07 // Size: 0x01
	bool LandscapeMobile; // Offset: 0x08 // Size: 0x01
	bool LandscapeShadowDepth; // Offset: 0x09 // Size: 0x01
	bool LandscapeDepth; // Offset: 0x0a // Size: 0x01
	bool SlateDefaultBase; // Offset: 0x0b // Size: 0x01
	bool SlateFontBase; // Offset: 0x0c // Size: 0x01
};

// Object Name: ScriptStruct ShaderCore.ShaderGroupDesc
// Size: 0x40 // Inherited bytes: 0x00
struct FShaderGroupDesc {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct FString Name; // Offset: 0x08 // Size: 0x10
	struct FString Parent; // Offset: 0x18 // Size: 0x10
	char pad_0x28[0x18]; // Offset: 0x28 // Size: 0x18
};

// Object Name: ScriptStruct ShaderCore.ShaderPak
// Size: 0x60 // Inherited bytes: 0x40
struct FShaderPak : FShaderGroupDesc {
	// Fields
	struct TArray<struct FString> Include; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FString> Exclude; // Offset: 0x50 // Size: 0x10
};

// Object Name: ScriptStruct ShaderCore.ShaderLevel
// Size: 0x60 // Inherited bytes: 0x40
struct FShaderLevel : FShaderGroupDesc {
	// Fields
	struct TArray<struct FString> Include; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FString> Quality; // Offset: 0x50 // Size: 0x10
};

