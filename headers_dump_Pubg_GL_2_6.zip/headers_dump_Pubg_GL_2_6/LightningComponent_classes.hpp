//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class LightningComponent.LightningActor
// Size: 0x3f8 // Inherited bytes: 0x3f0
struct ALightningActor : AActor {
	// Fields
	struct ULightningComponent* LightningComponent; // Offset: 0x3f0 // Size: 0x08
};

// Object Name: Class LightningComponent.LightningComponent
// Size: 0x850 // Inherited bytes: 0x790
struct ULightningComponent : UMeshComponent {
	// Fields
	int MaxFractalTime; // Offset: 0x790 // Size: 0x04
	int PatternMask; // Offset: 0x794 // Size: 0x04
	float LightningWidth; // Offset: 0x798 // Size: 0x04
	float WidthDecay; // Offset: 0x79c // Size: 0x04
	float BrightnessDecay; // Offset: 0x7a0 // Size: 0x04
	bool bShrinkWidth; // Offset: 0x7a4 // Size: 0x01
	char pad_0x7A5[0x3]; // Offset: 0x7a5 // Size: 0x03
	int AtlasNum; // Offset: 0x7a8 // Size: 0x04
	struct FVector SeedStart; // Offset: 0x7ac // Size: 0x0c
	struct FVector SeedEnd; // Offset: 0x7b8 // Size: 0x0c
	struct FVector2D ZigZagFraction; // Offset: 0x7c4 // Size: 0x08
	struct FVector2D ZigZagDeviationRight; // Offset: 0x7cc // Size: 0x08
	struct FVector2D ZigZagDeviationUp; // Offset: 0x7d4 // Size: 0x08
	float ZigZagDeviationDecay; // Offset: 0x7dc // Size: 0x04
	struct FVector2D ForkFraction; // Offset: 0x7e0 // Size: 0x08
	struct FVector2D ForkZigZagDeviationRight; // Offset: 0x7e8 // Size: 0x08
	struct FVector2D ForkZigZagDeviationUp; // Offset: 0x7f0 // Size: 0x08
	float ForkZigZagDeviationDecay; // Offset: 0x7f8 // Size: 0x04
	struct FVector2D ForkDeviationRight; // Offset: 0x7fc // Size: 0x08
	struct FVector2D ForkDeviationUp; // Offset: 0x804 // Size: 0x08
	struct FVector2D ForkDeviationForward; // Offset: 0x80c // Size: 0x08
	float ForkDeviationDecay; // Offset: 0x814 // Size: 0x04
	struct FVector2D ForkLength; // Offset: 0x818 // Size: 0x08
	float ForkLengthDecay; // Offset: 0x820 // Size: 0x04
	char pad_0x824[0x2c]; // Offset: 0x824 // Size: 0x2c

	// Functions

	// Object Name: Function LightningComponent.LightningComponent.SetWidthDecay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWidthDecay(float InDecay); // Offset: 0x102782cf4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.SetShrinkWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetShrinkWidth(bool InBool); // Offset: 0x102782c70 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LightningComponent.LightningComponent.SetPatternMask
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPatternMask(int InPatternMask); // Offset: 0x102782bf4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.SetMaxFractalTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxFractalTime(int InMaxFractalTime); // Offset: 0x102782b78 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.SetLightningWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLightningWidth(float InWidth); // Offset: 0x102782afc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.SetBrightnessDecay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrightnessDecay(float InDecay); // Offset: 0x102782a80 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.SetAtlasNum
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAtlasNum(int InVal); // Offset: 0x102782a04 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.RefreshLightningMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshLightningMesh(); // Offset: 0x1027829f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LightningComponent.LightningComponent.IsShrinkWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsShrinkWidth(); // Offset: 0x1027829d4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LightningComponent.LightningComponent.GetWidthDecay
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetWidthDecay(); // Offset: 0x1027829b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.GetPatternMask
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetPatternMask(); // Offset: 0x10278299c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.GetMaxFractalTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetMaxFractalTime(); // Offset: 0x102782980 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.GetLightningWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetLightningWidth(); // Offset: 0x102782964 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.GetBrightnessDecay
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetBrightnessDecay(); // Offset: 0x102782948 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LightningComponent.LightningComponent.GetAtlasNum
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetAtlasNum(); // Offset: 0x102782928 // Return & Params: Num(1) Size(0x4)
};

