//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby20_Right_Business_Item01_UIBP.Lobby20_Right_Business_Item01_UIBP_C
// Size: 0x2d0 // Inherited bytes: 0x260
struct ULobby20_Right_Business_Item01_UIBP_C : UUserWidget {
	// Fields
	struct UButton* Button_1; // Offset: 0x260 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Discout; // Offset: 0x268 // Size: 0x08
	struct UImage* Image_7; // Offset: 0x270 // Size: 0x08
	struct UImage* Image_Banner; // Offset: 0x278 // Size: 0x08
	struct UImage* Image_New; // Offset: 0x280 // Size: 0x08
	struct UImage* Image_Quality; // Offset: 0x288 // Size: 0x08
	struct UTextBlock* TextBlock1; // Offset: 0x290 // Size: 0x08
	struct UTextBlock* TextBlock2; // Offset: 0x298 // Size: 0x08
	struct UTextBlock* TextBlock3; // Offset: 0x2a0 // Size: 0x08
	struct UTextBlock* TextBlock_Name; // Offset: 0x2a8 // Size: 0x08
	struct UTextBlock* TextBlock_Price; // Offset: 0x2b0 // Size: 0x08
	struct UTextBlock* TextBlock_Price_Discout; // Offset: 0x2b8 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_2; // Offset: 0x2c0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Entrance; // Offset: 0x2c8 // Size: 0x08
};

