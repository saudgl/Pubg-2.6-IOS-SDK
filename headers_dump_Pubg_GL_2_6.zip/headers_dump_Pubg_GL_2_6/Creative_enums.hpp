//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum Creative.ECreativeModeActorState
enum class ECreativeModeActorState : uint8 {
	CreativeModeActorState_Unknown = 0,
	CreativeModeActorState_Prefab = 1,
	CreativeModeActorState_Instance = 2,
	CreativeModeActorState_MAX = 3
};

// Object Name: Enum Creative.ECreativeModePlayState
enum class ECreativeModePlayState : uint8 {
	CreativeModePlayState_None = 0,
	CreativeModePlayState_Ready = 1,
	CreativeModePlayState_Fighting = 2,
	CreativeModePlayState_Finish = 3,
	CreativeModePlayState_Max = 4
};

// Object Name: Enum Creative.ECreativeModeActorStreamingType
enum class ECreativeModeActorStreamingType : uint8 {
	CreativeModeActorStreamingType_AlwaysLoad = 0,
	CreativeModeActorStreamingType_Grid = 1,
	CreativeModeActorStreamingType_MAX = 2
};

// Object Name: Enum Creative.ECreativeModeGameType
enum class ECreativeModeGameType : uint8 {
	CreativeModeGameType_None = 0,
	CreativeModeGameType_Editor = 1,
	CreativeModeGameType_Game = 2,
	CreativeModeGameType_Max = 3
};

