//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: AnimBlueprintGeneratedClass wingmanAnimationBP_DT.wingmanAnimationBP_DT_C
// Size: 0x500 // Inherited bytes: 0x3c0
struct UwingmanAnimationBP_DT_C : UAnimInstance {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3c0 // Size: 0x08
	struct FAnimNode_Root AnimGraphNode_Root_2C92ABEF44108DF4306768A9A8900956; // Offset: 0x3c8 // Size: 0x50
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_94AB669544B9B14331BD1DBCC1F1B588; // Offset: 0x418 // Size: 0x70
	struct FAnimNode_Slot AnimGraphNode_Slot_8CFE89D84A15090307F81DAECC426213; // Offset: 0x488 // Size: 0x70
	struct UAnimMontage* NewVar_1; // Offset: 0x4f8 // Size: 0x08

	// Functions

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.BlueprintBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void BlueprintBeginPlay(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.ExecuteUbergraph_wingmanAnimationBP_DT
	// Flags: [None]
	void ExecuteUbergraph_wingmanAnimationBP_DT(int EntryPoint); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)
};

