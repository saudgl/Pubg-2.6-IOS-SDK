//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BattleItemHandle_MeleeWeapon.BattleItemHandle_MeleeWeapon_C
// Size: 0x6f1 // Inherited bytes: 0x6f1
struct UBattleItemHandle_MeleeWeapon_C : UBattleItemHandle_Pistol_C {
	// Functions

	// Object Name: Function BattleItemHandle_MeleeWeapon.BattleItemHandle_MeleeWeapon_C.GetSkillTemplates
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	struct TArray<struct FItemSkillsConfig> GetSkillTemplates(); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BattleItemHandle_MeleeWeapon.BattleItemHandle_MeleeWeapon_C.HandleUse
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool HandleUse(struct FBattleItemUseTarget Target, enum class EBattleItemUseReason Reason); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x2a)
};

