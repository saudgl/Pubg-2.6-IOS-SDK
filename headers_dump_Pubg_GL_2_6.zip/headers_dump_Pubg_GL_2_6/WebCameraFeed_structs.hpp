//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct WebCameraFeed.WebCameraDeviceId
// Size: 0x04 // Inherited bytes: 0x00
struct FWebCameraDeviceId {
	// Fields
	int selectedDevice; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct WebCameraFeed.VideoDevice
// Size: 0x50 // Inherited bytes: 0x00
struct FVideoDevice {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct WebCameraFeed.VideoFormat
// Size: 0x20 // Inherited bytes: 0x00
struct FVideoFormat {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

