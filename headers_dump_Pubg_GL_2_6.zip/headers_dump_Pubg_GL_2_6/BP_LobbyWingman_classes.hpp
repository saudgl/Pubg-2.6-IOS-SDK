//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_LobbyWingman.BP_LobbyWingman_C
// Size: 0x4e4 // Inherited bytes: 0x4c0
struct ABP_LobbyWingman_C : ASTExtraLobbyWingman {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4c0 // Size: 0x08
	struct UWingmanAvatarComp_BP_C* WingmanAvatarComp_BP; // Offset: 0x4c8 // Size: 0x08
	float invincible; // Offset: 0x4d0 // Size: 0x04
	float Freq; // Offset: 0x4d4 // Size: 0x04
	float Speed; // Offset: 0x4d8 // Size: 0x04
	bool isNeedUpdate; // Offset: 0x4dc // Size: 0x01
	char pad_0x4DD[0x3]; // Offset: 0x4dd // Size: 0x03
	int ShowType; // Offset: 0x4e0 // Size: 0x04

	// Functions

	// Object Name: Function BP_LobbyWingman.BP_LobbyWingman_C.SetHighLight
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetHighLight(float invincible, float Freq, float Speed); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function BP_LobbyWingman.BP_LobbyWingman_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyWingman.BP_LobbyWingman_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyWingman.BP_LobbyWingman_C.WingmanAvatarEqiuped_Event_1
	// Flags: [BlueprintCallable|BlueprintEvent]
	void WingmanAvatarEqiuped_Event_1(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyWingman.BP_LobbyWingman_C.ExecuteUbergraph_BP_LobbyWingman
	// Flags: [None]
	void ExecuteUbergraph_BP_LobbyWingman(int EntryPoint); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)
};

