//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class HiggsBoson.ClientGlueHiaSystem
// Size: 0x210 // Inherited bytes: 0x30
struct UClientGlueHiaSystem : UWorldSubsystem {
	// Fields
	char pad_0x30[0x1d4]; // Offset: 0x30 // Size: 0x1d4
	int ParamWall01; // Offset: 0x204 // Size: 0x04
	char pad_0x208[0x8]; // Offset: 0x208 // Size: 0x08

	// Functions

	// Object Name: Function HiggsBoson.ClientGlueHiaSystem.SetGameModeMoveSpeedModifier
	// Flags: [Final|Native|Private]
	void SetGameModeMoveSpeedModifier(float Value); // Offset: 0x103e6f0f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HiggsBoson.ClientGlueHiaSystem.IsTimeNearInvalidMoveState
	// Flags: [Final|Native|Private|Const]
	bool IsTimeNearInvalidMoveState(struct AActor* CharacterPtr, float TimeInSeconds, float MarginInSeconds); // Offset: 0x103e6eff8 // Return & Params: Num(4) Size(0x11)

	// Object Name: Function HiggsBoson.ClientGlueHiaSystem.IsGMCheatingSpeed
	// Flags: [Final|Native|Private]
	bool IsGMCheatingSpeed(struct AActor* CharacterPtr); // Offset: 0x103e6ef6c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function HiggsBoson.ClientGlueHiaSystem.IsDuringFightingState
	// Flags: [Final|Native|Private]
	bool IsDuringFightingState(); // Offset: 0x103e6ef38 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HiggsBoson.ClientGlueHiaSystem.GetGameModeMoveSpeedModifier
	// Flags: [Final|Native|Private]
	float GetGameModeMoveSpeedModifier(); // Offset: 0x103e6ef04 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HiggsBoson.ClientGlueHiaSystem.GetGameModeMaxRunningMoveSpeed
	// Flags: [Final|Native|Private]
	float GetGameModeMaxRunningMoveSpeed(); // Offset: 0x103e6eed0 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class HiggsBoson.FuzzyObject
// Size: 0x350 // Inherited bytes: 0x28
struct UFuzzyObject : UObject {
	// Fields
	char pad_0x28[0x320]; // Offset: 0x28 // Size: 0x320
	int Param1; // Offset: 0x348 // Size: 0x04
	char pad_0x34C[0x4]; // Offset: 0x34c // Size: 0x04

	// Functions

	// Object Name: Function HiggsBoson.FuzzyObject.SetUInt8ValueByName
	// Flags: [Final|Native|Public]
	bool SetUInt8ValueByName(struct FString Name, char Value); // Offset: 0x103e71484 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function HiggsBoson.FuzzyObject.SetUInt64ValueByName
	// Flags: [Final|Native|Public]
	bool SetUInt64ValueByName(struct FString Name, uint64 Value); // Offset: 0x103e7139c // Return & Params: Num(3) Size(0x19)

	// Object Name: Function HiggsBoson.FuzzyObject.SetUInt32ValueByName
	// Flags: [Final|Native|Public]
	bool SetUInt32ValueByName(struct FString Name, uint32_t Value); // Offset: 0x103e712b4 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function HiggsBoson.FuzzyObject.SetUInt16ValueByName
	// Flags: [Final|Native|Public]
	bool SetUInt16ValueByName(struct FString Name, uint16_t Value); // Offset: 0x103e711cc // Return & Params: Num(3) Size(0x13)

	// Object Name: Function HiggsBoson.FuzzyObject.SetInt8ValueByName
	// Flags: [Final|Native|Public]
	bool SetInt8ValueByName(struct FString Name, uint8_t Value); // Offset: 0x103e710e4 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function HiggsBoson.FuzzyObject.SetInt64ValueByName
	// Flags: [Final|Native|Public]
	bool SetInt64ValueByName(struct FString Name, int64_t Value); // Offset: 0x103e70ffc // Return & Params: Num(3) Size(0x19)

	// Object Name: Function HiggsBoson.FuzzyObject.SetInt32ValueByName
	// Flags: [Final|Native|Public]
	bool SetInt32ValueByName(struct FString Name, int Value); // Offset: 0x103e70f14 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function HiggsBoson.FuzzyObject.SetInt16ValueByName
	// Flags: [Final|Native|Public]
	bool SetInt16ValueByName(struct FString Name, int16_t Value); // Offset: 0x103e70e2c // Return & Params: Num(3) Size(0x13)

	// Object Name: Function HiggsBoson.FuzzyObject.SetFloatValueByName
	// Flags: [Final|Native|Public]
	bool SetFloatValueByName(struct FString Name, float Value); // Offset: 0x103e70d44 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function HiggsBoson.FuzzyObject.SetBoolValueByName
	// Flags: [Final|Native|Public]
	bool SetBoolValueByName(struct FString Name, bool Value); // Offset: 0x103e70c54 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function HiggsBoson.FuzzyObject.GetUInt8ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetUInt8ValueByName(struct FString Name, char& OutValue); // Offset: 0x103e70b5c // Return & Params: Num(3) Size(0x12)

	// Object Name: Function HiggsBoson.FuzzyObject.GetUInt64ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetUInt64ValueByName(struct FString Name, uint64& OutValue); // Offset: 0x103e70a64 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function HiggsBoson.FuzzyObject.GetUInt32ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetUInt32ValueByName(struct FString Name, uint32_t& OutValue); // Offset: 0x103e7096c // Return & Params: Num(3) Size(0x15)

	// Object Name: Function HiggsBoson.FuzzyObject.GetUInt16ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetUInt16ValueByName(struct FString Name, uint16_t& OutValue); // Offset: 0x103e70874 // Return & Params: Num(3) Size(0x13)

	// Object Name: Function HiggsBoson.FuzzyObject.GetInt8ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetInt8ValueByName(struct FString Name, uint8_t& OutValue); // Offset: 0x103e7077c // Return & Params: Num(3) Size(0x12)

	// Object Name: Function HiggsBoson.FuzzyObject.GetInt64ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetInt64ValueByName(struct FString Name, int64_t& OutValue); // Offset: 0x103e70684 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function HiggsBoson.FuzzyObject.GetInt32ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetInt32ValueByName(struct FString Name, int& OutValue); // Offset: 0x103e7058c // Return & Params: Num(3) Size(0x15)

	// Object Name: Function HiggsBoson.FuzzyObject.GetInt16ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetInt16ValueByName(struct FString Name, int16_t& OutValue); // Offset: 0x103e70494 // Return & Params: Num(3) Size(0x13)

	// Object Name: Function HiggsBoson.FuzzyObject.GetFloatValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetFloatValueByName(struct FString Name, float& OutValue); // Offset: 0x103e7039c // Return & Params: Num(3) Size(0x15)

	// Object Name: Function HiggsBoson.FuzzyObject.GetBoolValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetBoolValueByName(struct FString Name, bool& OutValue); // Offset: 0x103e702a4 // Return & Params: Num(3) Size(0x12)
};

// Object Name: Class HiggsBoson.SCoronaClientData
// Size: 0x350 // Inherited bytes: 0x350
struct USCoronaClientData : UFuzzyObject {
};

// Object Name: Class HiggsBoson.CamoyoHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UCamoyoHelper : UObject {
	// Functions

	// Object Name: Function HiggsBoson.CamoyoHelper.MakeRectTu
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void MakeRectTu(DelegateProperty CamoyoRetDelegate, struct FString Filename, int Quality, bool bShowUI); // Offset: 0x103e72124 // Return & Params: Num(4) Size(0x25)

	// Object Name: Function HiggsBoson.CamoyoHelper.MakeMemPerform
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void MakeMemPerform(int InbOpen); // Offset: 0x103e720b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HiggsBoson.CamoyoHelper.MakeFitRectTu
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	void MakeFitRectTu(DelegateProperty CamoyoRetDelegate, struct FVector4 InCutParam, int InTuType, bool isShowUI); // Offset: 0x103e71f64 // Return & Params: Num(4) Size(0x25)
};

// Object Name: Class HiggsBoson.HiggsBosonComponent
// Size: 0xc18 // Inherited bytes: 0x1d8
struct UHiggsBosonComponent : ULuaActorComponent {
	// Fields
	char pad_0x1D8[0x1f]; // Offset: 0x1d8 // Size: 0x1f
	bool bOpenActorChannelErrorReport; // Offset: 0x1f7 // Size: 0x01
	char pad_0x1F8[0x100]; // Offset: 0x1f8 // Size: 0x100
	struct FString TraceData; // Offset: 0x2f8 // Size: 0x10
	struct FString GameTraceData; // Offset: 0x308 // Size: 0x10
	uint32_t HeartBreaks; // Offset: 0x318 // Size: 0x04
	char pad_0x31C[0x4]; // Offset: 0x31c // Size: 0x04
	struct FString HeartInfo; // Offset: 0x320 // Size: 0x10
	struct FScriptMulticastDelegate OnSwiftHawkDelegate; // Offset: 0x330 // Size: 0x10
	struct FScriptMulticastDelegate OnGlueHiaRayResult; // Offset: 0x340 // Size: 0x10
	struct ASTExtraBaseCharacter* CharacterOwner; // Offset: 0x350 // Size: 0x08
	struct ASTExtraPlayerController* PlayerController; // Offset: 0x358 // Size: 0x08
	bool bClientInfoReceived; // Offset: 0x360 // Size: 0x01
	char pad_0x361[0x7]; // Offset: 0x361 // Size: 0x07
	struct TArray<uint32_t> ClientInfoAsUInt32Array; // Offset: 0x368 // Size: 0x10
	struct TArray<char> IntegrityItemCheckResultAsBytes; // Offset: 0x378 // Size: 0x10
	char pad_0x388[0x40]; // Offset: 0x388 // Size: 0x40
	bool bRoofTouchActive; // Offset: 0x3c8 // Size: 0x01
	char pad_0x3C9[0xb]; // Offset: 0x3c9 // Size: 0x0b
	int RoofTouchStatus; // Offset: 0x3d4 // Size: 0x04
	char pad_0x3D8[0x748]; // Offset: 0x3d8 // Size: 0x748
	struct USCoronaClientData* SecurityCoronaLabClientDataPointer; // Offset: 0xb20 // Size: 0x08
	char pad_0xB28[0xe4]; // Offset: 0xb28 // Size: 0xe4
	float TouchScreenActiveTimeRatioThreshold; // Offset: 0xc0c // Size: 0x04
	char pad_0xC10[0x8]; // Offset: 0xc10 // Size: 0x08

	// Functions

	// Object Name: Function HiggsBoson.HiggsBosonComponent.UpdateFeiji
	// Flags: [Final|Net|NetReliableNative|Event|Private|NetClient|NetValidate]
	void UpdateFeiji(float Param1); // Offset: 0x103e74988 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.SyncServerParam
	// Flags: [Final|Native|Public]
	void SyncServerParam(bool Param1); // Offset: 0x103e74904 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.SwiftHawk
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void SwiftHawk(struct TArray<char> Hawks, uint32_t Magic); // Offset: 0x103e747f8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.ShowABCD
	// Flags: [Event|Public|BlueprintEvent]
	void ShowABCD(struct FString Message, bool bIsClientShowWindow, bool bIsServerReportRobot, bool bIsSimilarMessageReportOnlyOnce); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x13)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.SetSchemeForInitialize
	// Flags: [Final|Native|Public]
	void SetSchemeForInitialize(int Index, uint32_t VerifyLen, struct TArray<char> VerifyHashArray, struct TArray<struct FPatchPoint> PatchPointArray); // Offset: 0x103e745f8 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.SetSchemeForGet
	// Flags: [Final|Native|Public]
	void SetSchemeForGet(int Index, uint32_t VerifyLen, struct TArray<char> VerifyHashArray, struct TArray<struct FPatchPoint> PatchPointArray); // Offset: 0x103e743f8 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.ServerWheat
	// Flags: [Net|Native|Event|Public|NetServer|NetValidate]
	void ServerWheat(float Param1, float Param2, float param3, float Param4, float Param5, float Param6, float Param7, float Param8, float Param9); // Offset: 0x103e74164 // Return & Params: Num(9) Size(0x24)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.ServerPoPo
	// Flags: [Final|Native|Private|HasOutParms]
	void ServerPoPo(struct TArray<char>& Array); // Offset: 0x103e740bc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.RPC_ServerGlueHiaPark
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void RPC_ServerGlueHiaPark(uint8_t HeShui, struct TArray<char> GlueHiaParkArr, uint32_t HiaStatus, struct TArray<char> GlueArg, struct TArray<char> GlueHiaParkArr2, uint32_t HiaStatus2); // Offset: 0x103e73e7c // Return & Params: Num(6) Size(0x44)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.RPC_ServerCapbo
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void RPC_ServerCapbo(uint8_t BoCapC, uint8_t InBoType, struct TArray<char> BoDataArr); // Offset: 0x103e73d34 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.RPC_ClientCoronaLab
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	void RPC_ClientCoronaLab(char bAllSwitch, struct TArray<char> CoronaLab, uint32_t CoronaState); // Offset: 0x103e73be8 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnWeaponAimInput
	// Flags: [Final|Native|Public]
	void OnWeaponAimInput(float InDistToEnemy, float InYaw, float InPitch, float InRoll); // Offset: 0x103e73ac0 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnTouchInput
	// Flags: [Final|Native|Public]
	void OnTouchInput(float InYaw, float InPitch, float InRoll); // Offset: 0x103e739d0 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnStopFireEvent
	// Flags: [Final|Native|Public]
	void OnStopFireEvent(); // Offset: 0x103e739bc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnStartFireEvent
	// Flags: [Final|Native|Public]
	void OnStartFireEvent(); // Offset: 0x103e739a8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnSkillInteruptVisual
	// Flags: [Final|Native|Public]
	void OnSkillInteruptVisual(struct AActor* InTarget, struct AActor* InCauser); // Offset: 0x103e738f4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnSkillEndVisual
	// Flags: [Final|Native|Public]
	void OnSkillEndVisual(struct AActor* InTarget, struct AActor* InCauser); // Offset: 0x103e73840 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnSkillEndTrans
	// Flags: [Final|Native|Public]
	void OnSkillEndTrans(struct AActor* InTarget, struct AActor* InCauser); // Offset: 0x103e7378c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnSkillBeginVisual
	// Flags: [Final|Native|Public]
	void OnSkillBeginVisual(struct AActor* InTarget, struct AActor* InCauser); // Offset: 0x103e736d8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnSkillBeginTrans
	// Flags: [Final|Native|Public]
	void OnSkillBeginTrans(struct AActor* InTarget, struct AActor* InCauser); // Offset: 0x103e73624 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnPlayerScopeOut
	// Flags: [Final|Native|Public]
	void OnPlayerScopeOut(bool bBegan); // Offset: 0x103e735a0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnPlayerScopeIn
	// Flags: [Final|Native|Public]
	void OnPlayerScopeIn(bool bBegan); // Offset: 0x103e7351c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnMyPawnRespawn
	// Flags: [Final|Native|Public]
	void OnMyPawnRespawn(struct AUAEPlayerController* InPlayerController); // Offset: 0x103e734a0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnKillSomeOneEvent
	// Flags: [Final|Native|Public]
	void OnKillSomeOneEvent(struct AActor* InSomeOne); // Offset: 0x103e73424 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnGyroInput
	// Flags: [Final|Native|Public]
	void OnGyroInput(float InYaw, float InPitch, float InRoll); // Offset: 0x103e73334 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnClientAdjustPosition
	// Flags: [Final|Native|Public|HasDefaults]
	void OnClientAdjustPosition(struct FVector NewLoc, enum class ECharacterMoveDragReason Reason); // Offset: 0x103e7327c // Return & Params: Num(2) Size(0xd)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnCapboReturn
	// Flags: [Final|Native|Public|HasOutParms]
	void OnCapboReturn(int BoCapC, int InBoType, struct TArray<char>& RetData); // Offset: 0x103e7315c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnBulletImpactEvent
	// Flags: [Final|Native|Public|HasOutParms]
	void OnBulletImpactEvent(struct AActor* InCauser, struct FHitResult& InImpactResult); // Offset: 0x103e73058 // Return & Params: Num(2) Size(0xa0)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.HandleClientReconnect
	// Flags: [Final|Native|Public]
	void HandleClientReconnect(); // Offset: 0x103e73044 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.GetServerGuey
	// Flags: [Final|Native|Public|Const]
	float GetServerGuey(); // Offset: 0x103e73010 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.FlushGameEnd
	// Flags: [Final|Native|Public]
	void FlushGameEnd(); // Offset: 0x103e72ffc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.EnableTickEncrypt
	// Flags: [Final|Native|Public]
	void EnableTickEncrypt(); // Offset: 0x103e72fe8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.EnableEnhancedDynamicActors
	// Flags: [Final|Native|Public]
	void EnableEnhancedDynamicActors(int Index); // Offset: 0x103e72f6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.DispatchIntegrityCheckItem
	// Flags: [Final|Native|Public]
	void DispatchIntegrityCheckItem(uint32_t PlatID, uint32_t AreaID, uint32_t GameBits, uint32_t Index, int Offset, uint32_t Len, uint32_t Type); // Offset: 0x103e72d94 // Return & Params: Num(7) Size(0x1c)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.ControlRoofTouch
	// Flags: [Final|Native|Public]
	void ControlRoofTouch(int Switch); // Offset: 0x103e72d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.ClientSwiftHawkWithParams
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientSwiftHawkWithParams(struct TArray<char> Hawks); // Offset: 0x103e72c78 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.ClientSwiftHawk
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientSwiftHawk(char Type, int SequenceID); // Offset: 0x103e72bb8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.ClientReceiveEx
	// Flags: [Final|Net|Native|Event|Private|NetClient|NetValidate]
	void ClientReceiveEx(struct TArray<char> RPCConstArray); // Offset: 0x103e72af0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.ClientDoJT
	// Flags: [Final|Native|Public]
	void ClientDoJT(bool bDelayUntilShot); // Offset: 0x103e72a6c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class HiggsBoson.SecurityImprisonComp
// Size: 0x140 // Inherited bytes: 0x110
struct USecurityImprisonComp : UActorComponent {
	// Fields
	struct ASTExtraPlayerController* OwnerPC; // Offset: 0x110 // Size: 0x08
	struct ASTExtraBaseCharacter* CharacterWaitForOp; // Offset: 0x118 // Size: 0x08
	struct TArray<uint64> TeammateKillerUID; // Offset: 0x120 // Size: 0x10
	struct TArray<char> TeammateKillType; // Offset: 0x130 // Size: 0x10

	// Functions

	// Object Name: Function HiggsBoson.SecurityImprisonComp.ReleaseTeammate
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ReleaseTeammate(uint64 PlayerUID); // Offset: 0x103e770d8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HiggsBoson.SecurityImprisonComp.ImprisonmentUIUpdate
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	void ImprisonmentUIUpdate(uint64 PlayerUID, bool bIsImprison); // Offset: 0x103e76fd8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function HiggsBoson.SecurityImprisonComp.ImprisonmentTeammate
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ImprisonmentTeammate(uint64 PlayerUID, bool bIscomplaint); // Offset: 0x103e76ed8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function HiggsBoson.SecurityImprisonComp.ImprisonmentReport
	// Flags: [Final|Native|Public]
	void ImprisonmentReport(uint64 PlayerUID); // Offset: 0x103e76e5c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class HiggsBoson.TickAsTimer
// Size: 0x28 // Inherited bytes: 0x28
struct UTickAsTimer : UObject {
};

// Object Name: Class HiggsBoson.TimeConsuming
// Size: 0x28 // Inherited bytes: 0x28
struct UTimeConsuming : UObject {
};

