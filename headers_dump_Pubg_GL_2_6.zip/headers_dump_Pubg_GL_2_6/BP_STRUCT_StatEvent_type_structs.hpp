//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_StatEvent_type.BP_STRUCT_StatEvent_type
// Size: 0x25 // Inherited bytes: 0x00
struct FBP_STRUCT_StatEvent_type {
	// Fields
	struct FString adjustAndroidToken_0_594DE04070C173A163E4B64201910D0E; // Offset: 0x00 // Size: 0x10
	struct FString adjustIOSToken_1_0503AAC047B9A92166DF565B059ACF0E; // Offset: 0x10 // Size: 0x10
	int id_2_62C4604044EB8A891315D5090A0F46F4; // Offset: 0x20 // Size: 0x04
	bool unique_3_5DB792C063488FEF6239807407CF07F5; // Offset: 0x24 // Size: 0x01
};

