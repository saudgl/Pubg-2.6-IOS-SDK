//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C
// Size: 0xa50 // Inherited bytes: 0xa38
struct UVehicleAdvanceAvatarComp_BP_C : UVehicleAdvanceAvatarComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xa38 // Size: 0x08
	struct TArray<int> DefaultStyleIDList; // Offset: 0xa40 // Size: 0x10

	// Functions

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.GetReflectionCubeName_Lobby
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	struct FName GetReflectionCubeName_Lobby(); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.BPGetSlotMeshType
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	enum class EMeshType BPGetSlotMeshType(int InSlotID, int InSubSlotID, struct UItemHandleBase* InItemHandle); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x11)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.InitVehicleAvatarBySkinID_Old
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	bool InitVehicleAvatarBySkinID_Old(int InVehicleSkinID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.PutOffItemIDInLobby
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PutOffItemIDInLobby(int InItemID, bool& Result); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.PutOnItemIDInLobby
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PutOnItemIDInLobby(int InItemID, int ColorID, int PatternID, int Particle ID, bool& Result); // Offset: 0x1041acc2c // Return & Params: Num(5) Size(0x11)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.PutOffSlotInLobby
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void PutOffSlotInLobby(char InSlotType, bool& Result); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x2)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.BP_ProcessStyleUnequipped
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void BP_ProcessStyleUnequipped(int OldStyleID); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.Bp_ProcessAvatarLogicUnequipped
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Bp_ProcessAvatarLogicUnequipped(int SlotID, struct FItemDefineID OldItemID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.BP_ProcessStyleEquipped
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void BP_ProcessStyleEquipped(int NewStyleID, int OldStyleID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.Bp_ProcessAvatarLogicEquipped
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Bp_ProcessAvatarLogicEquipped(int SlotID, struct FItemDefineID NewItemID, struct FItemDefineID OldItemID); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x38)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.BPCreateAvatarCustomHandle
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void BPCreateAvatarCustomHandle(int SlotID, int ItemID, struct FAvatarCustom& InCostomInfo, struct TArray<struct UAvatarCustomBase*>& OutCustomHandle); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x30)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.MakeVehicleStyleData
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct FVehicleStyleData MakeVehicleStyleData(int InStyleID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.GenerateDefaultAvatarConfig
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	bool GenerateDefaultAvatarConfig(int InBaseSkinID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.InitVehicleAvatarBySkinID
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool InitVehicleAvatarBySkinID(int InVehicleSkinID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.ReceiveBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.Bp_EventAvatarLogicEquipped
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Bp_EventAvatarLogicEquipped(int SlotID, struct FItemDefineID NewItemID, struct FItemDefineID OldItemID); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x38)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.Bp_EventAvatarLogicUnequipped
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Bp_EventAvatarLogicUnequipped(int SlotID, struct FItemDefineID OldItemID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.BP_EventStyleEquipped
	// Flags: [BlueprintCallable|BlueprintEvent]
	void BP_EventStyleEquipped(int NewStyleID, int OldStyleID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.BP_EventStyleUnequipped
	// Flags: [BlueprintCallable|BlueprintEvent]
	void BP_EventStyleUnequipped(int OldStyleID); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function VehicleAdvanceAvatarComp_BP.VehicleAdvanceAvatarComp_BP_C.ExecuteUbergraph_VehicleAdvanceAvatarComp_BP
	// Flags: [HasDefaults]
	void ExecuteUbergraph_VehicleAdvanceAvatarComp_BP(int EntryPoint); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)
};

