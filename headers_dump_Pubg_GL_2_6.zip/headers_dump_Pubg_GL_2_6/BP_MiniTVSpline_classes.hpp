//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_MiniTVSpline.BP_MiniTVSpline_C
// Size: 0x3f9 // Inherited bytes: 0x3f0
struct ABP_MiniTVSpline_C : AActor {
	// Fields
	struct USplineComponent* Spline; // Offset: 0x3f0 // Size: 0x08
	bool MoveActor; // Offset: 0x3f8 // Size: 0x01

	// Functions

	// Object Name: Function BP_MiniTVSpline.BP_MiniTVSpline_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)
};

