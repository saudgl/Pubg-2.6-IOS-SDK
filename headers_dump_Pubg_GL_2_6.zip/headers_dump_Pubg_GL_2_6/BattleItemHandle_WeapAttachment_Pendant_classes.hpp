//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BattleItemHandle_WeapAttachment_Pendant.BattleItemHandle_WeapAttachment_Pendant_C
// Size: 0x458 // Inherited bytes: 0x458
struct UBattleItemHandle_WeapAttachment_Pendant_C : UBattleItemHandle_WeapAttachment_C {
};

