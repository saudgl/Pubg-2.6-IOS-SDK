//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass AvatarCustomColor_BP.AvatarCustomColor_BP_C
// Size: 0x50 // Inherited bytes: 0x50
struct UAvatarCustomColor_BP_C : UAvatarCustomColor {
};

