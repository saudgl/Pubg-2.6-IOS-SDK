//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UnknowPass_ContinuousBuy_BP.UnknowPass_ContinuousBuy_BP_C
// Size: 0x490 // Inherited bytes: 0x418
struct UUnknowPass_ContinuousBuy_BP_C : UUAEUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x418 // Size: 0x08
	struct UWidgetAnimation* GetTitle; // Offset: 0x420 // Size: 0x08
	struct UButton* Button_1; // Offset: 0x428 // Size: 0x08
	struct UCanvasPanel* FX1; // Offset: 0x430 // Size: 0x08
	struct UCanvasPanel* FX1_A; // Offset: 0x438 // Size: 0x08
	struct UImage* FX2; // Offset: 0x440 // Size: 0x08
	struct UImage* Image_2; // Offset: 0x448 // Size: 0x08
	struct UImage* Image_Elite_vpass; // Offset: 0x450 // Size: 0x08
	struct UImage* Image_Glow_2; // Offset: 0x458 // Size: 0x08
	struct UImage* Image_Glow_3; // Offset: 0x460 // Size: 0x08
	struct UImage* Image_None_A; // Offset: 0x468 // Size: 0x08
	struct UImage* Image_Normal_A; // Offset: 0x470 // Size: 0x08
	struct UImage* Image_Plus_A; // Offset: 0x478 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher; // Offset: 0x480 // Size: 0x08
	int HighestLevel; // Offset: 0x488 // Size: 0x04
	int thisSeasonId; // Offset: 0x48c // Size: 0x04

	// Functions

	// Object Name: Function UnknowPass_ContinuousBuy_BP.UnknowPass_ContinuousBuy_BP_C.GetSeasonId
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetSeasonId(int InSeasonId, int& OutSeasonId); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function UnknowPass_ContinuousBuy_BP.UnknowPass_ContinuousBuy_BP_C.SetTypeData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetTypeData(int SeasonID, int Level, bool isElite, int Online, int Value, int passType); // Offset: 0x1041acc2c // Return & Params: Num(6) Size(0x18)

	// Object Name: Function UnknowPass_ContinuousBuy_BP.UnknowPass_ContinuousBuy_BP_C.HideFX
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void HideFX(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnknowPass_ContinuousBuy_BP.UnknowPass_ContinuousBuy_BP_C.SetEliteImage
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetEliteImage(int SeasonID, int Level, int Value, bool isElite); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0xd)

	// Object Name: Function UnknowPass_ContinuousBuy_BP.UnknowPass_ContinuousBuy_BP_C.SetData
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetData(int SeasonID, int Level, bool isElite, int Online, int Value); // Offset: 0x1041acc2c // Return & Params: Num(5) Size(0x14)

	// Object Name: Function UnknowPass_ContinuousBuy_BP.UnknowPass_ContinuousBuy_BP_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnknowPass_ContinuousBuy_BP.UnknowPass_ContinuousBuy_BP_C.ExecuteUbergraph_UnknowPass_ContinuousBuy_BP
	// Flags: [None]
	void ExecuteUbergraph_UnknowPass_ContinuousBuy_BP(int EntryPoint); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)
};

