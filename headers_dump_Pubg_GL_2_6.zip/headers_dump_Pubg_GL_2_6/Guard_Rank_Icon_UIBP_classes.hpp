//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Guard_Rank_Icon_UIBP.Guard_Rank_Icon_UIBP_C
// Size: 0x300 // Inherited bytes: 0x2d0
struct UGuard_Rank_Icon_UIBP_C : ULuaUserWidget {
	// Fields
	struct UButton* Button_1; // Offset: 0x2d0 // Size: 0x08
	struct UImage* Image_19; // Offset: 0x2d8 // Size: 0x08
	struct UImage* Image_20; // Offset: 0x2e0 // Size: 0x08
	struct UImage* Image_21; // Offset: 0x2e8 // Size: 0x08
	struct UImage* Image_Sweep_Light; // Offset: 0x2f0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_4; // Offset: 0x2f8 // Size: 0x08
};

