//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedEnum EnumAvatarForceGender.EnumAvatarForceGender
enum class EnumAvatarForceGender : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	EnumAvatarForceGender_MAX = 3
};

