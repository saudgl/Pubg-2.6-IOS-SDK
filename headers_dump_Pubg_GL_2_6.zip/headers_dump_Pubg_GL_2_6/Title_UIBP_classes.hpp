//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Title_UIBP.Title_UIBP_C
// Size: 0x50c // Inherited bytes: 0x418
struct UTitle_UIBP_C : UUAEUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x418 // Size: 0x08
	struct UWidgetAnimation* NewAnimation_5; // Offset: 0x420 // Size: 0x08
	struct UWidgetAnimation* NewAnimation_4; // Offset: 0x428 // Size: 0x08
	struct UWidgetAnimation* NewAnimation_3; // Offset: 0x430 // Size: 0x08
	struct UWidgetAnimation* NewAnimation_2; // Offset: 0x438 // Size: 0x08
	struct UImage* Icon; // Offset: 0x440 // Size: 0x08
	struct UImage* icon_nation; // Offset: 0x448 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x450 // Size: 0x08
	struct UImage* Image_3; // Offset: 0x458 // Size: 0x08
	struct UImage* Image_4; // Offset: 0x460 // Size: 0x08
	struct UImage* Image_bk; // Offset: 0x468 // Size: 0x08
	struct UTextBlock* Title; // Offset: 0x470 // Size: 0x08
	struct UTextBlock* Title_hidden; // Offset: 0x478 // Size: 0x08
	struct FBP_STRUCT_RegionConfig_type NationInfoRet2; // Offset: 0x480 // Size: 0x88
	int TextLength; // Offset: 0x508 // Size: 0x04

	// Functions

	// Object Name: Function Title_UIBP.Title_UIBP_C.__SetLbsGlobalAliasInfo
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void __SetLbsGlobalAliasInfo(int RankID); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Title_UIBP.Title_UIBP_C.SetAliasInfo
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetAliasInfo(int ID, struct FString Title, struct FString Nation, float Available len, int RankID); // Offset: 0x1041acc2c // Return & Params: Num(5) Size(0x30)

	// Object Name: Function Title_UIBP.Title_UIBP_C.__SetImageWithsSpriteRes
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void __SetImageWithsSpriteRes(struct FString ResPath, struct UImage* Image); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Title_UIBP.Title_UIBP_C.__GetNationInfo
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void __GetNationInfo(struct FString NationCode, struct FBP_STRUCT_RegionConfig_type& NationInfo); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x98)

	// Object Name: Function Title_UIBP.Title_UIBP_C.SetAliasData
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetAliasData(struct FString Nation, int Quality, struct FString PathUrl, struct FString Title, float availableLen, int RankID); // Offset: 0x1041acc2c // Return & Params: Num(6) Size(0x40)

	// Object Name: Function Title_UIBP.Title_UIBP_C.HideAll
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void HideAll(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Title_UIBP.Title_UIBP_C.DelayCheckAliasLength
	// Flags: [BlueprintCallable|BlueprintEvent]
	void DelayCheckAliasLength(float AvaliableLen, struct FString Title); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Title_UIBP.Title_UIBP_C.ExecuteUbergraph_Title_UIBP
	// Flags: [HasDefaults]
	void ExecuteUbergraph_Title_UIBP(int EntryPoint); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)
};

