//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_EmoteStateConfig_type.BP_STRUCT_EmoteStateConfig_type
// Size: 0x0c // Inherited bytes: 0x00
struct FBP_STRUCT_EmoteStateConfig_type {
	// Fields
	int NewEmoteID_0_6363C600226B100E7A6D97B809816AB4; // Offset: 0x00 // Size: 0x04
	int OriginEmoteID_1_56F8B5804AFE1ED04CCDD64B06544584; // Offset: 0x04 // Size: 0x04
	int State_2_3D821A00323D857E1494022404725595; // Offset: 0x08 // Size: 0x04
};

