//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass UAELobbyGamePawnMode.UAELobbyGamePawnMode_C
// Size: 0x4c8 // Inherited bytes: 0x4c0
struct AUAELobbyGamePawnMode_C : AUAELobbyGameMode {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x4c0 // Size: 0x08

	// Functions

	// Object Name: Function UAELobbyGamePawnMode.UAELobbyGamePawnMode_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)
};

