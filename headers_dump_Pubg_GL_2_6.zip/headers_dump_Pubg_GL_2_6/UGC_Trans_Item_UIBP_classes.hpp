//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UGC_Trans_Item_UIBP.UGC_Trans_Item_UIBP_C
// Size: 0x298 // Inherited bytes: 0x260
struct UUGC_Trans_Item_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* Out; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x268 // Size: 0x08
	struct UWidgetAnimation* translate_friend_animation; // Offset: 0x270 // Size: 0x08
	struct UButton* Button_translate_friend; // Offset: 0x278 // Size: 0x08
	struct UHorizontalBox* friend_chat_Box; // Offset: 0x280 // Size: 0x08
	struct UTextBlock* friend_trans_from; // Offset: 0x288 // Size: 0x08
	struct UImage* translate_friend; // Offset: 0x290 // Size: 0x08
};

