//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct TableResInclude.AudioVehicle_TabRes
// Size: 0x28 // Inherited bytes: 0x00
struct FAudioVehicle_TabRes {
	// Fields
	struct FString ID; // Offset: 0x00 // Size: 0x10
	int MinValue; // Offset: 0x10 // Size: 0x04
	int MaxValue; // Offset: 0x14 // Size: 0x04
	int Distance; // Offset: 0x18 // Size: 0x04
	int IsOpen; // Offset: 0x1c // Size: 0x04
	int Value; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct TableResInclude.CarMusic_TabRes
// Size: 0xb8 // Inherited bytes: 0x00
struct FCarMusic_TabRes {
	// Fields
	int ItemID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Music5; // Offset: 0x08 // Size: 0x10
	int Music1Probability; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString Music3; // Offset: 0x20 // Size: 0x10
	int Music7Probability; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FString Music2; // Offset: 0x38 // Size: 0x10
	int Music2Probability; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct FString Music1; // Offset: 0x50 // Size: 0x10
	int Music4Probability; // Offset: 0x60 // Size: 0x04
	int Music5Probability; // Offset: 0x64 // Size: 0x04
	struct FString Music6; // Offset: 0x68 // Size: 0x10
	struct FString Music7; // Offset: 0x78 // Size: 0x10
	struct FString Music8; // Offset: 0x88 // Size: 0x10
	struct FString Music4; // Offset: 0x98 // Size: 0x10
	int Music8Probability; // Offset: 0xa8 // Size: 0x04
	int Music6Probability; // Offset: 0xac // Size: 0x04
	int Music3Probability; // Offset: 0xb0 // Size: 0x04
	char pad_0xB4[0x4]; // Offset: 0xb4 // Size: 0x04
};

// Object Name: ScriptStruct TableResInclude.CollectedEvent_TabRes
// Size: 0x08 // Inherited bytes: 0x00
struct FCollectedEvent_TabRes {
	// Fields
	int EventId; // Offset: 0x00 // Size: 0x04
	bool bWeSeeNeeded; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct TableResInclude.DropConfig_TabRes
// Size: 0xc0 // Inherited bytes: 0x00
struct FDropConfig_TabRes {
	// Fields
	int DropPercent3; // Offset: 0x00 // Size: 0x04
	int DropMode9; // Offset: 0x04 // Size: 0x04
	int MonsterID; // Offset: 0x08 // Size: 0x04
	int DropRuleStart7; // Offset: 0x0c // Size: 0x04
	int DropRuleStart2; // Offset: 0x10 // Size: 0x04
	int DropRuleStart3; // Offset: 0x14 // Size: 0x04
	int DropRuleEnd9; // Offset: 0x18 // Size: 0x04
	int DropMode4; // Offset: 0x1c // Size: 0x04
	int DropPercent10; // Offset: 0x20 // Size: 0x04
	int DropPercent7; // Offset: 0x24 // Size: 0x04
	int DropRuleStart5; // Offset: 0x28 // Size: 0x04
	int DropRuleEnd5; // Offset: 0x2c // Size: 0x04
	int DropRuleStart6; // Offset: 0x30 // Size: 0x04
	int DropRuleStart8; // Offset: 0x34 // Size: 0x04
	int DropRuleEnd8; // Offset: 0x38 // Size: 0x04
	int DropMode8; // Offset: 0x3c // Size: 0x04
	int DropRuleEnd7; // Offset: 0x40 // Size: 0x04
	int DropMode6; // Offset: 0x44 // Size: 0x04
	int DropPercent5; // Offset: 0x48 // Size: 0x04
	int DropMode10; // Offset: 0x4c // Size: 0x04
	int DropRuleEnd2; // Offset: 0x50 // Size: 0x04
	int DropRuleEnd3; // Offset: 0x54 // Size: 0x04
	int DropRuleEnd10; // Offset: 0x58 // Size: 0x04
	int DropMode5; // Offset: 0x5c // Size: 0x04
	int DropPercent8; // Offset: 0x60 // Size: 0x04
	int DropPercent6; // Offset: 0x64 // Size: 0x04
	int DropRuleStart9; // Offset: 0x68 // Size: 0x04
	int DropRuleStart10; // Offset: 0x6c // Size: 0x04
	int DropMode7; // Offset: 0x70 // Size: 0x04
	int DropRuleEnd6; // Offset: 0x74 // Size: 0x04
	int DropRuleIDNumber; // Offset: 0x78 // Size: 0x04
	int DropPercent1; // Offset: 0x7c // Size: 0x04
	int DropPercent9; // Offset: 0x80 // Size: 0x04
	int DropMode1; // Offset: 0x84 // Size: 0x04
	struct FString TreasureBoxName; // Offset: 0x88 // Size: 0x10
	int DropPercent4; // Offset: 0x98 // Size: 0x04
	int TreasureBoxType; // Offset: 0x9c // Size: 0x04
	int DropMode2; // Offset: 0xa0 // Size: 0x04
	int DropRuleStart1; // Offset: 0xa4 // Size: 0x04
	int DropPercent2; // Offset: 0xa8 // Size: 0x04
	int DropRuleStart4; // Offset: 0xac // Size: 0x04
	int DropMode3; // Offset: 0xb0 // Size: 0x04
	int DropRuleEnd4; // Offset: 0xb4 // Size: 0x04
	int DropRuleEnd1; // Offset: 0xb8 // Size: 0x04
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
};

// Object Name: ScriptStruct TableResInclude.EvoBaseMapUIMarkTable
// Size: 0x30 // Inherited bytes: 0x08
struct FEvoBaseMapUIMarkTable : FTableRowBase {
	// Fields
	int ID; // Offset: 0x08 // Size: 0x04
	int UIBPSrcID; // Offset: 0x0c // Size: 0x04
	struct FString UIBPSoftPtr; // Offset: 0x10 // Size: 0x10
	struct FString UIDescription; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct TableResInclude.EvoBaseModTableTestTable
// Size: 0x28 // Inherited bytes: 0x08
struct FEvoBaseModTableTestTable : FTableRowBase {
	// Fields
	int ID; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString TestString; // Offset: 0x10 // Size: 0x10
	int TestNumber; // Offset: 0x20 // Size: 0x04
	bool TestBool; // Offset: 0x24 // Size: 0x01
	char pad_0x25[0x3]; // Offset: 0x25 // Size: 0x03
};

// Object Name: ScriptStruct TableResInclude.GrenadeSortPriority_TabRes
// Size: 0x50 // Inherited bytes: 0x00
struct FGrenadeSortPriority_TabRes {
	// Fields
	int ItemID; // Offset: 0x00 // Size: 0x04
	int GrenadeEnumValue; // Offset: 0x04 // Size: 0x04
	int Priority; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString BPPath; // Offset: 0x10 // Size: 0x10
	int SwitchOrder; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FString pressedimagepath; // Offset: 0x28 // Size: 0x10
	struct FString ImagePath; // Offset: 0x38 // Size: 0x10
	int CountDown; // Offset: 0x48 // Size: 0x04
	int skillindex; // Offset: 0x4c // Size: 0x04
};

// Object Name: ScriptStruct TableResInclude.ItemSpawnDataSub_TabRes
// Size: 0x78 // Inherited bytes: 0x00
struct FItemSpawnDataSub_TabRes {
	// Fields
	int Weight; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString CategoryFilter; // Offset: 0x08 // Size: 0x10
	int KeyID; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString ItemPath; // Offset: 0x20 // Size: 0x10
	int CountMin; // Offset: 0x30 // Size: 0x04
	int StackCount; // Offset: 0x34 // Size: 0x04
	int Count; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct FString ValueFilter; // Offset: 0x40 // Size: 0x10
	int CountMax; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct FString ItemTogetherPath; // Offset: 0x58 // Size: 0x10
	struct FString SubCategoryFilter; // Offset: 0x68 // Size: 0x10
};

// Object Name: ScriptStruct TableResInclude.ItemSpawnData_TabRes
// Size: 0x60 // Inherited bytes: 0x00
struct FItemSpawnData_TabRes {
	// Fields
	struct FString ItemPath; // Offset: 0x00 // Size: 0x10
	int Weight; // Offset: 0x10 // Size: 0x04
	int StackCount; // Offset: 0x14 // Size: 0x04
	struct FString ValueFilter; // Offset: 0x18 // Size: 0x10
	int KeyID; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString CategoryFilter; // Offset: 0x30 // Size: 0x10
	int CountMax; // Offset: 0x40 // Size: 0x04
	int CountMin; // Offset: 0x44 // Size: 0x04
	struct FString ItemTogetherPath; // Offset: 0x48 // Size: 0x10
	int Count; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct TableResInclude.ItemTag_TabRes
// Size: 0x20 // Inherited bytes: 0x00
struct FItemTag_TabRes {
	// Fields
	int TagValue; // Offset: 0x00 // Size: 0x04
	int ItemID; // Offset: 0x04 // Size: 0x04
	struct FString TagName; // Offset: 0x08 // Size: 0x10
	int ID; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct TableResInclude.Item_TabRes
// Size: 0x1d8 // Inherited bytes: 0x00
struct FItem_TabRes {
	// Fields
	struct FString ItemBigIcon; // Offset: 0x00 // Size: 0x10
	int MaxCount; // Offset: 0x10 // Size: 0x04
	int BPID; // Offset: 0x14 // Size: 0x04
	int ItemType; // Offset: 0x18 // Size: 0x04
	bool AutoEquipandDrop; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
	int ItemID; // Offset: 0x20 // Size: 0x04
	bool Consumable; // Offset: 0x24 // Size: 0x01
	char pad_0x25[0x3]; // Offset: 0x25 // Size: 0x03
	struct FString ItemDesc; // Offset: 0x28 // Size: 0x10
	struct FString ItemSmallIcon; // Offset: 0x38 // Size: 0x10
	struct FString ItemName; // Offset: 0x48 // Size: 0x10
	struct FString WardrobeTab; // Offset: 0x58 // Size: 0x10
	int ItemSubType; // Offset: 0x68 // Size: 0x04
	bool Equippable; // Offset: 0x6c // Size: 0x01
	char pad_0x6D[0x3]; // Offset: 0x6d // Size: 0x03
	float UnitWeight_f; // Offset: 0x70 // Size: 0x04
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
	struct FString ItemWhiteIcon; // Offset: 0x78 // Size: 0x10
	int ItemQuality; // Offset: 0x88 // Size: 0x04
	int SellTokenType; // Offset: 0x8c // Size: 0x04
	int SellPrice; // Offset: 0x90 // Size: 0x04
	char pad_0x94[0x4]; // Offset: 0x94 // Size: 0x04
	struct FString PickupSound; // Offset: 0x98 // Size: 0x10
	struct FString UnEquipSound; // Offset: 0xa8 // Size: 0x10
	struct FString DropSound; // Offset: 0xb8 // Size: 0x10
	struct FString EquipSound; // Offset: 0xc8 // Size: 0x10
	struct FString UnEquipBank; // Offset: 0xd8 // Size: 0x10
	struct FString EquipBank; // Offset: 0xe8 // Size: 0x10
	struct FString DropBank; // Offset: 0xf8 // Size: 0x10
	struct FString PickUpBank; // Offset: 0x108 // Size: 0x10
	struct FString KillWhiteIcon; // Offset: 0x118 // Size: 0x10
	bool NeedShare; // Offset: 0x128 // Size: 0x01
	char pad_0x129[0x3]; // Offset: 0x129 // Size: 0x03
	int WeightforOrder; // Offset: 0x12c // Size: 0x04
	struct FString Preview; // Offset: 0x130 // Size: 0x10
	struct FString ExTime; // Offset: 0x140 // Size: 0x10
	struct FString JumpUrl; // Offset: 0x150 // Size: 0x10
	int SourceBookEnable; // Offset: 0x160 // Size: 0x04
	char pad_0x164[0x4]; // Offset: 0x164 // Size: 0x04
	struct FString PickupDesc; // Offset: 0x168 // Size: 0x10
	int WardrobeMainTab; // Offset: 0x178 // Size: 0x04
	int Durability; // Offset: 0x17c // Size: 0x04
	struct FString JumpExchangeUrl; // Offset: 0x180 // Size: 0x10
	int LongDescID; // Offset: 0x190 // Size: 0x04
	int AIFullVaule; // Offset: 0x194 // Size: 0x04
	struct FString ItemSmallIcon2; // Offset: 0x198 // Size: 0x10
	struct FString ItemBigIcon2; // Offset: 0x1a8 // Size: 0x10
	struct FString BackpackSimple; // Offset: 0x1b8 // Size: 0x10
	int UseType; // Offset: 0x1c8 // Size: 0x04
	int gender; // Offset: 0x1cc // Size: 0x04
	int ArmoryJumpId; // Offset: 0x1d0 // Size: 0x04
	int CharmValue; // Offset: 0x1d4 // Size: 0x04
};

// Object Name: ScriptStruct TableResInclude.MonsterSpawnData_TabRes
// Size: 0x70 // Inherited bytes: 0x00
struct FMonsterSpawnData_TabRes {
	// Fields
	struct FString ValueFilter; // Offset: 0x00 // Size: 0x10
	struct FString ItemTogetherPath; // Offset: 0x10 // Size: 0x10
	struct FString MetaData; // Offset: 0x20 // Size: 0x10
	int Count; // Offset: 0x30 // Size: 0x04
	int CountMin; // Offset: 0x34 // Size: 0x04
	int StackCount; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct FString CategoryFilter; // Offset: 0x40 // Size: 0x10
	int Weight; // Offset: 0x50 // Size: 0x04
	int KeyID; // Offset: 0x54 // Size: 0x04
	struct FString ItemPath; // Offset: 0x58 // Size: 0x10
	int CountMax; // Offset: 0x68 // Size: 0x04
	int MonsterID; // Offset: 0x6c // Size: 0x04
};

// Object Name: ScriptStruct TableResInclude.PawnStateInvisUI_TabRes
// Size: 0x20 // Inherited bytes: 0x00
struct FPawnStateInvisUI_TabRes {
	// Fields
	struct FString UIClassName; // Offset: 0x00 // Size: 0x10
	struct TArray<int> InvisPawnState_a; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct TableResInclude.RoleUpgradeTable_TabRes
// Size: 0x14 // Inherited bytes: 0x00
struct FRoleUpgradeTable_TabRes {
	// Fields
	int Capacity; // Offset: 0x00 // Size: 0x04
	int Level; // Offset: 0x04 // Size: 0x04
	float ZombieInjury_f; // Offset: 0x08 // Size: 0x04
	float MovingSpeed_f; // Offset: 0x0c // Size: 0x04
	int Exp; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct TableResInclude.VehicleMaxHP_TabRes
// Size: 0x40 // Inherited bytes: 0x00
struct FVehicleMaxHP_TabRes {
	// Fields
	int HPNum; // Offset: 0x00 // Size: 0x04
	int VehicleItemID; // Offset: 0x04 // Size: 0x04
	int ID; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString EndTime; // Offset: 0x10 // Size: 0x10
	struct FString ModuleTypeID; // Offset: 0x20 // Size: 0x10
	struct FString StartTime; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct TableResInclude.VehicleSpawn_TabRes
// Size: 0x30 // Inherited bytes: 0x00
struct FVehicleSpawn_TabRes {
	// Fields
	struct FString VehicleType; // Offset: 0x00 // Size: 0x10
	int KeyID; // Offset: 0x10 // Size: 0x04
	bool SnapFloor; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	int Weight; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString Vehicle; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct TableResInclude.VibrateAssetsConfig_TabRes
// Size: 0x140 // Inherited bytes: 0x00
struct FVibrateAssetsConfig_TabRes {
	// Fields
	int AssetId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString AssetRelativePath; // Offset: 0x08 // Size: 0x10
	struct FString PlayVibrateParam; // Offset: 0x18 // Size: 0x10
	int TriggerEventType; // Offset: 0x28 // Size: 0x04
	int PlayPriority; // Offset: 0x2c // Size: 0x04
	float PlayDuration_f; // Offset: 0x30 // Size: 0x04
	bool bOnlyMatchMainItemType; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
	int TriggerMainItemType; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct FString TriggerMainItemData; // Offset: 0x40 // Size: 0x10
	int TriggerSubItem1Type; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct FString TriggerSubItem1Data; // Offset: 0x58 // Size: 0x10
	int TriggerSubItem2Type; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct FString TriggerSubItem2Data; // Offset: 0x70 // Size: 0x10
	int TriggerSubItem3Type; // Offset: 0x80 // Size: 0x04
	char pad_0x84[0x4]; // Offset: 0x84 // Size: 0x04
	struct FString TriggerSubItem3Data; // Offset: 0x88 // Size: 0x10
	int TriggerSubItem4Type; // Offset: 0x98 // Size: 0x04
	char pad_0x9C[0x4]; // Offset: 0x9c // Size: 0x04
	struct FString TriggerSubItem4Data; // Offset: 0xa0 // Size: 0x10
	int TriggerSubItem5Type; // Offset: 0xb0 // Size: 0x04
	char pad_0xB4[0x4]; // Offset: 0xb4 // Size: 0x04
	struct FString TriggerSubItem5Data; // Offset: 0xb8 // Size: 0x10
	int TriggerSubItem6Type; // Offset: 0xc8 // Size: 0x04
	char pad_0xCC[0x4]; // Offset: 0xcc // Size: 0x04
	struct FString TriggerSubItem6Data; // Offset: 0xd0 // Size: 0x10
	int TriggerSubItem7Type; // Offset: 0xe0 // Size: 0x04
	char pad_0xE4[0x4]; // Offset: 0xe4 // Size: 0x04
	struct FString TriggerSubItem7Data; // Offset: 0xe8 // Size: 0x10
	int TriggerSubItem8Type; // Offset: 0xf8 // Size: 0x04
	char pad_0xFC[0x4]; // Offset: 0xfc // Size: 0x04
	struct FString TriggerSubItem8Data; // Offset: 0x100 // Size: 0x10
	int TriggerSubItem9Type; // Offset: 0x110 // Size: 0x04
	char pad_0x114[0x4]; // Offset: 0x114 // Size: 0x04
	struct FString TriggerSubItem9Data; // Offset: 0x118 // Size: 0x10
	int TriggerSubItem10Type; // Offset: 0x128 // Size: 0x04
	char pad_0x12C[0x4]; // Offset: 0x12c // Size: 0x04
	struct FString TriggerSubItem10Data; // Offset: 0x130 // Size: 0x10
};

// Object Name: ScriptStruct TableResInclude.WeaponAttachments_TabRes
// Size: 0x84 // Inherited bytes: 0x00
struct FWeaponAttachments_TabRes {
	// Fields
	int Magazine1ID; // Offset: 0x00 // Size: 0x04
	int Stock2ID; // Offset: 0x04 // Size: 0x04
	int Lower1ID; // Offset: 0x08 // Size: 0x04
	int Lower2ID; // Offset: 0x0c // Size: 0x04
	int Magazine3ID; // Offset: 0x10 // Size: 0x04
	int Stock1ID; // Offset: 0x14 // Size: 0x04
	int Magazine2ID; // Offset: 0x18 // Size: 0x04
	int Muzzle2ID; // Offset: 0x1c // Size: 0x04
	int Upper1ID; // Offset: 0x20 // Size: 0x04
	int Upper2ID; // Offset: 0x24 // Size: 0x04
	int Muzzle1ID; // Offset: 0x28 // Size: 0x04
	int Upper4ID; // Offset: 0x2c // Size: 0x04
	int KeyID; // Offset: 0x30 // Size: 0x04
	int Muzzle3ID; // Offset: 0x34 // Size: 0x04
	int Upper3ID; // Offset: 0x38 // Size: 0x04
	int Upper5ID; // Offset: 0x3c // Size: 0x04
	int BulletID; // Offset: 0x40 // Size: 0x04
	int ProposeBulletNum; // Offset: 0x44 // Size: 0x04
	int Lower3ID; // Offset: 0x48 // Size: 0x04
	int Lower5ID; // Offset: 0x4c // Size: 0x04
	int Lower4ID; // Offset: 0x50 // Size: 0x04
	int Upper7ID; // Offset: 0x54 // Size: 0x04
	int Muzzle5ID; // Offset: 0x58 // Size: 0x04
	int Muzzle6ID; // Offset: 0x5c // Size: 0x04
	int Muzzle4ID; // Offset: 0x60 // Size: 0x04
	int Magazine6ID; // Offset: 0x64 // Size: 0x04
	int Magazine4ID; // Offset: 0x68 // Size: 0x04
	int Magazine5ID; // Offset: 0x6c // Size: 0x04
	int Upper6ID; // Offset: 0x70 // Size: 0x04
	int AIMaxAttackDist; // Offset: 0x74 // Size: 0x04
	int AIMinAttackDist; // Offset: 0x78 // Size: 0x04
	int Lower6ID; // Offset: 0x7c // Size: 0x04
	int UpperSide1ID; // Offset: 0x80 // Size: 0x04
};

// Object Name: ScriptStruct TableResInclude.ZombieTreasureBox_TabRes
// Size: 0x20 // Inherited bytes: 0x00
struct FZombieTreasureBox_TabRes {
	// Fields
	struct FString BoxPath; // Offset: 0x00 // Size: 0x10
	int ID; // Offset: 0x10 // Size: 0x04
	int BoxHealth; // Offset: 0x14 // Size: 0x04
	int TimeToCount; // Offset: 0x18 // Size: 0x04
	int BoxDropPlan; // Offset: 0x1c // Size: 0x04
};

