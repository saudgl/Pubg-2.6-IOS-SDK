//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_ReddotConfig_type.BP_STRUCT_ReddotConfig_type
// Size: 0x30 // Inherited bytes: 0x00
struct FBP_STRUCT_ReddotConfig_type {
	// Fields
	int ID_0_78AF56C044BEFD412EE9515D060FED24; // Offset: 0x00 // Size: 0x04
	bool IsEliminatePrimaryReddot_1_27D0FA0036EB83B630125A6C0410D674; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct FString Name_2_5B5613C00DB5AED7351999A70FEEB235; // Offset: 0x08 // Size: 0x10
	int Weight_3_4E71ED804B30B13256D9FD060C2DF214; // Offset: 0x18 // Size: 0x04
	int ValidLevel_6_6FEECD801D03127225565A3C007EFE9C; // Offset: 0x1c // Size: 0x04
	struct FString ValidUser_7_108A3740653B25C774ABC29402070AE2; // Offset: 0x20 // Size: 0x10
};

