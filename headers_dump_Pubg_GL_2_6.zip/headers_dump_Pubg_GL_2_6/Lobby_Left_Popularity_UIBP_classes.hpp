//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Left_Popularity_UIBP.Lobby_Left_Popularity_UIBP_C
// Size: 0x410 // Inherited bytes: 0x260
struct ULobby_Left_Popularity_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* Tips_Gift; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* Refresh; // Offset: 0x268 // Size: 0x08
	struct UWidgetAnimation* Tips_Fadein; // Offset: 0x270 // Size: 0x08
	struct UCanvasPanel* Add_Friend; // Offset: 0x278 // Size: 0x08
	struct UButton* Button_1; // Offset: 0x280 // Size: 0x08
	struct UButton* Button_Add; // Offset: 0x288 // Size: 0x08
	struct UButton* Button_Details; // Offset: 0x290 // Size: 0x08
	struct UButton* Button_Edit; // Offset: 0x298 // Size: 0x08
	struct UButton* Button_Gift; // Offset: 0x2a0 // Size: 0x08
	struct UButton* Button_IntimacyAction; // Offset: 0x2a8 // Size: 0x08
	struct UButton* Button_Photo; // Offset: 0x2b0 // Size: 0x08
	struct UButton* Button_Popularity; // Offset: 0x2b8 // Size: 0x08
	struct UButton* Button_Replay_Action; // Offset: 0x2c0 // Size: 0x08
	struct UButton* Button_Send; // Offset: 0x2c8 // Size: 0x08
	struct UButton* Button_Visitor; // Offset: 0x2d0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_2; // Offset: 0x2d8 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Popularity; // Offset: 0x2e0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_PopularPK; // Offset: 0x2e8 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Rank1; // Offset: 0x2f0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Rank2; // Offset: 0x2f8 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Rank3; // Offset: 0x300 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Send; // Offset: 0x308 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Top3; // Offset: 0x310 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Visitor; // Offset: 0x318 // Size: 0x08
	struct UCommon_Avatar_BP_C* Common_Avatar_BP_C_1; // Offset: 0x320 // Size: 0x08
	struct UCommon_Avatar_BP_C* Common_Avatar_BP_C_2; // Offset: 0x328 // Size: 0x08
	struct UCommon_Avatar_BP_C* Common_Avatar_BP_C_3; // Offset: 0x330 // Size: 0x08
	struct UCommon_Tips_Top_UIBP_C* Common_Tips_Top_UIBP; // Offset: 0x338 // Size: 0x08
	struct UCanvasPanel* Give; // Offset: 0x340 // Size: 0x08
	struct UGuard_Rank_Icon_UIBP_C* Guard_Rank_Icon_UIBP_2; // Offset: 0x348 // Size: 0x08
	struct UGuard_Rank_Icon_UIBP_C* Guard_Rank_Icon_UIBP_3; // Offset: 0x350 // Size: 0x08
	struct UGuard_Rank_Icon_UIBP_C* Guard_Rank_Icon_UIBP_4; // Offset: 0x358 // Size: 0x08
	struct UImage* Image_21; // Offset: 0x360 // Size: 0x08
	struct UImage* Image_Popularity; // Offset: 0x368 // Size: 0x08
	struct UImage* Image_TimeLimit; // Offset: 0x370 // Size: 0x08
	struct UCanvasPanel* Intimacy_Action; // Offset: 0x378 // Size: 0x08
	struct UCanvasPanel* Photo; // Offset: 0x380 // Size: 0x08
	struct UImage* Photo_Reddot; // Offset: 0x388 // Size: 0x08
	struct UPopularity_Rank_Icon_UIBP_C* Popularity_Rank_Icon_UIBP_2; // Offset: 0x390 // Size: 0x08
	struct UPopularity_Rank_Icon_UIBP_C* Popularity_Rank_Icon_UIBP_3; // Offset: 0x398 // Size: 0x08
	struct UPopularity_Rank_Icon_UIBP_C* Popularity_Rank_Icon_UIBP_4; // Offset: 0x3a0 // Size: 0x08
	struct UImage* popularity_reddot; // Offset: 0x3a8 // Size: 0x08
	struct UTextBlock* PopularityCount; // Offset: 0x3b0 // Size: 0x08
	struct UCanvasPanel* PopularityItem; // Offset: 0x3b8 // Size: 0x08
	struct UCanvasPanel* RedProducts; // Offset: 0x3c0 // Size: 0x08
	struct UCanvasPanel* Replay_Action; // Offset: 0x3c8 // Size: 0x08
	struct UCanvasPanel* Show_Details; // Offset: 0x3d0 // Size: 0x08
	struct UTextBlock* TextBlock_Send; // Offset: 0x3d8 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_Intimacy; // Offset: 0x3e0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_2; // Offset: 0x3e8 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_3; // Offset: 0x3f0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_4; // Offset: 0x3f8 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_GiftOrPhoto; // Offset: 0x400 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_IntimacyAction; // Offset: 0x408 // Size: 0x08
};

