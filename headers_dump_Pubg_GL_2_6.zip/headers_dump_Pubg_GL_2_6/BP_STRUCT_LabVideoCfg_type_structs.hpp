//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_LabVideoCfg_type.BP_STRUCT_LabVideoCfg_type
// Size: 0x38 // Inherited bytes: 0x00
struct FBP_STRUCT_LabVideoCfg_type {
	// Fields
	int ItemID_0_50A3120067EFA27848F9DF7D0B01D7A4; // Offset: 0x00 // Size: 0x04
	int time_1_197F76C01A56E85D5FFE29AD0679A545; // Offset: 0x04 // Size: 0x04
	struct FString video_2_222170C0118FEA75491290CC079C4DDF; // Offset: 0x08 // Size: 0x10
	struct FString desc_3_376DB2C0504EB4E55FF5E8420678A7E3; // Offset: 0x18 // Size: 0x10
	struct FString icon_4_2562D5403108D5095E33051F0678F32E; // Offset: 0x28 // Size: 0x10
};

