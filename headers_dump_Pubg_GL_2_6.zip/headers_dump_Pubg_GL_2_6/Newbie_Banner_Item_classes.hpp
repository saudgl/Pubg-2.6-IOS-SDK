//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Newbie_Banner_Item.Newbie_Banner_Item_C
// Size: 0x4a0 // Inherited bytes: 0x418
struct UNewbie_Banner_Item_C : UUAEUserWidget {
	// Fields
	struct UWidgetAnimation* Anim_loading_loop; // Offset: 0x418 // Size: 0x08
	struct UWidgetAnimation* AwardPickAnimation; // Offset: 0x420 // Size: 0x08
	struct UCanvasPanel* Activity; // Offset: 0x428 // Size: 0x08
	struct UTextBlock* ActivityName; // Offset: 0x430 // Size: 0x08
	struct UButton* Button_Activity; // Offset: 0x438 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_3; // Offset: 0x440 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_name; // Offset: 0x448 // Size: 0x08
	struct UImage* Image_Activity; // Offset: 0x450 // Size: 0x08
	struct UImage* Image_CountDown; // Offset: 0x458 // Size: 0x08
	struct UCanvasPanel* Panel_Download; // Offset: 0x460 // Size: 0x08
	struct UTextBlock* UnLockLevel; // Offset: 0x468 // Size: 0x08
	struct FScriptMulticastDelegate ItemMoveLeftDispatcher; // Offset: 0x470 // Size: 0x10
	struct FScriptMulticastDelegate ItemMoveRightDispatcher; // Offset: 0x480 // Size: 0x10
	struct FScriptMulticastDelegate ItemClickDispatcher; // Offset: 0x490 // Size: 0x10

	// Functions

	// Object Name: Function Newbie_Banner_Item.Newbie_Banner_Item_C.ItemClickDispatcher__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void ItemClickDispatcher__DelegateSignature(struct ULobby_Activity_BtnItem_C* Item); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Newbie_Banner_Item.Newbie_Banner_Item_C.ItemMoveRightDispatcher__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void ItemMoveRightDispatcher__DelegateSignature(struct ULobby_Activity_BtnItem_C* Item); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Newbie_Banner_Item.Newbie_Banner_Item_C.ItemMoveLeftDispatcher__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void ItemMoveLeftDispatcher__DelegateSignature(struct ULobby_Activity_BtnItem_C* Item); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)
};

