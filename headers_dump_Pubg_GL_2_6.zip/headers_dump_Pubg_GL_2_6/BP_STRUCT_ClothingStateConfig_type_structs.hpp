//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_ClothingStateConfig_type.BP_STRUCT_ClothingStateConfig_type
// Size: 0x30 // Inherited bytes: 0x00
struct FBP_STRUCT_ClothingStateConfig_type {
	// Fields
	struct FString DetailIcon_0_790460404C6C98513F2D40CE0575B25E; // Offset: 0x00 // Size: 0x10
	int NewClothID_1_7C6DF580783D2B4C2A01FA4E0CC004C4; // Offset: 0x10 // Size: 0x04
	int OriginClothID_2_3653A50027DBF40E540F41B402F35B94; // Offset: 0x14 // Size: 0x04
	int State_3_3255A98004D1663E790C77840944E285; // Offset: 0x18 // Size: 0x04
	int StateName_4_6CF4E9C00CBE0D5B58EE403F028104D5; // Offset: 0x1c // Size: 0x04
	struct FString WardrobeIcon_5_2C21D900529AC976547A36DB01B5D17E; // Offset: 0x20 // Size: 0x10
};

