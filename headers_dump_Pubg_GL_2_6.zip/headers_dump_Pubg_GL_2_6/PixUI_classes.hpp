//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class PixUI.PixUIBPLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UPixUIBPLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_Version
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString PixUI_Version(); // Offset: 0x102452214 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_Startup
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool PixUI_Startup(struct FString fstr_CachePathForWrite); // Offset: 0x10245217c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_Shutdown
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool PixUI_Shutdown(); // Offset: 0x102452148 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_ShowTick
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_ShowTick(bool b_show); // Offset: 0x1024520cc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_ShowResInfor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_ShowResInfor(); // Offset: 0x1024520b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_ShowMousePos
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_ShowMousePos(bool b_show); // Offset: 0x10245203c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_SetPaintDura
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_SetPaintDura(int n_duar_count); // Offset: 0x102451fc8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_SetMobileUseTouchEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_SetMobileUseTouchEvent(bool b_used); // Offset: 0x102451f4c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_SetMatRootPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_SetMatRootPath(struct FString fstr_root_path); // Offset: 0x102451ebc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_SetMatBasePath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_SetMatBasePath(struct FString fstr_base_path); // Offset: 0x102451e2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_SetDynamicFixFontSize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_SetDynamicFixFontSize(bool b_OpenDynamicFix); // Offset: 0x102451db0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_SetDefaultFontSize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_SetDefaultFontSize(int n_FontSize); // Offset: 0x102451d3c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_SetDefaultFont
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_SetDefaultFont(struct FString fstr_FontName); // Offset: 0x102451cac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_SetDebugTickDelay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_SetDebugTickDelay(float f_delay); // Offset: 0x102451c38 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_SetDebugRetainDraw
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_SetDebugRetainDraw(bool b_retain); // Offset: 0x102451bbc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_SetDebugNoCoreTick
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_SetDebugNoCoreTick(bool b_no_tick); // Offset: 0x102451b40 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_SetDebugCPURunTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_SetDebugCPURunTime(int n_time); // Offset: 0x102451acc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_SetCoreTickDura
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_SetCoreTickDura(int n_duar_count); // Offset: 0x102451a58 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_RHIShaderPlatform
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int PixUI_RHIShaderPlatform(); // Offset: 0x102451a24 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_RHIShaderLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int PixUI_RHIShaderLevel(); // Offset: 0x1024519f0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_RemoveSystemFont
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_RemoveSystemFont(struct FString fstr_FontName); // Offset: 0x102451960 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_PlatformOSVersionCode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float PixUI_PlatformOSVersionCode(); // Offset: 0x10245192c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_PlatformOSVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString PixUI_PlatformOSVersion(); // Offset: 0x1024518c8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_PlatformCode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int PixUI_PlatformCode(); // Offset: 0x102451894 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_Platform
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString PixUI_Platform(); // Offset: 0x102451830 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_LogEnable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_LogEnable(bool b_Enagble); // Offset: 0x1024517b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_IsStartUp
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool PixUI_IsStartUp(); // Offset: 0x102451780 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_IsShowTick
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool PixUI_IsShowTick(); // Offset: 0x10245174c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_IsShowMousePos
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool PixUI_IsShowMousePos(); // Offset: 0x102451718 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_IsRHIShaderVulkan
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool PixUI_IsRHIShaderVulkan(); // Offset: 0x1024516e4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_IsRHIShaderOpenGLES2
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool PixUI_IsRHIShaderOpenGLES2(); // Offset: 0x1024516b0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_IsRHIShaderOpenGL
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool PixUI_IsRHIShaderOpenGL(); // Offset: 0x10245167c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_IsRHIShaderMetal
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool PixUI_IsRHIShaderMetal(); // Offset: 0x102451648 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_IsRHIShaderDX
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool PixUI_IsRHIShaderDX(); // Offset: 0x102451614 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_IsOsBit64
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool PixUI_IsOsBit64(); // Offset: 0x1024515e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_IsOsBit32
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool PixUI_IsOsBit32(); // Offset: 0x1024515ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_IsMobileUseTouchEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool PixUI_IsMobileUseTouchEvent(); // Offset: 0x102451578 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_IsDynamicFixFontSize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool PixUI_IsDynamicFixFontSize(); // Offset: 0x102451544 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_GetWindowSlotObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UObject* PixUI_GetWindowSlotObject(int windowID, struct FString strTagId); // Offset: 0x102451470 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_GetPaintDura
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int PixUI_GetPaintDura(); // Offset: 0x10245143c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_GetMatRootPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString PixUI_GetMatRootPath(); // Offset: 0x1024513d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_GetMatBasePath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString PixUI_GetMatBasePath(); // Offset: 0x102451374 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_GetFontPath
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool PixUI_GetFontPath(struct FString fstr_FontName, struct FString& fstr_FontPath); // Offset: 0x102451278 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_GetDefaultFontSize
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void PixUI_GetDefaultFontSize(int& n_FontSize); // Offset: 0x1024511f4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_GetDefaultFont
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void PixUI_GetDefaultFont(struct FString& fstr_FontName); // Offset: 0x102451154 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_GetDebugTickDelay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float PixUI_GetDebugTickDelay(); // Offset: 0x102451120 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_GetDebugRetainDraw
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool PixUI_GetDebugRetainDraw(); // Offset: 0x1024510ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_GetDebugNoCoreTick
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool PixUI_GetDebugNoCoreTick(); // Offset: 0x1024510b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_GetDebugCPURunTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int PixUI_GetDebugCPURunTime(); // Offset: 0x102451084 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_GetCoreTickDura
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int PixUI_GetCoreTickDura(); // Offset: 0x102451050 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_GetCachePath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString PixUI_GetCachePath(); // Offset: 0x102450fec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_FindByWindowID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UPixUIWidget* PixUI_FindByWindowID(int windowID); // Offset: 0x102450f70 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_CurrentGameFPS
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float PixUI_CurrentGameFPS(); // Offset: 0x102450f3c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_CreateWidget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UPixUIWidget* PixUI_CreateWidget(); // Offset: 0x102450f08 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_CreateViewPortWidget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UPixUIViewPortWidget* PixUI_CreateViewPortWidget(); // Offset: 0x102450ed4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_CreateViewPortAddToCanvasEx
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UPixUIViewPortWidget* PixUI_CreateViewPortAddToCanvasEx(struct UCanvasPanel* p_ParentCanvas); // Offset: 0x102450e58 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_CreateViewPortAddToCanvas
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UPixUIViewPortWidget* PixUI_CreateViewPortAddToCanvas(struct UCanvasPanel* p_ParentCanvas, struct FAnchors& Anchors, struct FMargin& Margin); // Offset: 0x102450d3c // Return & Params: Num(4) Size(0x30)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_CreateAddToCanvasEx
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UPixUIWidget* PixUI_CreateAddToCanvasEx(struct UCanvasPanel* p_ParentCanvas); // Offset: 0x102450cc0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_CreateAddToCanvas
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UPixUIWidget* PixUI_CreateAddToCanvas(struct UCanvasPanel* p_ParentCanvas, struct FAnchors& Anchors, struct FMargin& Margin); // Offset: 0x102450ba4 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_ClearCacheFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_ClearCacheFile(); // Offset: 0x102450b90 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PixUI.PixUIBPLibrary.PixUI_AddSystemFont
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PixUI_AddSystemFont(struct FString fstr_FontName, struct FString fstr_FontPath); // Offset: 0x102450aac // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class PixUI.PixUIInput
// Size: 0x60 // Inherited bytes: 0x28
struct UPixUIInput : UObject {
	// Fields
	DelegateProperty ActivateDelegate; // Offset: 0x28 // Size: 0x10
	DelegateProperty DeativateInput; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x18]; // Offset: 0x48 // Size: 0x18

	// Functions

	// Object Name: Function PixUI.PixUIInput.OnInputText
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OnInputText(struct FString fstrInsert, bool b_end_input, bool b_lost_focus, bool b_replace); // Offset: 0x1024534c4 // Return & Params: Num(4) Size(0x13)

	// Object Name: Function PixUI.PixUIInput.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UPixUIInput* Get(); // Offset: 0x102453490 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class PixUI.PixUILog
// Size: 0x38 // Inherited bytes: 0x28
struct UPixUILog : UObject {
	// Fields
	struct FScriptMulticastDelegate LogDelegate; // Offset: 0x28 // Size: 0x10

	// Functions

	// Object Name: Function PixUI.PixUILog.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UPixUILog* Get(); // Offset: 0x1024539f8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function PixUI.PixUILog.DispatchLog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DispatchLog(enum class EPXLogTypes e_LogType, enum class EPXLogLevels e_LogLevel, struct FString fstr_LogContent); // Offset: 0x1024538f0 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class PixUI.PixUIViewPortWidget
// Size: 0x298 // Inherited bytes: 0x260
struct UPixUIViewPortWidget : UUserWidget {
	// Fields
	DelegateProperty pixuiWinOpenDelegate; // Offset: 0x260 // Size: 0x10
	DelegateProperty pixuiWinConfirmDelegate; // Offset: 0x270 // Size: 0x10
	DelegateProperty pixuiWinPrompDelegate; // Offset: 0x280 // Size: 0x10
	char pad_0x290[0x8]; // Offset: 0x290 // Size: 0x08

	// Functions

	// Object Name: Function PixUI.PixUIViewPortWidget.PostPxMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PostPxMessage(struct FString fstr_Message); // Offset: 0x1024541c8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PixUI.PixUIViewPortWidget.OnPixuiPromptDelegate
	// Flags: [Final|Native|Public]
	struct FString OnPixuiPromptDelegate(struct FString fstr_Tip, struct FString fstr_Default); // Offset: 0x1024540a4 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function PixUI.PixUIViewPortWidget.OnPixuiOpenDelegate
	// Flags: [Final|Native|Public]
	int OnPixuiOpenDelegate(struct FString fstr_Url, struct FString fstr_Name, struct FString fstr_Features, bool b_replace); // Offset: 0x102453f0c // Return & Params: Num(5) Size(0x38)

	// Object Name: Function PixUI.PixUIViewPortWidget.OnPixuiConfirmDelegate
	// Flags: [Final|Native|Public]
	bool OnPixuiConfirmDelegate(struct FString fstr_ConfirmMsg); // Offset: 0x102453e64 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function PixUI.PixUIViewPortWidget.LoadPXViewFromUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	int LoadPXViewFromUrl(struct FString fstr_Url); // Offset: 0x102453dbc // Return & Params: Num(2) Size(0x14)

	// Object Name: Function PixUI.PixUIViewPortWidget.LoadPXViewFromGameAssetPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	int LoadPXViewFromGameAssetPath(struct FString fstr_FilePath); // Offset: 0x102453d14 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function PixUI.PixUIViewPortWidget.LoadPXViewFromData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int LoadPXViewFromData(struct TArray<char>& arry_Data, struct FString fstr_RootPath); // Offset: 0x102453c04 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function PixUI.PixUIViewPortWidget.GetPixuiWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UPixUIWidget* GetPixuiWidget(); // Offset: 0x102453bd0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function PixUI.PixUIViewPortWidget.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Close(); // Offset: 0x102453bbc // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class PixUI.PixUIWidget
// Size: 0x3d8 // Inherited bytes: 0x130
struct UPixUIWidget : UCanvasPanel {
	// Fields
	char pad_0x130[0x18]; // Offset: 0x130 // Size: 0x18
	struct FScriptMulticastDelegate OnCloseDelegate; // Offset: 0x148 // Size: 0x10
	struct FScriptMulticastDelegate OnDestroyDelegate; // Offset: 0x158 // Size: 0x10
	struct FScriptMulticastDelegate pixuiOnLoadedDelegate; // Offset: 0x168 // Size: 0x10
	struct FScriptMulticastDelegate pixuiOnScriptStateInitDelegate; // Offset: 0x178 // Size: 0x10
	struct FScriptMulticastDelegate pixuiOnInternalErrorDelegate; // Offset: 0x188 // Size: 0x10
	DelegateProperty pixuiWinOpenDelegate; // Offset: 0x198 // Size: 0x10
	struct FScriptMulticastDelegate pixuiWinCloseDelegate; // Offset: 0x1a8 // Size: 0x10
	struct FScriptMulticastDelegate pixuiWinAlertDelegate; // Offset: 0x1b8 // Size: 0x10
	DelegateProperty pixuiWinConfirmDelegate; // Offset: 0x1c8 // Size: 0x10
	DelegateProperty pixuiWinPrompDelegate; // Offset: 0x1d8 // Size: 0x10
	struct FScriptMulticastDelegate pixuiWinTransformDelegate; // Offset: 0x1e8 // Size: 0x10
	struct FScriptMulticastDelegate pixuiWinMessageDelegate; // Offset: 0x1f8 // Size: 0x10
	struct FScriptMulticastDelegate pixuiWin_app_foreground_delegate; // Offset: 0x208 // Size: 0x10
	struct FScriptMulticastDelegate pixuiWin_app_background_delegate; // Offset: 0x218 // Size: 0x10
	char pad_0x228[0x1b0]; // Offset: 0x228 // Size: 0x1b0

	// Functions

	// Object Name: Function PixUI.PixUIWidget.SetScriptGlobalString
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScriptGlobalString(struct FString Name, struct FString Key, struct FString str); // Offset: 0x102455108 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function PixUI.PixUIWidget.SetScriptGlobalNumber
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScriptGlobalNumber(struct FString Name, struct FString Key, float Num); // Offset: 0x102454fdc // Return & Params: Num(3) Size(0x24)

	// Object Name: Function PixUI.PixUIWidget.SetScriptGlobalBoolean
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScriptGlobalBoolean(struct FString Name, struct FString Key, bool V); // Offset: 0x102454ea8 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function PixUI.PixUIWidget.SetAutoTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoTransform(bool b_auto); // Offset: 0x102454e24 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIWidget.PostPxMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PostPxMessage(struct FString fstr_Message); // Offset: 0x102454d8c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PixUI.PixUIWidget.OpenPageFromUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenPageFromUrl(struct FString fstrUrl); // Offset: 0x102454ce4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function PixUI.PixUIWidget.OpenPageFromGameAssetPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenPageFromGameAssetPath(struct FString fstr_File); // Offset: 0x102454c3c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function PixUI.PixUIWidget.OpenPageFromData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int OpenPageFromData(struct TArray<char>& arry_Data, struct FString fstr_BasePath); // Offset: 0x102454b2c // Return & Params: Num(3) Size(0x24)

	// Object Name: Function PixUI.PixUIWidget.GetSlotObjectByTagId
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* GetSlotObjectByTagId(struct FString slotTagId); // Offset: 0x102454a84 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function PixUI.PixUIWidget.GetScriptGlobalString
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetScriptGlobalString(struct FString Name, struct FString Key); // Offset: 0x102454960 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function PixUI.PixUIWidget.GetScriptGlobalNumber
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetScriptGlobalNumber(struct FString Name, struct FString Key); // Offset: 0x102454864 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function PixUI.PixUIWidget.GetScriptGlobalBoolean
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetScriptGlobalBoolean(struct FString Name, struct FString Key); // Offset: 0x102454768 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function PixUI.PixUIWidget.GetPxWinId
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetPxWinId(); // Offset: 0x102454734 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIWidget.DestroyPage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DestroyPage(); // Offset: 0x102454720 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PixUI.PixUIWidget.CreateScriptGlobal
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CreateScriptGlobal(struct FString Name); // Offset: 0x102454688 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PixUI.PixUIWidget.ClosePage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClosePage(); // Offset: 0x102454674 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class PixUI.PixUIWidgetOld
// Size: 0x268 // Inherited bytes: 0x100
struct UPixUIWidgetOld : UWidget {
	// Fields
	char pad_0x100[0x10]; // Offset: 0x100 // Size: 0x10
	struct FScriptMulticastDelegate OnCloseDelegate; // Offset: 0x110 // Size: 0x10
	struct FScriptMulticastDelegate OnDestroyDelegate; // Offset: 0x120 // Size: 0x10
	struct FScriptMulticastDelegate pixuiOnLoadedDelegate; // Offset: 0x130 // Size: 0x10
	struct FScriptMulticastDelegate pixuiOnScriptStateInitDelegate; // Offset: 0x140 // Size: 0x10
	struct FScriptMulticastDelegate pixuiOnInternalErrorDelegate; // Offset: 0x150 // Size: 0x10
	DelegateProperty pixuiWinOpenDelegate; // Offset: 0x160 // Size: 0x10
	struct FScriptMulticastDelegate pixuiWinCloseDelegate; // Offset: 0x170 // Size: 0x10
	struct FScriptMulticastDelegate pixuiWinAlertDelegate; // Offset: 0x180 // Size: 0x10
	DelegateProperty pixuiWinConfirmDelegate; // Offset: 0x190 // Size: 0x10
	DelegateProperty pixuiWinPrompDelegate; // Offset: 0x1a0 // Size: 0x10
	struct FScriptMulticastDelegate pixuiWinTransformDelegate; // Offset: 0x1b0 // Size: 0x10
	struct FScriptMulticastDelegate pixuiWinMessageDelegate; // Offset: 0x1c0 // Size: 0x10
	struct FScriptMulticastDelegate pixuiWin_app_foreground_delegate; // Offset: 0x1d0 // Size: 0x10
	struct FScriptMulticastDelegate pixuiWin_app_background_delegate; // Offset: 0x1e0 // Size: 0x10
	char pad_0x1F0[0x78]; // Offset: 0x1f0 // Size: 0x78

	// Functions

	// Object Name: Function PixUI.PixUIWidgetOld.SetScriptGlobalString
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScriptGlobalString(struct FString Name, struct FString Key, struct FString str); // Offset: 0x10245621c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function PixUI.PixUIWidgetOld.SetScriptGlobalNumber
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScriptGlobalNumber(struct FString Name, struct FString Key, float Num); // Offset: 0x1024560f0 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function PixUI.PixUIWidgetOld.SetScriptGlobalBoolean
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScriptGlobalBoolean(struct FString Name, struct FString Key, bool V); // Offset: 0x102455fbc // Return & Params: Num(3) Size(0x21)

	// Object Name: Function PixUI.PixUIWidgetOld.SetCustomLayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCustomLayer(int n_in_layer); // Offset: 0x102455f40 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIWidgetOld.SetAutoTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoTransform(bool b_auto); // Offset: 0x102455ebc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PixUI.PixUIWidgetOld.PostPxMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PostPxMessage(struct FString fstr_Message); // Offset: 0x102455e24 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PixUI.PixUIWidgetOld.OpenPageFromUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenPageFromUrl(struct FString fstr_Url); // Offset: 0x102455d7c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function PixUI.PixUIWidgetOld.OpenPageFromGameAssetPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenPageFromGameAssetPath(struct FString fstr_File); // Offset: 0x102455cd4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function PixUI.PixUIWidgetOld.OpenPageFromData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int OpenPageFromData(struct TArray<char>& arry_Data, struct FString fstr_BasePath); // Offset: 0x102455bc4 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function PixUI.PixUIWidgetOld.GetScriptGlobalString
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetScriptGlobalString(struct FString Name, struct FString Key); // Offset: 0x102455aa0 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function PixUI.PixUIWidgetOld.GetScriptGlobalNumber
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetScriptGlobalNumber(struct FString Name, struct FString Key); // Offset: 0x1024559a4 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function PixUI.PixUIWidgetOld.GetScriptGlobalBoolean
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetScriptGlobalBoolean(struct FString Name, struct FString Key); // Offset: 0x1024558a8 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function PixUI.PixUIWidgetOld.GetPxWinId
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetPxWinId(); // Offset: 0x102455874 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIWidgetOld.GetCustomLayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetCustomLayer(); // Offset: 0x102455840 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PixUI.PixUIWidgetOld.DestroyPage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DestroyPage(); // Offset: 0x10245582c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PixUI.PixUIWidgetOld.CreateScriptGlobal
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CreateScriptGlobal(struct FString Name); // Offset: 0x102455794 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PixUI.PixUIWidgetOld.ClosePage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClosePage(); // Offset: 0x102455780 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class PixUI.PxSubLayerWidget
// Size: 0x120 // Inherited bytes: 0x100
struct UPxSubLayerWidget : UWidget {
	// Fields
	char pad_0x100[0x20]; // Offset: 0x100 // Size: 0x20
};

// Object Name: Class PixUI.PxSubCtrlWidget
// Size: 0x130 // Inherited bytes: 0x120
struct UPxSubCtrlWidget : UPxSubLayerWidget {
	// Fields
	char pad_0x120[0x10]; // Offset: 0x120 // Size: 0x10
};

