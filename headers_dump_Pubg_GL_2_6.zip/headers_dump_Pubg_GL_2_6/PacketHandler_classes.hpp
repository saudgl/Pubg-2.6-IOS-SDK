//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class PacketHandler.HandlerComponentFactory
// Size: 0x28 // Inherited bytes: 0x28
struct UHandlerComponentFactory : UObject {
};

