//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C
// Size: 0x98 // Inherited bytes: 0x98
struct UGlobalUIFunctionLibrary_C : UBlueprintFunctionOverride {
	// Functions

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.OpenRechargeUI
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void OpenRechargeUI(struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.AddOrUpdateBlendable
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void AddOrUpdateBlendable(struct UCameraComponent* CameraComponent, struct UMaterialInstanceDynamic* MIDynamic, float BlendWeight, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.ProcessAndroidBack
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void ProcessAndroidBack(struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetSpecialIconWithSprite2DMatchSize
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetSpecialIconWithSprite2DMatchSize(struct UImage* Widget, struct FString specialIconPath, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetZoneDelay
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetZoneDelay(int ZoneID, int fakeShowDelay, int maxDelay, struct UObject* __WorldContext, int& Delay); // Offset: 0x1041acc2c // Return & Params: Num(5) Size(0x1c)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.UnixTimeToLocalizedTimeStrGMT
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void UnixTimeToLocalizedTimeStrGMT(int Year, int Month, int Day, int Hour, int Min, int sec, bool start_from_month, struct FString h_m_s_format, struct UObject* __WorldContext, struct FString& TimeStr); // Offset: 0x1041acc2c // Return & Params: Num(10) Size(0x48)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetItemTableRow
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetItemTableRow(int ID, struct UObject* __WorldContext, struct FBP_STRUCT_Item_type& Item); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x1a8)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SecondsToMMSS
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SecondsToMMSS(int Seconds, struct UObject* __WorldContext, struct FString& FormatTime); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.PlaySoundPopup
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void PlaySoundPopup(struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.PlaySoundToggle
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void PlaySoundToggle(struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.PlaySoundSubTab
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void PlaySoundSubTab(struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.PlaySoundTab
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void PlaySoundTab(struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetBgQualityPathWithLight
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetBgQualityPathWithLight(int Quality, struct UObject* __WorldContext, struct FString& Path); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetUIRectOffset
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetUIRectOffset(struct UObject* __WorldContext, int& Left, int& Right); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x10)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.IsConfigGameModeSubType
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void IsConfigGameModeSubType(enum class EGameModeSubType InSubType, struct UObject* Context, struct UObject* __WorldContext, bool& res); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x19)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.IsConfigGameModeType
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void IsConfigGameModeType(enum class EGameModeType InGameModeType, struct UObject* Context, struct UObject* __WorldContext, bool& res); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x19)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetGlobalLuaUI
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetGlobalLuaUI(struct UObject* WorldContextObject, struct UObject* __WorldContext, struct UGlobalLuaWidget_C*& AsGlobal Lua Widget); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetBrushWithPath
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetBrushWithPath(struct FString ImagePath, int ImageWidth, int ImageHeight, struct UObject* __WorldContext, struct FSlateBrush& OutBrush, bool& bOK); // Offset: 0x1041acc2c // Return & Params: Num(6) Size(0xd9)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SwitchSceneCameraToTransform_2
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SwitchSceneCameraToTransform_2(struct FTransform Transform, float FOV, float BlendTime, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x40)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetVector4
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetVector4(float X, float Y, float W, float H, struct UObject* __WorldContext, struct FVector4& Vector); // Offset: 0x1041acc2c // Return & Params: Num(6) Size(0x30)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.DestroyLobbyCameras
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void DestroyLobbyCameras(struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.InitAmmoDropBox
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void InitAmmoDropBox(struct UMeshComponent* MeshComponent, int LOD, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetRankIntegralBigIcon
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct FString GetRankIntegralBigIcon(struct FString Icon, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetRankIntegralSmallIcon
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct FString GetRankIntegralSmallIcon(struct FString Icon, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetRankIntegralSubIcon
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct FString GetRankIntegralSubIcon(struct FString Icon, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetArenaWeaponLightProperty
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetArenaWeaponLightProperty(struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.UpdateMPCLightDirection
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void UpdateMPCLightDirection(struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetRankInteral
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetRankInteral(struct FBP_STRUCT_RankIntegralLevel_type RankIntegralLevelInfo, struct UImage* ImageIcon, struct UTextBlock* TextBlock_Rank, struct UCanvasPanel* Canvas Panel_Star, struct UImage* Image_Star, struct UTextBlock* TextBlock_Star, bool isSegmentStarOpen, struct UImage* Image_Quality, struct UImage* vx_Image_Quality, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(10) Size(0x130)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.PlayModelSequence
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PlayModelSequence(struct FString Path, struct UObject* __WorldContext, struct ULevelSequencePlayer*& playingsequence); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SwitchSceneCameraToTransform
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SwitchSceneCameraToTransform(struct FVector Location, struct FVector Rotation, struct FVector Scale, float FOV, float BlendTime, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(6) Size(0x38)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetImageFromPath
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetImageFromPath(struct UImage* Image, struct FString IconPath, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetCharacterImage
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetCharacterImage(struct FString imgPath, struct UImage* imageItem, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetPopularityColor
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetPopularityColor(int Type, struct UObject* __WorldContext, struct FSlateColor& Output); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x38)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetBrushFromSprite
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetBrushFromSprite(struct FSlateBrush Brush, struct FString Path, struct UObject* __WorldContext, struct FSlateBrush& Result); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x188)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.LoadImage
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void LoadImage(struct UImage* Image, struct FString IconPath, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.LoadSprite
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadSprite(struct UImage* Image, struct FString IconPath, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetXieQualityPath
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetXieQualityPath(int Quality, struct UObject* __WorldContext, struct FString& Path); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetBgQualityPath
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetBgQualityPath(int Quality, struct UObject* __WorldContext, struct FString& Path); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetQualityPath
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetQualityPath(int Quality, struct UObject* __WorldContext, struct FString& Path); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetLocalizationString
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetLocalizationString(struct FString Key, struct UObject* __WorldContext, struct FString& Ret); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetCornerQuality
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetCornerQuality(struct UImage* Image, int Quality, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetPingColor
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetPingColor(float ms, struct UObject* __WorldContext, struct FLinearColor& Color); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetImgWithPath
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetImgWithPath(struct UImage* ImgRef, struct FString imgPath, bool IsMatchSize, struct UObject* __WorldContext, bool& Success); // Offset: 0x1041acc2c // Return & Params: Num(5) Size(0x29)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SendLobbyEventClickReport
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SendLobbyEventClickReport(struct FString SubEvent, struct FString para1, struct FString para2, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetItemName
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetItemName(struct FString Name, int Length, bool ChineseSensity, struct UObject* __WorldContext, struct FString& OutName); // Offset: 0x1041acc2c // Return & Params: Num(5) Size(0x30)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.UpdateImageByPath
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateImageByPath(struct UImage* Image, struct FString Path, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.ConvertRGBAStr
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void ConvertRGBAStr(struct FString RGBAstr, struct UObject* __WorldContext, float& R, float& G, float& B, float& A); // Offset: 0x1041acc2c // Return & Params: Num(6) Size(0x28)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SendGemClickReport
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SendGemClickReport(struct FString SubEvent, struct FString para1, struct FString para2, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.IsJapanOrKorea
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void IsJapanOrKorea(struct UObject* __WorldContext, bool& Result); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.UpdateImageTint
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateImageTint(struct UImage* Image, struct FLinearColor Color, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.ChangeBrushColor
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ChangeBrushColor(struct FSlateBrush Brush, struct FLinearColor Color, struct UObject* __WorldContext, struct FSlateBrush& NewBrush); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x188)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.UpdateButtonColor
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateButtonColor(struct UButton* Button, struct FLinearColor Color, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetCameraMod
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetCameraMod(struct UObject* __WorldContext, int& Mod); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.ConvertSecondsToString
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ConvertSecondsToString(int Seconds, struct UObject* __WorldContext, struct FString& timestring); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetLangueTable
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetLangueTable(struct UObject* __WorldContext, struct UUAEDataTable*& NewParam); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetGuidonInfo
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetGuidonInfo(struct FString code, struct UObject* __WorldContext, struct FBP_STRUCT_GuidonConfig_type& GuidonConfig); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x68)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetHumanLightProperty
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetHumanLightProperty(struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetWeaponLightProperty
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetWeaponLightProperty(struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetSceneSkyLightProperty
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetSceneSkyLightProperty(struct FString lightName, struct FTransform Trans, float Intensity, struct FLinearColor Color, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(5) Size(0x60)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetLobbyDefaultLightProperty
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetLobbyDefaultLightProperty(struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetAndroidKeyIsValid
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetAndroidKeyIsValid(bool bValid, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.numToTimeStrFormat
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void numToTimeStrFormat(int timeNum, struct UObject* __WorldContext, struct FString& TimeStr); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.numToTimeStr
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void numToTimeStr(int timeNum, struct UObject* __WorldContext, struct FString& TimeStr); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.IdToColor
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void IdToColor(int ID, struct UObject* __WorldContext, struct FColor& Color); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x14)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetOnLineColor
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetOnLineColor(int onlinestate, bool bonline, struct UObject* __WorldContext, struct FSlateColor& Color); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.UpdateNationImage
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateNationImage(struct UImage* Image, struct FString RoleNation, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SwitchLobbyMeshBg
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SwitchLobbyMeshBg(int BgIdx, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.IsLengthyScreen
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void IsLengthyScreen(struct UObject* __WorldContext, bool& bWideScreen); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetLobbyDragDropWidget
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void GetLobbyDragDropWidget(int dragDropType, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetItemQuality
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetItemQuality(int ItemQuality, struct UImage* imageres, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetIntimacy
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetIntimacy(struct UImage* heart, int intimacynum, struct UTextBlock* intimacyText, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetLobbyRankTexture
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetLobbyRankTexture(int rankIntegral, struct UObject* __WorldContext, struct UTexture2D*& Output); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetScenePointLightProperty
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetScenePointLightProperty(struct FString lightName, struct FTransform targetTrans, float Intensity, struct FLinearColor Color, int inverseSquareFalloff, float Radius, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(7) Size(0x68)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetSceneDirectionalLightProperty
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetSceneDirectionalLightProperty(struct FString lightName, struct FTransform targetTrans, float Intensity, struct FLinearColor Color, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(5) Size(0x60)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetCorpsSegmentLimit
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetCorpsSegmentLimit(struct UCommon_RankIntegralLevel_Style_Small_UIBP_C* segmentWidget, struct UTextBlock* textWidget, int LevelID, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetCorpsLevelLimit
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetCorpsLevelLimit(struct UTextBlock* textWidget, int Level, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetLobbyCorpsIcon
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetLobbyCorpsIcon(int IconID, struct UObject* __WorldContext, struct UTexture2D*& Value); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetPlatfromDisplayName
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetPlatfromDisplayName(struct FString strChannel, struct UObject* __WorldContext, struct FString& showChannel); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetPlayerPrefs
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetPlayerPrefs(struct UObject* __WorldContext, struct UPlayerPrefs_C*& bp_playerprefs); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.ShowLobbyMenuEnterAnimation
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void ShowLobbyMenuEnterAnimation(struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetLobbyGlobalBp
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetLobbyGlobalBp(struct UObject* __WorldContext, struct UGlobal_Bp_C*& AsGlobal Bp); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetLobbyFrameTexture
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetLobbyFrameTexture(int frameLevel, struct UObject* __WorldContext, struct UTexture2D*& Output); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.InvoleBpFunctionNoFetch
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void InvoleBpFunctionNoFetch(struct FString InName, struct FString InFunname, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.CheckChatPrivacyAcceptStatus
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void CheckChatPrivacyAcceptStatus(struct UObject* __WorldContext, bool& ChatPrivacyAcceptStatus); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetGVoiceInterface
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetGVoiceInterface(struct UObject* __WorldContext, struct UGVoiceInterface*& outputObj); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.OpenUseItemUI
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void OpenUseItemUI(struct FString itemInsID, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.ConvertURLByLanguage
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void ConvertURLByLanguage(struct FString URL, struct UObject* __WorldContext, struct FString& convertedURL); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.isChineseSymbol
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void isChineseSymbol(struct FString Text, struct UObject* __WorldContext, bool& Result); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x19)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.isSpace
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void isSpace(struct FString Text, struct UObject* __WorldContext, bool& Result); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x19)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetNationInfo
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetNationInfo(struct FString NationCode, struct UObject* __WorldContext, struct FBP_STRUCT_RegionConfig_type& NationInfo); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0xa0)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SetImageWithSpriteRes
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetImageWithSpriteRes(struct FString ResPath, struct UImage* Image, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetNationSwitch
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetNationSwitch(struct FString Name, struct UObject* __WorldContext, bool& Ret); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x19)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetBpLuaObject
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetBpLuaObject(struct FString bp_name, struct UObject* __WorldContext, struct ALuaClassObj*& Lua obj); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.CheckIfMenuOpen
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void CheckIfMenuOpen(int MenuId, struct UObject* __WorldContext, bool& Ret); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetValidStringAll
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetValidStringAll(struct FString Text, bool CanBeEnglish, bool CanBeNumber, bool CanBeWhiteSpace, bool CanBeChinese, bool CanBeSpace, bool CanBeChineseSymbol, struct UObject* __WorldContext, struct FString& validText); // Offset: 0x1041acc2c // Return & Params: Num(9) Size(0x30)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.UpdateLobbyRedpointStatus
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void UpdateLobbyRedpointStatus(bool IsShow, int ModeID, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x10)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetItemTimeS_Server
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetItemTimeS_Server(int expire_ts, int valid_hours, struct UObject* __WorldContext, struct FString& time_s, bool& is_have_limit); // Offset: 0x1041acc2c // Return & Params: Num(5) Size(0x21)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetItemTimeS
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetItemTimeS(int res_id, int FirstTimeNum, struct UObject* __WorldContext, struct FString& time_s, bool& is_have_limit); // Offset: 0x1041acc2c // Return & Params: Num(5) Size(0x21)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.TimeNumToTimeS
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void TimeNumToTimeS(int time_num, struct UObject* __WorldContext, struct FString& time_s); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.ShowItemTipsByButton
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void ShowItemTipsByButton(int ItemID, struct UButton* Button, int validHours, bool isShowCloseBtn, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(5) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.CloseItemTips
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void CloseItemTips(struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.CreateUAEUserWidget
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void CreateUAEUserWidget(struct UUAEUserWidget* Class, struct UUAEUserWidget* Parent, struct UObject* __WorldContext, struct UUAEUserWidget*& Widget); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.PlaySoundCloseButton
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void PlaySoundCloseButton(struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.ShowEffect
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void ShowEffect(struct TArray<struct UWidget*>& Widget, bool IsShow, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.IsWidgetVisible
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void IsWidgetVisible(struct UWidget* Widget, struct UObject* __WorldContext, bool& Visible); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.PlaySoundClickButton
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void PlaySoundClickButton(struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.IsChinese
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void IsChinese(struct FString Text, struct UObject* __WorldContext, bool& Result); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x19)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.SendBAReport
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SendBAReport(int ButtonType, int Reason, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x10)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.IsValidChar
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void IsValidChar(struct FString Text, bool CanBeEnglish, bool CanBeNumber, bool CanBeWhiteSpace, bool CanBeChinese, bool CanBeSpace, bool CanBeChineseSymbol, struct UObject* __WorldContext, bool& Result); // Offset: 0x1041acc2c // Return & Params: Num(9) Size(0x21)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.IsNumber
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void IsNumber(struct FString Text, struct UObject* __WorldContext, bool& Result); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x19)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.IsWhiteSpace
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void IsWhiteSpace(struct FString Text, struct UObject* __WorldContext, bool& Result); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x19)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetTextLength
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetTextLength(struct FString Text, bool ChineseSensity, struct UObject* __WorldContext, int& Length); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x24)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.BoolToVisible
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void BoolToVisible(bool Visible, bool collapse, bool isButton, struct UObject* __WorldContext, enum class ESlateVisibility& Visibility); // Offset: 0x1041acc2c // Return & Params: Num(5) Size(0x11)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetValidString
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetValidString(int maxLength, struct FString Text, bool CanBeEnglish, bool CanBeNumber, bool CanBeWhiteSpace, bool CanBeChinese, bool ChineseSensity, bool CanBeSpace, struct UObject* __WorldContext, struct FString& validText); // Offset: 0x1041acc2c // Return & Params: Num(10) Size(0x38)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.IsEnglish
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void IsEnglish(struct FString Text, struct UObject* __WorldContext, bool& Result); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x19)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.UpdateRankName
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateRankName(struct UTextBlock* Text, int Level, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.UpdateRankIcon
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateRankIcon(struct UImage* imageObj, int Level, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetGlobalData
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetGlobalData(struct UObject* __WorldContext, struct Abp_global_C*& globalObj); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.InvoleBpFunction
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void InvoleBpFunction(struct FString bp_name, struct FString func_name, struct UObject* __WorldContext); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetLocalizeString
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetLocalizeString(int ID, struct FString string1, struct FString string2, struct FString string3, struct UObject* __WorldContext, struct FString& TextValue); // Offset: 0x1041acc2c // Return & Params: Num(6) Size(0x50)

	// Object Name: Function GlobalUIFunctionLibrary.GlobalUIFunctionLibrary_C.GetGlobalUIEventDispatcher
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetGlobalUIEventDispatcher(struct UFrontendHUD* FrontendHUD, struct UObject* __WorldContext, struct UGlobalUIEventDispatcher_BP_C*& NewParam); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x18)
};

