//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass VehicleAvatarHandleBase_BP.VehicleAvatarHandleBase_BP_C
// Size: 0x498 // Inherited bytes: 0x498
struct UVehicleAvatarHandleBase_BP_C : UBackpackVehicleAvatarHandle {
};

