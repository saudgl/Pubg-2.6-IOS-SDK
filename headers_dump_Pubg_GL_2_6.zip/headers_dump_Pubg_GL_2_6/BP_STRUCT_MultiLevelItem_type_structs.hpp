//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_MultiLevelItem_type.BP_STRUCT_MultiLevelItem_type
// Size: 0x10 // Inherited bytes: 0x00
struct FBP_STRUCT_MultiLevelItem_type {
	// Fields
	int GroupID_5_3BB8908055FC2C9220DCD7860F82E614; // Offset: 0x00 // Size: 0x04
	int ItemID_6_3DFE91004236D48E3BE164890D1603F4; // Offset: 0x04 // Size: 0x04
	int Level_7_095F68007727584A67D53A8602D3389C; // Offset: 0x08 // Size: 0x04
	int MoudleID_8_4CC906C00848B807320F112409F904E4; // Offset: 0x0c // Size: 0x04
};

