//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Bottom_right_UIBP.Lobby_Bottom_Right_UIBP_C
// Size: 0x280 // Inherited bytes: 0x260
struct ULobby_Bottom_Right_UIBP_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 // Size: 0x08
	struct ULobby_Main_Expression_UIBP_C* Lobby_Main_Expression_UIBP; // Offset: 0x268 // Size: 0x08
	struct ULobby_Main_Pet_UIBP_C* Lobby_Main_Pet_UIBP; // Offset: 0x270 // Size: 0x08
	int preWidth; // Offset: 0x278 // Size: 0x04
	int preHeight; // Offset: 0x27c // Size: 0x04

	// Functions

	// Object Name: Function Lobby_Bottom_right_UIBP.Lobby_Bottom_Right_UIBP_C.CheckAdaption
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void CheckAdaption(bool& bAdapt, float& Width, float& Height); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Lobby_Bottom_right_UIBP.Lobby_Bottom_Right_UIBP_C.GetAdaptWidthHeight
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetAdaptWidthHeight(float Width, float Height, float& adaptWidth, float& adaptHeight); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Lobby_Bottom_right_UIBP.Lobby_Bottom_Right_UIBP_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function Lobby_Bottom_right_UIBP.Lobby_Bottom_Right_UIBP_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Bottom_right_UIBP.Lobby_Bottom_Right_UIBP_C.ExecuteUbergraph_Lobby_Bottom_Right_UIBP
	// Flags: [HasDefaults]
	void ExecuteUbergraph_Lobby_Bottom_Right_UIBP(int EntryPoint); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)
};

