//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Common_Certification_UIBP.Common_Certification_UIBP_C
// Size: 0x319 // Inherited bytes: 0x2d0
struct UCommon_Certification_UIBP_C : ULuaUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x2d0 // Size: 0x08
	struct UButton* Button_Tips; // Offset: 0x2d8 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x2e0 // Size: 0x08
	struct UImage* Image_bg; // Offset: 0x2e8 // Size: 0x08
	struct UImage* Image_Certification1; // Offset: 0x2f0 // Size: 0x08
	struct UImage* Image_Certification2; // Offset: 0x2f8 // Size: 0x08
	struct USizeBox* SizeBox_1; // Offset: 0x300 // Size: 0x08
	struct UTextBlock* TextBlock_Title; // Offset: 0x308 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_1; // Offset: 0x310 // Size: 0x08
	bool OnlyImage; // Offset: 0x318 // Size: 0x01

	// Functions

	// Object Name: Function Common_Certification_UIBP.Common_Certification_UIBP_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Certification_UIBP.Common_Certification_UIBP_C.ExecuteUbergraph_Common_Certification_UIBP
	// Flags: [None]
	void ExecuteUbergraph_Common_Certification_UIBP(int EntryPoint); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)
};

