//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_TxMissionMapMode_type.BP_STRUCT_TxMissionMapMode_type
// Size: 0x38 // Inherited bytes: 0x00
struct FBP_STRUCT_TxMissionMapMode_type {
	// Fields
	int IsDefault_1_60FF1A001E02FF964E6DDC2D05E252E4; // Offset: 0x00 // Size: 0x04
	int MapID_3_1802048073B979802E7096C60ED92B84; // Offset: 0x04 // Size: 0x04
	struct FString Name_8_5FA9BA0030E3436445DDF0B205EDEEC5; // Offset: 0x08 // Size: 0x10
	int Prestige_9_5D990A80713AE524270F7137023F4205; // Offset: 0x18 // Size: 0x04
	int Worth_11_7FDEFEC007C262D128DE42D50ED8C6F8; // Offset: 0x1c // Size: 0x04
	int DescID_12_6C483CC039E901DD5FDD82FC0C066234; // Offset: 0x20 // Size: 0x04
	int ModeID_13_43A8BE401B4532157985E7880DAF5C34; // Offset: 0x24 // Size: 0x04
	int ModeType_14_74846380625428FE6F82CCD60F5F6DC5; // Offset: 0x28 // Size: 0x04
	int TicketID_15_56E2160063678596591B4DD0057425D4; // Offset: 0x2c // Size: 0x04
	int TicketNum_16_1E0EDEC07147CF7F60B400E0074265ED; // Offset: 0x30 // Size: 0x04
	int MainModeID_17_38149F805E5DD13C4085D5E908E834C4; // Offset: 0x34 // Size: 0x04
};

