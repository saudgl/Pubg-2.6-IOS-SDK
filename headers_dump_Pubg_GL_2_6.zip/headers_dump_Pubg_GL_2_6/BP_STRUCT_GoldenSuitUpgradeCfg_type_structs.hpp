//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_GoldenSuitUpgradeCfg_type.BP_STRUCT_GoldenSuitUpgradeCfg_type
// Size: 0x5c // Inherited bytes: 0x00
struct FBP_STRUCT_GoldenSuitUpgradeCfg_type {
	// Fields
	int ItemID_1_5225E200346E8D367C280D560FD79094; // Offset: 0x00 // Size: 0x04
	int MatID1_2_5084D30079DBD5AC313F49840FE5BC31; // Offset: 0x04 // Size: 0x04
	int MatID2_3_5085D34079DBD5AD313F49870FE5BC32; // Offset: 0x08 // Size: 0x04
	int MatNum1_4_578CDBC01380C24B652ADED20E5C50F1; // Offset: 0x0c // Size: 0x04
	int MatNum2_5_578DDC001380C24C652ADED30E5C50F2; // Offset: 0x10 // Size: 0x04
	int RelicID_6_150E7A00068CC8307BE8D3540571E324; // Offset: 0x14 // Size: 0x04
	int ShareID_7_75B17B000B6C0C2C355BC5F3043B9D24; // Offset: 0x18 // Size: 0x04
	int Star_8_29E461804C1B742032A6D59E014F77B2; // Offset: 0x1c // Size: 0x04
	int SubTabID1_9_36DB1AC0425C037B6E9E66A704B39A11; // Offset: 0x20 // Size: 0x04
	int SubTabID2_10_36DC1B00425C037C6E9E66A404B39A12; // Offset: 0x24 // Size: 0x04
	int TabDesc1_16_052B6CC048F00D457ACB808F0A5B8611; // Offset: 0x28 // Size: 0x04
	int TabDesc2_17_052C6D0048F00D467ACB808C0A5B8612; // Offset: 0x2c // Size: 0x04
	int TabID_13_525124005E64272E33CB10A404F7A5C4; // Offset: 0x30 // Size: 0x04
	int Index_14_227DD9004E4E21643303CB8C04E399D8; // Offset: 0x34 // Size: 0x04
	int Period_15_740773C01B84CFB37A7BD5940FB1BF14; // Offset: 0x38 // Size: 0x04
	int Effect1_18_3B80BA803C4E871C2C820DDF061FAE91; // Offset: 0x3c // Size: 0x04
	int Effect2_19_3B81BAC03C4E871D2C820DDE061FAE92; // Offset: 0x40 // Size: 0x04
	int ActID_20_462E64402FAE4FE73AB506F604EA7BC4; // Offset: 0x44 // Size: 0x04
	int NeedJump_21_752D41001982E8C86E0638E2068A55D0; // Offset: 0x48 // Size: 0x04
	int SecondMatCount_23_60D7DCC00387AD2F7C1126460E3D6424; // Offset: 0x4c // Size: 0x04
	int SecondMatID_24_7D683DC021B04F9110425B600087E384; // Offset: 0x50 // Size: 0x04
	int LimitMatID1_25_2C5BD2C0468114A35B7D71330DC7BC61; // Offset: 0x54 // Size: 0x04
	int LimitMatID2_26_2C5CD300468114A45B7D71340DC7BC62; // Offset: 0x58 // Size: 0x04
};

