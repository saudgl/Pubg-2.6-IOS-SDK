//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct Basic.AttrModifyItem
// Size: 0x48 // Inherited bytes: 0x00
struct FAttrModifyItem {
	// Fields
	struct TArray<struct FCacheAffactTargetInfo> AffectTargetsCachInfo; // Offset: 0x00 // Size: 0x10
	struct FString AttrModifyItemName; // Offset: 0x10 // Size: 0x10
	struct FString AttrName; // Offset: 0x20 // Size: 0x10
	int AttrId; // Offset: 0x30 // Size: 0x04
	int CompareId; // Offset: 0x34 // Size: 0x04
	enum class EAttrOperator ModifierOp; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x3]; // Offset: 0x39 // Size: 0x03
	float ModifierValue; // Offset: 0x3c // Size: 0x04
	bool IsEnable; // Offset: 0x40 // Size: 0x01
	bool ClientSimulate; // Offset: 0x41 // Size: 0x01
	char pad_0x42[0x6]; // Offset: 0x42 // Size: 0x06
};

// Object Name: ScriptStruct Basic.CacheAffactTargetInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FCacheAffactTargetInfo {
	// Fields
	struct TWeakObjectPtr<struct AActor> AffectTarget; // Offset: 0x00 // Size: 0x08
	float FinalAddValue; // Offset: 0x08 // Size: 0x04
	uint32_t CModifyUid; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Basic.AttrAffected
// Size: 0x18 // Inherited bytes: 0x00
struct FAttrAffected {
	// Fields
	struct FString AttrName; // Offset: 0x00 // Size: 0x10
	struct AActor* AffectedActor; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct Basic.AttrRegisterItem
// Size: 0x30 // Inherited bytes: 0x00
struct FAttrRegisterItem {
	// Fields
	struct FString AttrName; // Offset: 0x00 // Size: 0x10
	enum class EAttrVariableType AttrVariableType; // Offset: 0x10 // Size: 0x01
	bool HasReplicatedTag; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x1e]; // Offset: 0x12 // Size: 0x1e
};

// Object Name: ScriptStruct Basic.ModAttrSimulateSyncItem
// Size: 0x08 // Inherited bytes: 0x00
struct FModAttrSimulateSyncItem {
	// Fields
	int AttrId; // Offset: 0x00 // Size: 0x04
	float FinalValue; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Basic.RelateAttributeGroup
// Size: 0x50 // Inherited bytes: 0x00
struct FRelateAttributeGroup {
	// Fields
	struct TMap<int, struct FString> RelateAttributes; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Basic.AttributeExpand
// Size: 0x48 // Inherited bytes: 0x00
struct FAttributeExpand {
	// Fields
	struct FString AttrName; // Offset: 0x00 // Size: 0x10
	struct FString AttrDesc; // Offset: 0x10 // Size: 0x10
	int RelateTypeId; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FString RelateGroup; // Offset: 0x28 // Size: 0x10
	float Value; // Offset: 0x38 // Size: 0x04
	int nValue; // Offset: 0x3c // Size: 0x04
	char bValue; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
};

// Object Name: ScriptStruct Basic.AttrDynamicModifier
// Size: 0xa8 // Inherited bytes: 0x00
struct FAttrDynamicModifier {
	// Fields
	struct TMap<struct FString, struct FAttrDynamicModifyTarget> ModifyAttrs; // Offset: 0x00 // Size: 0x50
	struct TMap<struct FString, struct FAttrDynamicModifyConfig> ModifyConfigs; // Offset: 0x50 // Size: 0x50
	struct UAttrModifyComponent* Component; // Offset: 0xa0 // Size: 0x08
};

// Object Name: ScriptStruct Basic.AttrDynamicModifyConfig
// Size: 0x38 // Inherited bytes: 0x00
struct FAttrDynamicModifyConfig {
	// Fields
	bool IsOneceModify; // Offset: 0x00 // Size: 0x01
	bool HasLimitAttr; // Offset: 0x01 // Size: 0x01
	bool HasMaxAttr; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x5]; // Offset: 0x03 // Size: 0x05
	struct FString AttrName; // Offset: 0x08 // Size: 0x10
	struct FString LimitAttrName; // Offset: 0x18 // Size: 0x10
	struct FString MaxAttrName; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct Basic.AttrDynamicModifyTarget
// Size: 0x18 // Inherited bytes: 0x00
struct FAttrDynamicModifyTarget {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct TArray<struct FAttrDynamicModifyItem> List; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Basic.AttrDynamicModifyItem
// Size: 0x28 // Inherited bytes: 0x00
struct FAttrDynamicModifyItem {
	// Fields
	char pad_0x0[0x1c]; // Offset: 0x00 // Size: 0x1c
	struct TWeakObjectPtr<struct UObject> Causer; // Offset: 0x1c // Size: 0x08
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct Basic.ItemDefineID
// Size: 0x18 // Inherited bytes: 0x00
struct FItemDefineID {
	// Fields
	int Type; // Offset: 0x00 // Size: 0x04
	int TypeSpecificID; // Offset: 0x04 // Size: 0x04
	bool bValidItem; // Offset: 0x08 // Size: 0x01
	bool bValidInstance; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x6]; // Offset: 0x0a // Size: 0x06
	uint64 InstanceID; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct Basic.ClientBaseInfo
// Size: 0x178 // Inherited bytes: 0x00
struct FClientBaseInfo {
	// Fields
	struct FString OpenID; // Offset: 0x00 // Size: 0x10
	uint64 RoleID; // Offset: 0x10 // Size: 0x08
	struct FString GameSvrId; // Offset: 0x18 // Size: 0x10
	struct FString GameAppID; // Offset: 0x28 // Size: 0x10
	uint16_t AreaID; // Offset: 0x38 // Size: 0x02
	uint8_t PlatID; // Offset: 0x3a // Size: 0x01
	char pad_0x3B[0x5]; // Offset: 0x3b // Size: 0x05
	struct FString ZoneID; // Offset: 0x40 // Size: 0x10
	uint64 BattleID; // Offset: 0x50 // Size: 0x08
	uint64 GameID; // Offset: 0x58 // Size: 0x08
	struct FString BattleServerIP; // Offset: 0x60 // Size: 0x10
	uint32_t BattleServerPort; // Offset: 0x70 // Size: 0x04
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
	struct FString UserName; // Offset: 0x78 // Size: 0x10
	struct FString PicUrl; // Offset: 0x88 // Size: 0x10
	uint32_t PlayerKey; // Offset: 0x98 // Size: 0x04
	char pad_0x9C[0x4]; // Offset: 0x9c // Size: 0x04
	uint8_t WeatherID; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x7]; // Offset: 0xa1 // Size: 0x07
	struct FString WeatherLevelName; // Offset: 0xa8 // Size: 0x10
	float WeatherTime; // Offset: 0xb8 // Size: 0x04
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
	struct TArray<int> MrpcsData; // Offset: 0xc0 // Size: 0x10
	char pad_0xD0[0x8]; // Offset: 0xd0 // Size: 0x08
	struct TMap<int, struct FString> AdvConfig; // Offset: 0xd8 // Size: 0x50
	struct TMap<struct FString, struct UTexture2D*> AdvTextureList; // Offset: 0x128 // Size: 0x50
};

// Object Name: ScriptStruct Basic.BuffInstancedItem
// Size: 0x40 // Inherited bytes: 0x00
struct FBuffInstancedItem {
	// Fields
	struct FName BuffName; // Offset: 0x00 // Size: 0x08
	int BuffID; // Offset: 0x08 // Size: 0x04
	struct TWeakObjectPtr<struct USTBaseBuff> Buff; // Offset: 0x0c // Size: 0x08
	int LayerCount; // Offset: 0x14 // Size: 0x04
	struct AController* CauserPawnController; // Offset: 0x18 // Size: 0x08
	bool PendingRemove; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	float Expiry; // Offset: 0x24 // Size: 0x04
	struct AActor* Target; // Offset: 0x28 // Size: 0x08
	struct AActor* BuffApplier; // Offset: 0x30 // Size: 0x08
	int BuffIndex; // Offset: 0x38 // Size: 0x04
	uint32_t DamageCauseID; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct Basic.UTBuffSynData
// Size: 0x28 // Inherited bytes: 0x00
struct FUTBuffSynData {
	// Fields
	struct FName BuffName; // Offset: 0x00 // Size: 0x08
	struct AController* BuffCauser; // Offset: 0x08 // Size: 0x08
	int LayerCount; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct AActor* BuffApplierActor; // Offset: 0x18 // Size: 0x08
	float RemainingTime; // Offset: 0x20 // Size: 0x04
	float ExpireTime; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct Basic.BuffInstInfo
// Size: 0x14 // Inherited bytes: 0x00
struct FBuffInstInfo {
	// Fields
	int BuffID; // Offset: 0x00 // Size: 0x04
	int InstID; // Offset: 0x04 // Size: 0x04
	int CauseSkillID; // Offset: 0x08 // Size: 0x04
	char LayerCount; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	float EndTime; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct Basic.ClientSyncBrief
// Size: 0x28 // Inherited bytes: 0x00
struct FClientSyncBrief {
	// Fields
	int InstID; // Offset: 0x00 // Size: 0x04
	char LayerCount; // Offset: 0x04 // Size: 0x01
	char Level; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	int BuffID; // Offset: 0x08 // Size: 0x04
	int CauseSkillID; // Offset: 0x0c // Size: 0x04
	struct AActor* CauseActor; // Offset: 0x10 // Size: 0x08
	float SyncTime; // Offset: 0x18 // Size: 0x04
	float Duration; // Offset: 0x1c // Size: 0x04
	float EndTime; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct Basic.BuffIncNetArray
// Size: 0x20 // Inherited bytes: 0x00
struct FBuffIncNetArray {
	// Fields
	struct TArray<struct FBuffNetArrayUnit> IncArray; // Offset: 0x00 // Size: 0x10
	char pad_0x10[0x10]; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Basic.BuffNetArrayUnit
// Size: 0x30 // Inherited bytes: 0x00
struct FBuffNetArrayUnit {
	// Fields
	struct FClientSyncBrief Unit; // Offset: 0x00 // Size: 0x28
	bool bMarkDelete; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

// Object Name: ScriptStruct Basic.ItemAssociation
// Size: 0x28 // Inherited bytes: 0x00
struct FItemAssociation {
	// Fields
	int AssociationType; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FItemDefineID AssociationTargetDefineID; // Offset: 0x08 // Size: 0x18
	struct UItemHandleBase* AssociationTargetHandle; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct Basic.BattleItemUseTarget
// Size: 0x28 // Inherited bytes: 0x00
struct FBattleItemUseTarget {
	// Fields
	struct FItemDefineID TargetDefineID; // Offset: 0x00 // Size: 0x18
	int TargetAssociationType; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct AActor* TargetActor; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct Basic.ItemData
// Size: 0x58 // Inherited bytes: 0x00
struct FItemData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct FItemDefineID DefineID; // Offset: 0x08 // Size: 0x18
	struct FString Name; // Offset: 0x20 // Size: 0x10
	struct FString Desc; // Offset: 0x30 // Size: 0x10
	struct FString Icon; // Offset: 0x40 // Size: 0x10
	struct UItemHandleBase* ItemHandle; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct Basic.BattleItemData
// Size: 0xb8 // Inherited bytes: 0x58
struct FBattleItemData : FItemData {
	// Fields
	int Count; // Offset: 0x58 // Size: 0x04
	bool bEquipping; // Offset: 0x5c // Size: 0x01
	char pad_0x5D[0x3]; // Offset: 0x5d // Size: 0x03
	struct TArray<struct FBattleItemAdditionalData> AdditionalData; // Offset: 0x60 // Size: 0x10
	int Durability; // Offset: 0x70 // Size: 0x04
	enum class EItemStoreArea ItemStoreArea; // Offset: 0x74 // Size: 0x01
	char pad_0x75[0x3]; // Offset: 0x75 // Size: 0x03
	struct FBattleItemFeatureData FeatureData; // Offset: 0x78 // Size: 0x2c
	char pad_0xA4[0x4]; // Offset: 0xa4 // Size: 0x04
	struct TArray<struct FItemAssociation> Associations; // Offset: 0xa8 // Size: 0x10
};

// Object Name: ScriptStruct Basic.BattleItemFeatureData
// Size: 0x2c // Inherited bytes: 0x00
struct FBattleItemFeatureData {
	// Fields
	float UnitWeight; // Offset: 0x00 // Size: 0x04
	int MaxCount; // Offset: 0x04 // Size: 0x04
	int CountLimit; // Offset: 0x08 // Size: 0x04
	bool bUnique; // Offset: 0x0c // Size: 0x01
	bool bStackable; // Offset: 0x0d // Size: 0x01
	bool bEquippable; // Offset: 0x0e // Size: 0x01
	bool bConsumable; // Offset: 0x0f // Size: 0x01
	bool bAutoEquipAndDrop; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	int ItemAttrsFlag; // Offset: 0x14 // Size: 0x04
	int SortingPriority; // Offset: 0x18 // Size: 0x04
	int Worth; // Offset: 0x1c // Size: 0x04
	int ItemCapacity; // Offset: 0x20 // Size: 0x04
	int ItemDurability; // Offset: 0x24 // Size: 0x04
	int ItemType; // Offset: 0x28 // Size: 0x04
};

// Object Name: ScriptStruct Basic.BattleItemAdditionalData
// Size: 0x28 // Inherited bytes: 0x00
struct FBattleItemAdditionalData {
	// Fields
	enum class EBattleItemAdditionalDataType EDataType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int IntData; // Offset: 0x04 // Size: 0x04
	struct FString StringData; // Offset: 0x08 // Size: 0x10
	float FloatData; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0xc]; // Offset: 0x1c // Size: 0x0c
};

// Object Name: ScriptStruct Basic.BattleItemPickupInfo
// Size: 0x58 // Inherited bytes: 0x00
struct FBattleItemPickupInfo {
	// Fields
	struct UObject* Source; // Offset: 0x00 // Size: 0x08
	int Count; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FBattleItemAdditionalData> AdditionalData; // Offset: 0x10 // Size: 0x10
	bool bAutoEquip; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
	struct FBattleItemUseTarget AutoEquipTarget; // Offset: 0x28 // Size: 0x28
	bool bDropOnDead; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x7]; // Offset: 0x51 // Size: 0x07
};

// Object Name: ScriptStruct Basic.BattleItemSpectatingData
// Size: 0x08 // Inherited bytes: 0x00
struct FBattleItemSpectatingData {
	// Fields
	int TypeSpecificID; // Offset: 0x00 // Size: 0x04
	int AdditionalData; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Basic.ItemFixTableItem
// Size: 0x18 // Inherited bytes: 0x00
struct FItemFixTableItem {
	// Fields
	int ValidTimes; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString ExTime; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Basic.MultiStringMap
// Size: 0x50 // Inherited bytes: 0x00
struct FMultiStringMap {
	// Fields
	struct TMap<int, struct FStringMap> StringMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Basic.StringMap
// Size: 0x50 // Inherited bytes: 0x00
struct FStringMap {
	// Fields
	struct TMap<struct FString, struct FString> Data; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Basic.AttrModifyRepItem
// Size: 0x10 // Inherited bytes: 0x00
struct FAttrModifyRepItem {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct AActor* TargetActor; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct Basic.AttrRowData
// Size: 0x28 // Inherited bytes: 0x00
struct FAttrRowData {
	// Fields
	int AttrGroup; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString AttrName; // Offset: 0x08 // Size: 0x10
	enum class EAttrVariableType AttrVariableType; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	float OriginalValue; // Offset: 0x1c // Size: 0x04
	float MinValue; // Offset: 0x20 // Size: 0x04
	float MaxValue; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct Basic.AttrModifyGroupItem
// Size: 0x10 // Inherited bytes: 0x00
struct FAttrModifyGroupItem {
	// Fields
	struct TArray<struct FAttrModifyItem> AttrModifyItem; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Basic.PlayerThrowInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FPlayerThrowInfo {
	// Fields
	struct TArray<struct FBattleItemSpectatingData> PlayerThrowInfo; // Offset: 0x00 // Size: 0x10
	uint32_t PlayerKey; // Offset: 0x10 // Size: 0x04
	uint32_t TeamID; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Basic.PlayerBackPackInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FPlayerBackPackInfo {
	// Fields
	struct TArray<struct FBattleItemSpectatingData> PlayerBackPackInfo; // Offset: 0x00 // Size: 0x10
	int MainWeapon1TypeSpecificID; // Offset: 0x10 // Size: 0x04
	int MainWeapon1AmmoNuminClip; // Offset: 0x14 // Size: 0x04
	int MainWeapon2TypeSpecificID; // Offset: 0x18 // Size: 0x04
	int MainWeapon2AmmoNuminClip; // Offset: 0x1c // Size: 0x04
	uint32_t PlayerKey; // Offset: 0x20 // Size: 0x04
	uint32_t TeamID; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct Basic.BattleItemPickupAfterLand
// Size: 0x78 // Inherited bytes: 0x00
struct FBattleItemPickupAfterLand {
	// Fields
	struct FItemDefineID DefineID; // Offset: 0x00 // Size: 0x18
	struct FBattleItemPickupInfo PickupInfo; // Offset: 0x18 // Size: 0x58
	enum class EBattleItemPickupReason Reason; // Offset: 0x70 // Size: 0x01
	enum class EBattleItemClientPickupType BattleItemClientPickupType; // Offset: 0x71 // Size: 0x01
	char pad_0x72[0x6]; // Offset: 0x72 // Size: 0x06
};

// Object Name: ScriptStruct Basic.TagItemList
// Size: 0x10 // Inherited bytes: 0x00
struct FTagItemList {
	// Fields
	struct TArray<int> tagList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Basic.TagOneItem
// Size: 0x08 // Inherited bytes: 0x00
struct FTagOneItem {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct Basic.PickupProposeData
// Size: 0x188 // Inherited bytes: 0x00
struct FPickupProposeData {
	// Fields
	struct TArray<struct FPickupFirstCount> pickFirst; // Offset: 0x00 // Size: 0x10
	int closeSubType; // Offset: 0x10 // Size: 0x04
	int crossbowSubType; // Offset: 0x14 // Size: 0x04
	int panID; // Offset: 0x18 // Size: 0x04
	int pistolSubType; // Offset: 0x1c // Size: 0x04
	int gunType; // Offset: 0x20 // Size: 0x04
	int specialType; // Offset: 0x24 // Size: 0x04
	int specialType2; // Offset: 0x28 // Size: 0x04
	int lens2ID; // Offset: 0x2c // Size: 0x04
	int lens3ID; // Offset: 0x30 // Size: 0x04
	int lens4ID; // Offset: 0x34 // Size: 0x04
	int lens6ID; // Offset: 0x38 // Size: 0x04
	int lens8ID; // Offset: 0x3c // Size: 0x04
	int ID2Type; // Offset: 0x40 // Size: 0x04
	int pistolClipSubType; // Offset: 0x44 // Size: 0x04
	int SubMachineGunClipSubType; // Offset: 0x48 // Size: 0x04
	int SniperClipSubType; // Offset: 0x4c // Size: 0x04
	int RifleClipSubType; // Offset: 0x50 // Size: 0x04
	int gasSubID; // Offset: 0x54 // Size: 0x04
	int backSubType; // Offset: 0x58 // Size: 0x04
	int MedicalSubType; // Offset: 0x5c // Size: 0x04
	int back3ID; // Offset: 0x60 // Size: 0x04
	int BandageID; // Offset: 0x64 // Size: 0x04
	int QuickBandageID; // Offset: 0x68 // Size: 0x04
	int EnergyDrinksID; // Offset: 0x6c // Size: 0x04
	int AdrenalineID; // Offset: 0x70 // Size: 0x04
	int AnodyneID; // Offset: 0x74 // Size: 0x04
	int Medical1ID; // Offset: 0x78 // Size: 0x04
	int QuickMedical1ID; // Offset: 0x7c // Size: 0x04
	int Medical2ID; // Offset: 0x80 // Size: 0x04
	int AntidoteID; // Offset: 0x84 // Size: 0x04
	int BatteryChipID; // Offset: 0x88 // Size: 0x04
	int GameCoinID; // Offset: 0x8c // Size: 0x04
	int ZhenBaoDan; // Offset: 0x90 // Size: 0x04
	int YanWuDan; // Offset: 0x94 // Size: 0x04
	int RanShaoPing; // Offset: 0x98 // Size: 0x04
	int ShouLei; // Offset: 0x9c // Size: 0x04
	int FlarePistolID; // Offset: 0xa0 // Size: 0x04
	char pad_0xA4[0x4]; // Offset: 0xa4 // Size: 0x04
	struct TArray<int> SideMirrorList; // Offset: 0xa8 // Size: 0x10
	struct TArray<int> MirrorList; // Offset: 0xb8 // Size: 0x10
	int ViscidityBomb; // Offset: 0xc8 // Size: 0x04
	int GrenadeZombie; // Offset: 0xcc // Size: 0x04
	int GrenadeYedan; // Offset: 0xd0 // Size: 0x04
	int DefaultMedicineNum; // Offset: 0xd4 // Size: 0x04
	int helmetSubType; // Offset: 0xd8 // Size: 0x04
	int armorSubType; // Offset: 0xdc // Size: 0x04
	int ScoreItemSubType; // Offset: 0xe0 // Size: 0x04
	int SpecialNoDropItemSubType; // Offset: 0xe4 // Size: 0x04
	int IceDrinkItemSubType; // Offset: 0xe8 // Size: 0x04
	int IsAutoPickUpTaskSubType; // Offset: 0xec // Size: 0x04
	struct TArray<int> carryOnPlane; // Offset: 0xf0 // Size: 0x10
	int CapacityThreshold; // Offset: 0x100 // Size: 0x04
	int GlideSubType; // Offset: 0x104 // Size: 0x04
	int ParachuteItemSubType; // Offset: 0x108 // Size: 0x04
	int revivalCardID; // Offset: 0x10c // Size: 0x04
	int SnowManID; // Offset: 0x110 // Size: 0x04
	float revivalCardValidTime; // Offset: 0x114 // Size: 0x04
	struct TArray<int> firewoodPriority; // Offset: 0x118 // Size: 0x10
	struct TArray<int> meatPriority; // Offset: 0x128 // Size: 0x10
	struct TArray<int> UAVList; // Offset: 0x138 // Size: 0x10
	struct TArray<int> ElectricityList; // Offset: 0x148 // Size: 0x10
	struct TArray<int> ToUseInBackpackSubList; // Offset: 0x158 // Size: 0x10
	struct TArray<int> ToUseInBackpackIDList; // Offset: 0x168 // Size: 0x10
	struct TArray<int> notExtractItemIDList; // Offset: 0x178 // Size: 0x10
};

// Object Name: ScriptStruct Basic.PickupFirstCount
// Size: 0x08 // Inherited bytes: 0x00
struct FPickupFirstCount {
	// Fields
	int pickID; // Offset: 0x00 // Size: 0x04
	int Count; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Basic.PickupSettingForTPlan
// Size: 0x1e8 // Inherited bytes: 0x00
struct FPickupSettingForTPlan {
	// Fields
	int LimitSkillProps; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TMap<int, int> LimitBulletMap_XT; // Offset: 0x08 // Size: 0x50
	struct TMap<int, int> LimitDrugMap_XT; // Offset: 0x58 // Size: 0x50
	struct TMap<int, int> LimitThrowObjMap_XT; // Offset: 0xa8 // Size: 0x50
	struct TMap<int, int> LimitMultipleMirrorMap_XT; // Offset: 0xf8 // Size: 0x50
	struct TMap<int, int> LimitNormalInfillingMap_XT; // Offset: 0x148 // Size: 0x50
	struct TMap<int, int> LimitHalloweenInfillingMap_XT; // Offset: 0x198 // Size: 0x50
};

// Object Name: ScriptStruct Basic.PickupSetting
// Size: 0x1c8 // Inherited bytes: 0x00
struct FPickupSetting {
	// Fields
	int LimitBandage; // Offset: 0x00 // Size: 0x04
	int LimitMedical; // Offset: 0x04 // Size: 0x04
	int LimitFirstAidKit; // Offset: 0x08 // Size: 0x04
	int LimitAnodyne; // Offset: 0x0c // Size: 0x04
	int LimitEnergyDrinks; // Offset: 0x10 // Size: 0x04
	int LimitAdrenaline; // Offset: 0x14 // Size: 0x04
	int LimitShouliudan; // Offset: 0x18 // Size: 0x04
	int LimitYanwudan; // Offset: 0x1c // Size: 0x04
	int LimitZhenbaodan; // Offset: 0x20 // Size: 0x04
	int LimitRanshaodan; // Offset: 0x24 // Size: 0x04
	int LimitViscidityBomb; // Offset: 0x28 // Size: 0x04
	int LimitGrenadeZombie; // Offset: 0x2c // Size: 0x04
	int LimitGrenadeYedan; // Offset: 0x30 // Size: 0x04
	int LimitAntidote; // Offset: 0x34 // Size: 0x04
	int LimitBatteryChip; // Offset: 0x38 // Size: 0x04
	int LimitGameCoin; // Offset: 0x3c // Size: 0x04
	int LimitBullet9mm; // Offset: 0x40 // Size: 0x04
	int LimitBullet7_62mm; // Offset: 0x44 // Size: 0x04
	int Limit12koujing; // Offset: 0x48 // Size: 0x04
	int Limit45koujing; // Offset: 0x4c // Size: 0x04
	int Limit300magenandanyao; // Offset: 0x50 // Size: 0x04
	int Limitbolt; // Offset: 0x54 // Size: 0x04
	int LimitBullet5_57; // Offset: 0x58 // Size: 0x04
	bool AutoPickupPistol; // Offset: 0x5c // Size: 0x01
	bool AutoPickupLevel3Backpack; // Offset: 0x5d // Size: 0x01
	bool AutoPickupSideMirror; // Offset: 0x5e // Size: 0x01
	char pad_0x5F[0x1]; // Offset: 0x5f // Size: 0x01
	int LimitSniper2X; // Offset: 0x60 // Size: 0x04
	int LimitSniper3X; // Offset: 0x64 // Size: 0x04
	int LimitSniper4X; // Offset: 0x68 // Size: 0x04
	int LimitSniper6X; // Offset: 0x6c // Size: 0x04
	int LimitSniper8X; // Offset: 0x70 // Size: 0x04
	bool AutoPickupSkillProps; // Offset: 0x74 // Size: 0x01
	char pad_0x75[0x3]; // Offset: 0x75 // Size: 0x03
	int LimitSkillProps; // Offset: 0x78 // Size: 0x04
	int LimitSnowMan; // Offset: 0x7c // Size: 0x04
	bool AutoPickMirror; // Offset: 0x80 // Size: 0x01
	char pad_0x81[0x3]; // Offset: 0x81 // Size: 0x03
	int AutoPickClipType; // Offset: 0x84 // Size: 0x04
	struct TMap<int, int> LimitDrugMap; // Offset: 0x88 // Size: 0x50
	struct TMap<int, int> LimitThrowObjMap; // Offset: 0xd8 // Size: 0x50
	struct TMap<int, int> LimitMultipleMirrorMap; // Offset: 0x128 // Size: 0x50
	struct TMap<int, int> LimitFixConsumeItemMap; // Offset: 0x178 // Size: 0x50
};

// Object Name: ScriptStruct Basic.SpecPickItem
// Size: 0x0c // Inherited bytes: 0x00
struct FSpecPickItem {
	// Fields
	int item_id; // Offset: 0x00 // Size: 0x04
	int cur_count; // Offset: 0x04 // Size: 0x04
	int total_count; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Basic.ItemRecordData
// Size: 0x100 // Inherited bytes: 0x00
struct FItemRecordData {
	// Fields
	char pad_0x0[0x4]; // Offset: 0x00 // Size: 0x04
	int ItemID; // Offset: 0x04 // Size: 0x04
	int ItemType; // Offset: 0x08 // Size: 0x04
	int ItemSubType; // Offset: 0x0c // Size: 0x04
	int BPID; // Offset: 0x10 // Size: 0x04
	int WeightforOrder; // Offset: 0x14 // Size: 0x04
	int Worth; // Offset: 0x18 // Size: 0x04
	int ItemCapacity; // Offset: 0x1c // Size: 0x04
	int Durability; // Offset: 0x20 // Size: 0x04
	int ItemSoundID; // Offset: 0x24 // Size: 0x04
	int ItemQuality; // Offset: 0x28 // Size: 0x04
	int ItemPickupRule; // Offset: 0x2c // Size: 0x04
	int AIFullVaule; // Offset: 0x30 // Size: 0x04
	float Weight; // Offset: 0x34 // Size: 0x04
	int MaxCount; // Offset: 0x38 // Size: 0x04
	bool AutoEquipandDrop; // Offset: 0x3c // Size: 0x01
	bool Consumable; // Offset: 0x3d // Size: 0x01
	bool Equipable; // Offset: 0x3e // Size: 0x01
	char pad_0x3F[0x1]; // Offset: 0x3f // Size: 0x01
	struct FString ItemName; // Offset: 0x40 // Size: 0x10
	struct FString ItemBigIcon; // Offset: 0x50 // Size: 0x10
	struct FString ItemDesc; // Offset: 0x60 // Size: 0x10
	struct FString ItemSmallIcon; // Offset: 0x70 // Size: 0x10
	struct FString KillWhiteIcon; // Offset: 0x80 // Size: 0x10
	struct FString ItemWhiteIcon; // Offset: 0x90 // Size: 0x10
	struct FString RedEmotionSoundPath; // Offset: 0xa0 // Size: 0x10
	struct FString PickupDesc; // Offset: 0xb0 // Size: 0x10
	struct FString BackpackSimple; // Offset: 0xc0 // Size: 0x10
	struct FString SpecialIcon; // Offset: 0xd0 // Size: 0x10
	struct FString ItemBigIcon2; // Offset: 0xe0 // Size: 0x10
	struct FString ItemSmallIcon2; // Offset: 0xf0 // Size: 0x10
};

// Object Name: ScriptStruct Basic.ArmorAttachItemUnit
// Size: 0x20 // Inherited bytes: 0x00
struct FArmorAttachItemUnit {
	// Fields
	struct FItemDefineID DefineID; // Offset: 0x00 // Size: 0x18
	enum class EBattleItemAdditionalDataType SlotAdditionalType; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct Basic.BPClassItemMap
// Size: 0x50 // Inherited bytes: 0x00
struct FBPClassItemMap {
	// Fields
	struct TMap<struct FString, struct UClass*> BPClassModOverride; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Basic.BPClassItem
// Size: 0xb0 // Inherited bytes: 0x00
struct FBPClassItem {
	// Fields
	struct FString ClassTagName; // Offset: 0x00 // Size: 0x10
	struct UClass* NativeClass; // Offset: 0x10 // Size: 0x28
	struct UClass* BPClass; // Offset: 0x38 // Size: 0x28
	struct TMap<struct FString, struct UClass*> BPClassModOverride; // Offset: 0x60 // Size: 0x50
};

// Object Name: ScriptStruct Basic.RecordItemID
// Size: 0x18 // Inherited bytes: 0x00
struct FRecordItemID {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct Basic.LuaEventTypeToIDSet
// Size: 0x50 // Inherited bytes: 0x00
struct FLuaEventTypeToIDSet {
	// Fields
	struct TMap<struct FString, struct FLuaEventTypeIDSet> EventTypeToIDSet; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Basic.LuaEventTypeIDSet
// Size: 0x50 // Inherited bytes: 0x00
struct FLuaEventTypeIDSet {
	// Fields
	struct TSet<struct FString> EventIDSet; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Basic.LuaEventTypeContainer
// Size: 0x50 // Inherited bytes: 0x00
struct FLuaEventTypeContainer {
	// Fields
	struct TMap<struct FString, int> EventIDContainer; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Basic.EventTypeContainer
// Size: 0x50 // Inherited bytes: 0x00
struct FEventTypeContainer {
	// Fields
	struct TMap<struct FString, struct FEventIDContainer> EventIDContainer; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Basic.EventIDContainer
// Size: 0x10 // Inherited bytes: 0x00
struct FEventIDContainer {
	// Fields
	struct TArray<struct FEventValueContainer> EventValueContainer; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Basic.EventValueContainer
// Size: 0x38 // Inherited bytes: 0x00
struct FEventValueContainer {
	// Fields
	struct TWeakObjectPtr<struct UObject> ObjContext; // Offset: 0x00 // Size: 0x08
	struct FString FunctionName; // Offset: 0x08 // Size: 0x10
	struct FString EventType; // Offset: 0x18 // Size: 0x10
	struct FString EventId; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct Basic.NetRelevancyGroupManager
// Size: 0x50 // Inherited bytes: 0x00
struct FNetRelevancyGroupManager {
	// Fields
	struct TMap<struct FNetRelevancyGroupID, struct UNetRelevancyGroup*> RelevancyGroups; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Basic.NetRelevancyGroupID
// Size: 0x04 // Inherited bytes: 0x00
struct FNetRelevancyGroupID {
	// Fields
	char pad_0x0[0x4]; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct Basic.BuffEventActionItem
// Size: 0x10 // Inherited bytes: 0x00
struct FBuffEventActionItem {
	// Fields
	struct USTBaseBuffEventType* EventType; // Offset: 0x00 // Size: 0x08
	struct UUTSkillAction* BuffEventAction; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct Basic.BuffActionItem
// Size: 0x08 // Inherited bytes: 0x00
struct FBuffActionItem {
	// Fields
	struct UUTSkillAction* BuffAction; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct Basic.StatusChange
// Size: 0x10 // Inherited bytes: 0x00
struct FStatusChange {
	// Fields
	struct USTBaseBuffStatusType* StatusName; // Offset: 0x00 // Size: 0x08
	bool StatusValue; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
};

// Object Name: ScriptStruct Basic.STBaseBuffTemplateItem
// Size: 0x18 // Inherited bytes: 0x00
struct FSTBaseBuffTemplateItem {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FName Name; // Offset: 0x08 // Size: 0x08
	struct USTBaseBuff* Buff; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct Basic.BuffManagerModPath
// Size: 0x10 // Inherited bytes: 0x00
struct FBuffManagerModPath {
	// Fields
	struct FName ModName; // Offset: 0x00 // Size: 0x08
	struct FName BuffListPath; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct Basic.BuffConditionActionItem
// Size: 0x08 // Inherited bytes: 0x00
struct FBuffConditionActionItem {
	// Fields
	int Index; // Offset: 0x00 // Size: 0x04
	enum class EBuffConditionInitializeType InitializeType; // Offset: 0x04 // Size: 0x01
	enum class EBuffConditionTrueExecuteType TrueExecType; // Offset: 0x05 // Size: 0x01
	enum class EBuffConditionFalseExecuteType FalseExecType; // Offset: 0x06 // Size: 0x01
	char pad_0x7[0x1]; // Offset: 0x07 // Size: 0x01
};

// Object Name: ScriptStruct Basic.STBuffInstancedItem
// Size: 0xb0 // Inherited bytes: 0x00
struct FSTBuffInstancedItem {
	// Fields
	int InstID; // Offset: 0x00 // Size: 0x04
	int BuffID; // Offset: 0x04 // Size: 0x04
	int BuffIndex; // Offset: 0x08 // Size: 0x04
	int LayerCount; // Offset: 0x0c // Size: 0x04
	int Level; // Offset: 0x10 // Size: 0x04
	bool PendingRemove; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	float EndTime; // Offset: 0x18 // Size: 0x04
	float DSEndTime; // Offset: 0x1c // Size: 0x04
	float Duration; // Offset: 0x20 // Size: 0x04
	int LayerMax; // Offset: 0x24 // Size: 0x04
	struct TWeakObjectPtr<struct AActor> Causer; // Offset: 0x28 // Size: 0x08
	struct TWeakObjectPtr<struct AActor> Owner; // Offset: 0x30 // Size: 0x08
	struct TWeakObjectPtr<struct USTBuff> Buff; // Offset: 0x38 // Size: 0x08
	struct TWeakObjectPtr<struct UActorComponent> OwnerSystem; // Offset: 0x40 // Size: 0x08
	int CauseSkillID; // Offset: 0x48 // Size: 0x04
	float PowerValue; // Offset: 0x4c // Size: 0x04
	float LastSyncClientTime; // Offset: 0x50 // Size: 0x04
	bool IsNeedSyncClient; // Offset: 0x54 // Size: 0x01
	char pad_0x55[0x5b]; // Offset: 0x55 // Size: 0x5b
};

// Object Name: ScriptStruct Basic.BuffTableRow
// Size: 0x130 // Inherited bytes: 0x00
struct FBuffTableRow {
	// Fields
	int BuffID; // Offset: 0x00 // Size: 0x04
	int MaxLayer; // Offset: 0x04 // Size: 0x04
	float Duration; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString BuffType; // Offset: 0x10 // Size: 0x10
	struct FString Name; // Offset: 0x20 // Size: 0x10
	struct FString IconPath; // Offset: 0x30 // Size: 0x10
	struct FString BPPath; // Offset: 0x40 // Size: 0x10
	struct FString Desc; // Offset: 0x50 // Size: 0x10
	struct TSet<struct FString> MutexBuffTypes; // Offset: 0x60 // Size: 0x50
	struct TSet<struct FString> ExcludeBuffTypes; // Offset: 0xb0 // Size: 0x50
	enum class EBuffRefreshType RefreshType; // Offset: 0x100 // Size: 0x01
	enum class EBuffReActionType ReActionType; // Offset: 0x101 // Size: 0x01
	enum class EBuffTargetType TargetType; // Offset: 0x102 // Size: 0x01
	enum class EMultiCauserHandleType MultiCauserHanleType; // Offset: 0x103 // Size: 0x01
	enum class EMultiSkillHandleType MultiSkillHandleType; // Offset: 0x104 // Size: 0x01
	enum class EBuffClientSyncType ClientSyncType; // Offset: 0x105 // Size: 0x01
	char pad_0x106[0x2]; // Offset: 0x106 // Size: 0x02
	float ClientSyncInterval; // Offset: 0x108 // Size: 0x04
	bool ExistForever; // Offset: 0x10c // Size: 0x01
	bool IsOnece; // Offset: 0x10d // Size: 0x01
	bool IsClientOwnLife; // Offset: 0x10e // Size: 0x01
	bool bNeedShowInUI; // Offset: 0x10f // Size: 0x01
	int LocalizeDescID; // Offset: 0x110 // Size: 0x04
	int TipsOnAddBuff; // Offset: 0x114 // Size: 0x04
	int ModeOpen; // Offset: 0x118 // Size: 0x04
	char pad_0x11C[0x4]; // Offset: 0x11c // Size: 0x04
	struct FString ModeStrings; // Offset: 0x120 // Size: 0x10
};

// Object Name: ScriptStruct Basic.BuffActionShared
// Size: 0x01 // Inherited bytes: 0x00
struct FBuffActionShared {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct Basic.BuffTargetShared
// Size: 0x10 // Inherited bytes: 0x01
struct FBuffTargetShared : FBuffActionShared {
	// Fields
	struct TArray<struct TWeakObjectPtr<struct AActor>> Actors; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Basic.AnimChildComponentData
// Size: 0x0c // Inherited bytes: 0x00
struct FAnimChildComponentData {
	// Fields
	struct TWeakObjectPtr<struct UUAEAnimListComponentBase> ChildComp; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x4]; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Basic.AnimListMapValueData
// Size: 0x10 // Inherited bytes: 0x00
struct FAnimListMapValueData {
	// Fields
	struct TArray<struct FAnimListData> AnimListMapValue; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Basic.AnimListData
// Size: 0x10 // Inherited bytes: 0x00
struct FAnimListData {
	// Fields
	int LayerID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UAnimationAsset* Animation; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct Basic.GameEngineTickStat
// Size: 0x08 // Inherited bytes: 0x00
struct FGameEngineTickStat {
	// Fields
	float Duration; // Offset: 0x00 // Size: 0x04
	float AvgTickDelta; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Basic.TravelFailureInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FTravelFailureInfo {
	// Fields
	struct UWorld* World; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
	struct FString ErrorMessage; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Basic.NetworkFailureInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FNetworkFailureInfo {
	// Fields
	struct UWorld* World; // Offset: 0x00 // Size: 0x08
	struct UNetDriver* NetDriver; // Offset: 0x08 // Size: 0x08
	char pad_0x10[0x8]; // Offset: 0x10 // Size: 0x08
	struct FString ErrorMessage; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Basic.LoadClassArrayParams
// Size: 0x18 // Inherited bytes: 0x00
struct FLoadClassArrayParams {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct Basic.BPTableItem
// Size: 0x58 // Inherited bytes: 0x00
struct FBPTableItem {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Name; // Offset: 0x08 // Size: 0x10
	struct FString Path; // Offset: 0x18 // Size: 0x10
	struct FString LobbyPath; // Offset: 0x28 // Size: 0x10
	struct FString WrapperPath; // Offset: 0x38 // Size: 0x10
	struct FString Custom1; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct Basic.DSNetSaturateCollectInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FDSNetSaturateCollectInfo {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct Basic.UnLoadLevelActorCollection
// Size: 0x18 // Inherited bytes: 0x00
struct FUnLoadLevelActorCollection {
	// Fields
	struct TArray<struct AActor*> LevelActors; // Offset: 0x00 // Size: 0x10
	float CollectionTime; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Basic.DistanceSegmentConfig
// Size: 0x08 // Inherited bytes: 0x00
struct FDistanceSegmentConfig {
	// Fields
	float RadiusSquared; // Offset: 0x00 // Size: 0x04
	int NumberLimit; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Basic.DistanceSegmentItem
// Size: 0x0c // Inherited bytes: 0x00
struct FDistanceSegmentItem {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

// Object Name: ScriptStruct Basic.PendingRegionNetworkObject
// Size: 0x20 // Inherited bytes: 0x00
struct FPendingRegionNetworkObject {
	// Fields
	struct UObject* RegionObject; // Offset: 0x00 // Size: 0x08
	struct FRegionID OldRegionID; // Offset: 0x08 // Size: 0x0c
	struct FRegionID NewRegionID; // Offset: 0x14 // Size: 0x0c
};

// Object Name: ScriptStruct Basic.DSNetReportInfo
// Size: 0x1c // Inherited bytes: 0x00
struct FDSNetReportInfo {
	// Fields
	char pad_0x0[0x1c]; // Offset: 0x00 // Size: 0x1c
};

// Object Name: ScriptStruct Basic.TableKeyPair
// Size: 0x60 // Inherited bytes: 0x00
struct FTableKeyPair {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
	struct TWeakObjectPtr<struct UUAEDataTable> BaseDataTable; // Offset: 0x50 // Size: 0x08
	struct TWeakObjectPtr<struct UUAEDataTable> ModDataTable; // Offset: 0x58 // Size: 0x08
};

