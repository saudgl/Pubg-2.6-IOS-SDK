//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Reddot_Anchor_Item05.Reddot_Anchor_Item05_C
// Size: 0x2dc // Inherited bytes: 0x2d0
struct UReddot_Anchor_Item05_C : ULuaUserWidget {
	// Fields
	struct UImage* Image_Breathing; // Offset: 0x2d0 // Size: 0x08
	int PosTemplate; // Offset: 0x2d8 // Size: 0x04
};

