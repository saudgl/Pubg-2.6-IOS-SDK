//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_UGCAuthorLevelConfig_type.BP_STRUCT_UGCAuthorLevelConfig_type
// Size: 0x48 // Inherited bytes: 0x00
struct FBP_STRUCT_UGCAuthorLevelConfig_type {
	// Fields
	int AlbumMaxNum_0_4B84BF403F93AEE757B260110334567D; // Offset: 0x00 // Size: 0x04
	int Level_1_52184B80082F14782E394D4D031E66BC; // Offset: 0x04 // Size: 0x04
	struct FString Icon_3_30DBEFC0796CDD3341E4862D003034FE; // Offset: 0x08 // Size: 0x10
	struct FString Name_4_7CC6CDC031F2EE2B41E514B600318E95; // Offset: 0x18 // Size: 0x10
	int EditModMaxNum_5_74216C8075E1CC2625D8D392002264DD; // Offset: 0x28 // Size: 0x04
	int PublishModMaxNum_6_5FD020C04EB5A3BF2E6AC34C0C0056DD; // Offset: 0x2c // Size: 0x04
	int ViewPicMaxNum_7_20CEB0C0514E6A434FC91047086E105D; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FString BgImage_8_6F9C90806450546622EF21EE041634D5; // Offset: 0x38 // Size: 0x10
};

