//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SuitDyePart_type.BP_STRUCT_SuitDyePart_type
// Size: 0x44 // Inherited bytes: 0x00
struct FBP_STRUCT_SuitDyePart_type {
	// Fields
	struct FString ChangeCost_0_0FA254C0779499277051C22E04B06B34; // Offset: 0x00 // Size: 0x10
	int ID_1_4DE34040418E994F2D0A457A03F06984; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString PartName_2_09ADE30011A0C53623B194970B693005; // Offset: 0x18 // Size: 0x10
	int PartNo_3_4CA1D20060DD89C2267DE0FD083B692F; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString PartParamIDs_4_7E61BF001A141FE663CE2AA000BD74B3; // Offset: 0x30 // Size: 0x10
	int Period_5_0EE975C010E3A28726084B1E083F8034; // Offset: 0x40 // Size: 0x04
};

