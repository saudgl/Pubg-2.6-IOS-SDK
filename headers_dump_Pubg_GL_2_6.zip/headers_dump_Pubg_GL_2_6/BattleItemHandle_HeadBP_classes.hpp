//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BattleItemHandle_HeadBP.BattleItemHandle_HeadBP_C
// Size: 0xb48 // Inherited bytes: 0xb32
struct UBattleItemHandle_HeadBP_C : UBattleItemHandle_AvatarBP_C {
	// Fields
	char pad_0xB32[0x6]; // Offset: 0xb32 // Size: 0x06
	struct TArray<int> BodyResIDList; // Offset: 0xb38 // Size: 0x10
};

