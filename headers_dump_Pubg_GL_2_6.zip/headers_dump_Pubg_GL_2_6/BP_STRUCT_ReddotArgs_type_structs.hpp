//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_ReddotArgs_type.BP_STRUCT_ReddotArgs_type
// Size: 0x2c // Inherited bytes: 0x00
struct FBP_STRUCT_ReddotArgs_type {
	// Fields
	struct FString Desc_0_439D61002282DEAA74C02F5C063A5C03; // Offset: 0x00 // Size: 0x10
	int ID_1_55BC6480323F81A02F5ECCBD00963A24; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString Type_2_5449C9C01D6C435B74D8C98C063B50F5; // Offset: 0x18 // Size: 0x10
	int Value_3_4C03008036F08F166DD7613003B38AD5; // Offset: 0x28 // Size: 0x04
};

