//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum Gamelet.EGameletEnvironment
enum class EGameletEnvironment : uint8 {
	Gamelet_Test = 0,
	Gamelet_Product = 1,
	Gamelet_Tyf_Test = 2,
	Gamelet_Tyf_Product = 3,
	Gamelet_MAX = 4
};

// Object Name: Enum Gamelet.ECmd
enum class ECmd : int32 {
	G_Send_Message_To_App = 10001,
	S2E_SDK_Initialized = 40001,
	S2E_On_Cgi_Process_Complete = 40002,
	ECmd_MAX = 40003
};

