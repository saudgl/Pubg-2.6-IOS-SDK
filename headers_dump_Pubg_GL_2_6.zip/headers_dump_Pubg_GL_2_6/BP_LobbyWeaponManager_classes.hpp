//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_LobbyWeaponManager.BP_LobbyWeaponManager_C
// Size: 0x3ec // Inherited bytes: 0x388
struct UBP_LobbyWeaponManager_C : ULobbyWeaponManagerComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x388 // Size: 0x08
	int CurEquipWeaponID; // Offset: 0x390 // Size: 0x04
	int CurUseWeaponID; // Offset: 0x394 // Size: 0x04
	struct TSet<int> NoneLODModeWeapons; // Offset: 0x398 // Size: 0x50
	int ExactDeviceLevel; // Offset: 0x3e8 // Size: 0x04

	// Functions

	// Object Name: Function BP_LobbyWeaponManager.BP_LobbyWeaponManager_C.UnEquipAllWeapon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UnEquipAllWeapon(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyWeaponManager.BP_LobbyWeaponManager_C.UnEquipAllExtraWeapon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UnEquipAllExtraWeapon(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyWeaponManager.BP_LobbyWeaponManager_C.AsyncWeaponAllAssetsLoadFinish
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void AsyncWeaponAllAssetsLoadFinish(struct ABP_LobbyWeapon_C* BPLobbyWeapon); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_LobbyWeaponManager.BP_LobbyWeaponManager_C.AsyncWeaponMeshLoadFinish
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void AsyncWeaponMeshLoadFinish(struct UAvatarDIYComponent* AvatarDIYComponent); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_LobbyWeaponManager.BP_LobbyWeaponManager_C.AsyncWeaponAnimLoadFinish
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void AsyncWeaponAnimLoadFinish(struct ASTExtraLobbyWeapon* LobbyWeapon); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_LobbyWeaponManager.BP_LobbyWeaponManager_C.CheckWeaponNeedLODOptimize
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void CheckWeaponNeedLODOptimize(int AvatarLevel, bool& bIsNeedLodOptimize); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function BP_LobbyWeaponManager.BP_LobbyWeaponManager_C.CheckCanEquipWeapon
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void CheckCanEquipWeapon(int resID, bool& CanEquip); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function BP_LobbyWeaponManager.BP_LobbyWeaponManager_C.EquipWeaponByResId
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void EquipWeaponByResId(int resID, bool bUse, bool bAsync, struct FName SocketName, struct ASTExtraWeapon*& Weapon); // Offset: 0x1041acc2c // Return & Params: Num(5) Size(0x18)

	// Object Name: Function BP_LobbyWeaponManager.BP_LobbyWeaponManager_C.UnEquipWeaponByResId
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UnEquipWeaponByResId(struct FName SocketName); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_LobbyWeaponManager.BP_LobbyWeaponManager_C.GetWeaponSocketNameByResId
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetWeaponSocketNameByResId(int resID, struct FName& SocketName); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_LobbyWeaponManager.BP_LobbyWeaponManager_C.SetWeaponVisibility
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetWeaponVisibility(bool bHide); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_LobbyWeaponManager.BP_LobbyWeaponManager_C.CreateWeapon
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void CreateWeapon(int inInt, struct ASTExtraWeapon*& Weapon, struct UBattleItemHandleBase*& Handle); // Offset: 0x1041acc2c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function BP_LobbyWeaponManager.BP_LobbyWeaponManager_C.GetLobbyWeaponClass
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct UObject* GetLobbyWeaponClass(int InWeaponAvatarID); // Offset: 0x1041acc2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_LobbyWeaponManager.BP_LobbyWeaponManager_C.CreateWeaponAndChangeSkin
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct ASTExtraWeapon* CreateWeaponAndChangeSkin(int WeaponSkinID, bool bUse, bool bSync); // Offset: 0x1041acc2c // Return & Params: Num(4) Size(0x10)

	// Object Name: Function BP_LobbyWeaponManager.BP_LobbyWeaponManager_C.ReceiveBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x1041acc2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyWeaponManager.BP_LobbyWeaponManager_C.ExecuteUbergraph_BP_LobbyWeaponManager
	// Flags: [None]
	void ExecuteUbergraph_BP_LobbyWeaponManager(int EntryPoint); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0x4)
};

