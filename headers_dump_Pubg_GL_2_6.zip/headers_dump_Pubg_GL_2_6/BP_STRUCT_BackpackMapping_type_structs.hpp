//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_BackpackMapping_type.BP_STRUCT_BackpackMapping_type
// Size: 0x20 // Inherited bytes: 0x00
struct FBP_STRUCT_BackpackMapping_type {
	// Fields
	int ItemIDLv1_0_21A3A0400039E85B0FB4B5AE02FC6161; // Offset: 0x00 // Size: 0x04
	int ItemIDLv3_4_21A5A0C00039E85D0FB4B5A802FC6163; // Offset: 0x04 // Size: 0x04
	int SkinID_5_0CC9E5002CE60FA0348CD8800DC46CC4; // Offset: 0x08 // Size: 0x04
	int ItemIDLv2_6_21A4A0800039E85C0FB4B5AF02FC6162; // Offset: 0x0c // Size: 0x04
	int SkinItemIDLv1_8_54E5658067900F920ABA96CA085B62E1; // Offset: 0x10 // Size: 0x04
	int SkinItemIDLv3_9_54E7660067900F940ABA96CC085B62E3; // Offset: 0x14 // Size: 0x04
	int LobbyShowItemID_10_2F22E9C00E7C61770577495A0A75F1B4; // Offset: 0x18 // Size: 0x04
	int SkinItemIDLv2_11_54E665C067900F930ABA96CD085B62E2; // Offset: 0x1c // Size: 0x04
};

