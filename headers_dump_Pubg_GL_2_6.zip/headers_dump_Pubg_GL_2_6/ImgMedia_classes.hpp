//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ImgMedia.ImgMediaSource
// Size: 0x60 // Inherited bytes: 0x38
struct UImgMediaSource : UBaseMediaSource {
	// Fields
	float FramesPerSecondOverride; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct FString ProxyOverride; // Offset: 0x40 // Size: 0x10
	struct FDirectoryPath SequencePath; // Offset: 0x50 // Size: 0x10

	// Functions

	// Object Name: Function ImgMedia.ImgMediaSource.SetSequencePath
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSequencePath(struct FString Path); // Offset: 0x1026fa318 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ImgMedia.ImgMediaSource.GetSequencePath
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSequencePath(); // Offset: 0x1026fa2b0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ImgMedia.ImgMediaSource.GetProxies
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetProxies(struct TArray<struct FString>& OutProxies); // Offset: 0x1026fa208 // Return & Params: Num(1) Size(0x10)
};

