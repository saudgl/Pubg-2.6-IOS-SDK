//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BattleItemHandle_VirtualCharacter.BattleItemHandle_VirtualCharacter_C
// Size: 0x140 // Inherited bytes: 0x140
struct UBattleItemHandle_VirtualCharacter_C : UBattleItemHandle_VirtualItem_C {
	// Functions

	// Object Name: Function BattleItemHandle_VirtualCharacter.BattleItemHandle_VirtualCharacter_C.ExtractItemData
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const]
	struct FBattleItemData ExtractItemData(); // Offset: 0x1041acc2c // Return & Params: Num(1) Size(0xb8)
};

