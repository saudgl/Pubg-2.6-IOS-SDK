//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class QRCodeUtility.ZXingScanner
// Size: 0x28 // Inherited bytes: 0x28
struct UZXingScanner : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function QRCodeUtility.ZXingScanner.Encode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UTexture2D* Encode(struct FString Text); // Offset: 0x1022c3188 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function QRCodeUtility.ZXingScanner.Decode
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	bool Decode(struct UTexture2D* Texture, struct FZXingScanResult& OutResult, struct FVector4& InRect); // Offset: 0x1022c3038 // Return & Params: Num(4) Size(0x41)
};

