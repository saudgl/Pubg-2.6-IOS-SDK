//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SystemConfig_type.BP_STRUCT_SystemConfig_type
// Size: 0x20 // Inherited bytes: 0x00
struct FBP_STRUCT_SystemConfig_type {
	// Fields
	struct FString ConfigName_0_B351EBDD4943D6FD5424AEA22C61E67A; // Offset: 0x00 // Size: 0x10
	struct FString ConfigValue_1_620016104053F64B0B760E850ADBE839; // Offset: 0x10 // Size: 0x10
};

