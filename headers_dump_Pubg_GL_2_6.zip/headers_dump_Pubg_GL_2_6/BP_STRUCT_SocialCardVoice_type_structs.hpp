//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SocialCardVoice_type.BP_STRUCT_SocialCardVoice_type
// Size: 0x18 // Inherited bytes: 0x00
struct FBP_STRUCT_SocialCardVoice_type {
	// Fields
	int ID_0_41C03B802C9BA22C40CED3890D91E234; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Voice_1_568315C024E4602D06D9223E0E338685; // Offset: 0x08 // Size: 0x10
};

