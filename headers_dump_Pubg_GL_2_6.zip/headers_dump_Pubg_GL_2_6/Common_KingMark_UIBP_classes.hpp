//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Common_KingMark_UIBP.Common_KingMark_UIBP_C
// Size: 0x270 // Inherited bytes: 0x260
struct UCommon_KingMark_UIBP_C : UUserWidget {
	// Fields
	struct UImage* Image_Icon_Bg; // Offset: 0x260 // Size: 0x08
	struct UTextBlock* TextBlock_Num; // Offset: 0x268 // Size: 0x08
};

