//gnerated by telegram @saudgl
//https://t.me/pubg_dev
#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SocialCardMode_type.BP_STRUCT_SocialCardMode_type
// Size: 0x18 // Inherited bytes: 0x00
struct FBP_STRUCT_SocialCardMode_type {
	// Fields
	int ID_0_0B8B7F4068179AC906DF9AB102AFB144; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Mode_1_442BBD401A100D51760CE2CA0FB2B705; // Offset: 0x08 // Size: 0x10
};

